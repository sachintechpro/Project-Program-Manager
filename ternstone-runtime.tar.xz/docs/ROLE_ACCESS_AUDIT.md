# Ternstone ValueOps — Role Access and SAFe Alignment Audit
> Source audited: AI-native ValueOps reference application. Test environment: fictional specialty insurer, synthetic scenarios. This is not a certification of SAFe conformance or production security.

## Executive assessment
- **Original build:** 29 defined roles; only 21 personas selectable. Most roles shared portfolio-centric dashboard content, all could browse broad technical artifacts and unassigned pending reviews, and all received the audit feed. Admin incorrectly appeared as a reviewer of ten pending contracts.
- **Corrective reference build:** 29 demo personas and 29 role-targeted workspaces; explicit role-to-contract visibility; authorization enforced for artifact listing, direct download, revisions, initiative ZIP export, approvals, audit access and connector operations. Admin cannot read business-domain records or export financial contracts.
- **Verification:** 9 backend tests passed; offline Chromium DOM/rendering smoke checked all 29 role dashboards and navigation, with zero JavaScript page errors. Browser smoke used an intercepted API fixture because direct browser navigation was unavailable.
- **Major remaining scope:** Role access is defined by organizational role, not yet by assigned value stream, project, business line, tenant or individual user. Other SAFe-specific collaboration modules and real integrations are incomplete.

## Role-by-role matrix
| Role | Workspace intent | Authoring | Approval | Coverage |
|---|---|---|---|---|
| Executive Sponsor | Strategic sponsorship | — | — | Context / limited controls |
| Lean Portfolio Leader | Lean Portfolio Management | — | portfolio-epic | Gate-enabled |
| Value Management Office | Portfolio operations | — | — | Context / limited controls |
| Finance Business Partner | Financial stewardship | — | lean-business-case | Gate-enabled |
| Epic Owner | Epic lifecycle | portfolio-epic, lean-business-case | — | Gate-enabled |
| Enterprise Architect | Enterprise architecture | — | — | Context / limited controls |
| Business Owner | Business outcomes | brd | brd | Gate-enabled |
| Value Stream Owner | Value stream outcomes | — | benefits-report | Gate-enabled |
| Product Manager | Product management | — | prd | Gate-enabled |
| Product Owner | Product ownership | prd | — | Gate-enabled |
| Release Train Engineer | ART delivery coordination | — | — | Context / limited controls |
| Program / Project Manager | Integrated delivery controls | — | — | Context / limited controls |
| Scrum Master / Team Coach | Team flow and coaching | — | — | Context / limited controls |
| Forward Deployed Engineer | AI-enabled engineering | technical-plan, integration-contract, implementation-report, qa-report, security-review, release-plan, ops-handover | — | Gate-enabled |
| Engineering Reviewer | Engineering peer review | — | implementation-report | Gate-enabled |
| Solution / System Architect | Solution architecture | — | technical-plan | Gate-enabled |
| Integration & Data Lead | Integration and data | — | integration-contract | Gate-enabled |
| QA / Validation Lead | Quality and validation | — | qa-report | Gate-enabled |
| Security / Compliance Lead | Security assurance | — | security-review | Gate-enabled |
| Risk & Legal Advisor | Risk and compliance | — | — | Context / limited controls |
| Internal Auditor | Independent audit | — | — | Context / limited controls |
| Release Manager | Release control | — | release-plan | Gate-enabled |
| Operations / SRE Lead | Operational readiness | — | ops-handover | Gate-enabled |
| Customer Care Lead | Customer care handover | — | — | Context / limited controls |
| Analytics / Benefits Analyst | Benefits and measurement | benefits-report | — | Gate-enabled |
| Actuarial / Underwriting SME | Underwriting domain assurance | — | — | Context / limited controls |
| Claims Operations SME | Claims domain assurance | — | — | Context / limited controls |
| Supplier / Vendor Manager | Supplier coordination | — | — | Context / limited controls |
| Platform Administrator | Platform administration | — | — | Context / limited controls |

## Current stage ownership and approval contracts
| Stage | Contract | Author | Reviewer |
|---|---|---|---|
| Portfolio authorization | `portfolio-epic` | epic_owner | lpm |
| Portfolio authorization | `lean-business-case` | epic_owner | finance |
| Business & product contract | `brd` | business_owner | business_owner |
| Business & product contract | `prd` | product_owner | product_manager |
| Solution design approval | `technical-plan` | fde | architect |
| Solution design approval | `integration-contract` | fde | integration |
| AI-native engineering execution | `implementation-report` | fde | engineer |
| Independent quality & security | `qa-report` | fde | qa |
| Independent quality & security | `security-review` | fde | security |
| Controlled release | `release-plan` | fde | release |
| Operations handover | `ops-handover` | fde | ops |
| Benefits realization & closure | `benefits-report` | analytics | value_owner |

## Findings that require additional product development

### 1. Not all SAFe role responsibilities are implemented (high)
The RTE lacks a real PI Planning / ART Sync / dependency management workspace; the Scrum Master lacks a team-flow board; the Product Owner lacks an editable prioritized team backlog; Product Management lacks a roadmap/feature prioritization service; VMO and LPM lack an executable portfolio Kanban and WSJF investment decision process; enterprise architects lack an enabler/architecture runway service. Role-specific landing information is not a substitute for these workflows.

### 2. Business-domain specialist control gates are incomplete (high)
The current workflow has 12 contract types in eight stages, but the Actuarial/Underwriting SME, Claims SME and Risk/Legal Advisor have no mandatory domain-specific approval. The BRD currently uses Business Owner as both author and reviewer. The workflow should support context-specific multi-approver gates and separation of duties where the organization requires it.

### 3. Object-level and data-classification authorization remain incomplete (high)
The implemented permission layer enforces role-to-document-type visibility. It does not assign an individual to a value stream, ART, initiative, line of business or tenant. A role authorized for a particular contract type can still read that type across all initiatives. Markdown is not classified for embedded private financial, customer, claim or regulated content; contract type alone is insufficient for true enterprise DLP. Production requires per-record ABAC, explicit assignment, retention, masking and audit rules.

### 4. Operational role journeys require dedicated services (medium–high)
Customer Care lacks incident/feedback and customer-communication records; Operations lacks live SLO and runbook execution; Finance lacks actual-versus-forecast integration; Internal Audit has read-only ledger visibility but no independent control-testing workflow; Vendor Management has no supplier obligation board. These roles now have more appropriate landing views but cannot yet complete the full duties described by their titles.

### 5. Connectors and evidence freshness are still simulated (high for production)
Existing connectors can verify certain credentials and publish approved artifacts, but do not provide end-to-end bi-directional syncing, durable event delivery, source-of-truth reconciliation or live business data authorization. The free Render demo uses ephemeral SQLite. Full production deployment requires SSO, persistent database, infrastructure audit, scoped OAuth, and security testing.

### 6. Permissions are distinct from operational ownership (design principle)
Portfolio leadership decides funding, ART roles coordinate flow, Product Owners manage team priorities, FDEs own implementation, and independent QA/security/release/operations roles validate the relevant deliverables. The FDE role is the project’s custom AI-native delivery model, not a standard mandatory SAFe ART role.

## Recommended delivery order
1. Introduce assignment- and value-stream-based authorization plus data classification on all business objects and contract versions.
2. Add a dynamic reviewer/risk matrix and mandatory independent approvals for BRD, domain SMEs, regulatory controls and benefits validation.
3. Build PI Planning, ART dependency tracking, prioritized team backlogs, portfolio Kanban and financial decision workspaces.
4. Complete operational feedback loops: Customer Care issues, production KPIs, actual financial data, benefit measurement, and external synchronization.
5. Perform production security review, enterprise SSO integration, durable storage, DLP tests and independent end-to-end penetration testing.

## Verification environment
The 29-role UI smoke test was run locally using Chromium with mocked API responses based on actual FastAPI TestClient requests. Nine backend tests passed, including all persona access, permissions, financial exclusions, queue ownership, artifact downloading, and external publication restrictions. Live Render verification should be confirmed after deployment.
