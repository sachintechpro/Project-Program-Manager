# Context help and role-aware work assistant

## How to use

- Click the small **?** next to a form label or data column for a short meaning, an example and a relevant control note.
- Open **? Help** in the header or **Work assistant** in the lower corner. It follows the signed-in stakeholder, current page and selected initiative.
- Ask **What should I do next?**, **Which approvals are mine?**, **What blocks the current stage?**, **Explain RACI**, or **What evidence is required?**.
- The assistant reads the **current role's permitted stage, assigned contracts and control decisions**. It can also surface assigned RAID actions with recorded due dates, if available.
- Click its suggested page link to continue working. The assistant never approves a contract, changes a value or deploys software.

## Catalog and source data

| File | Purpose |
|---|---|
| `seed/help/pages.csv` | Purpose, next action and caution for each page |
| `seed/help/roles.csv` | Specific responsibilities and boundaries for all 29 roles |
| `seed/help/fields.csv` | More than 260 field definitions with examples, types and validation guidance |
| `seed/data/schema.json` | Authoritative schema for the existing reference CSVs; the field glossary is checked against it |

Source and glossary values are illustrations. No real customer or financial information is embedded in the help files.

## Two chat modes

**Guided answers (default):** Server-side, rule-based explanations grounded in the authenticated role, current page, relevant initiative and permitted state. Does not contact an external language model. This works immediately in the public demo.

**Connected AI (optional):** Appears only if an administrator explicitly configures a **live OpenAI connector**, using managed encryption and a restricted key. Users must choose **Use connected AI** for that request. The server sends a minimal role-scoped summary rather than raw documents, record dumps, credentials or protected financial values. Model responses are suggestions, never approved evidence.

Do not enter private customer information, PII or authentication credentials into the assistant. A company should approve its provider data policy before enabling this mode. The assistant has no external action tools.

## Safety and traceability

- The chat route requires an authenticated user and CSRF validation.
- The server checks role permissions; it does not rely on client-side hiding.
- QA and other nonfinancial roles cannot retrieve budget/financial fields through help, even by requesting a restricted page or choosing another initiative.
- Platform administrators cannot use help to read business initiative details.
- No chat action can create, approve, reject, update or publish a contract. Those actions remain in dedicated authorized application workflows.
- The audit ledger records the fact of a help request, the page, focused field, mode and relevant initiative reference, **not the raw chat question**.
- Chat messages are kept only in the browser for the current signed-in role; switching roles or signing out clears them.
- An optional live model does not gain any programmatic approval or write authority.

## Verification

Run `pytest -q tests/` for the backend, contract and access tests. The contextual tests cover all 29 roles, field catalog completeness, QA financial restrictions, administrator isolation and assistance against current stage records.

The offline Playwright script `tests/browser_help_offline.py` exercises the desktop/mobile interface with mocked network responses because the local automation browser restricts navigation. It verifies form help, opening and closing the assistant, role changes and financial-restriction behavior. For final enterprise use, separately perform real-browser accessibility, integration and security testing.
