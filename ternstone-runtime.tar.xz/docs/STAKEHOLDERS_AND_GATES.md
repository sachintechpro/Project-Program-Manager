# Stakeholder and stage-gate model

The system models 29 end-to-end stakeholders. The names below are a combination of SAFe roles and enterprise delivery functions, not 29 roles formally mandated by SAFe. A single individual may fill several compatible roles; independent approvals remain separated where required.

| Operating domain | Stakeholders | Core accountability |
|---|---|---|
| Executive investment | Executive Sponsor, LPM Leader, VMO, Finance Partner, Epic Owner, Enterprise Architect | Strategy, portfolio economic choices, investment guardrails, portfolio Kanban, technology direction |
| Business | Business Owner, Value Stream Owner, Underwriting/Actuarial SME, Claims SME | Operational outcomes, insurance rules, business decisions and benefits ownership |
| Product | Product Manager, Product Owner | Roadmap, products, BRD/PRD, backlog priorities, acceptance |
| ART / program | RTE, Program/Project Manager, Scrum Master/Team Coach, Vendor Manager | PI cadence, dependencies, funding reporting, risks, execution flow, supplier coordination |
| Engineering | FDE, Engineering Reviewer, Solution/System Architect, Integration/Data Lead | AI orchestration, source changes, technical design, integrations and peer verification |
| Independent assurance | QA/Validation Lead, Security/Compliance Lead, Risk/Legal Advisor, Internal Auditor | Verifiable tests, security, compliance, risk and control evidence |
| Operations | Release Manager, Operations/SRE Lead, Customer Care Lead | Controlled releases, operational handoff, ongoing service and customer feedback |
| Measurement / administration | Benefits Analyst, Platform Administrator | KPI baselines, realization evidence, secure platform configuration |

## Required transition contracts

| Current stage | Required Markdown | Human approval role | Next |
|---|---|---|---|
| Portfolio | Portfolio Epic | Lean Portfolio Leader | Product after all portfolio approvals |
| Portfolio | Lean Business Case | Finance Business Partner | Product after all portfolio approvals |
| Product | BRD | Business Owner | Architecture after BRD and PRD approvals |
| Product | PRD | Product Manager | Architecture after BRD and PRD approvals |
| Architecture | Technical Plan | Solution/System Architect | Build after all architecture approvals |
| Architecture | Integration Contract | Integration/Data Lead | Build after all architecture approvals |
| Build | Implementation Report | Engineering Reviewer | QA/Security |
| Quality | QA Report | Independent QA Lead | Release after QA and Security |
| Quality | Security Review | Security/Compliance Lead | Release after QA and Security |
| Release | Release Plan | Release Manager | Operations |
| Operations | Operational Handover | Operations/SRE Lead | Benefits |
| Benefits | Benefits Realization Report | Value Stream Owner | Closed |

The stage engine enforces these role checks and version-specific approvals. In the demo, generated Markdown QA and release contracts are **planning examples** rather than proof that an external build or deployment occurred.

## User interaction

For every contract: generate and review the standardized document; revise with the author role; approve or reject with the review role; record the decision and audit hash; advance only when all stage contracts are accepted. Downloadable Markdown and ZIP include stable IDs and historical versions. User role identities in production require individual accounts, not demo persona switching.
