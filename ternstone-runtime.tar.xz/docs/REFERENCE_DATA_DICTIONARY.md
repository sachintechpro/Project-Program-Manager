# Reference CSV dictionary and data lineage

Each CSV has exactly one topic and primary identifier. All references use stable IDs instead of copying repeated amounts into every file. Use the schema descriptions below to understand required values. All financial figures, volumes and outcomes are modeled; they must not be reported as actual operational outcomes.

## `value_streams.csv` — 6 rows
Organizational business flow and target operating measures.

| Column | Type | Interpretation |
|---|---|---|
| `stream_id` | `id` | Stable identifier of the parent development value stream. |
| `stream_name` | `text` | Stream name for this record; use stable vocabulary and link to the parent initiative. |
| `line_of_business` | `text` | Commercial or specialty insurance line affected. |
| `owner_role` | `role` | Role responsible for this item and its assigned response. |
| `strategy_theme` | `text` | Strategy theme for this record; use stable vocabulary and link to the parent initiative. |
| `flow_metric` | `text` | Flow metric for this record; use stable vocabulary and link to the parent initiative. |
| `metric_unit` | `text` | Unit in which the KPI is measured, such as hours or days. |
| `baseline_value` | `decimal` | Measured or modeled current-state value; interpret with metric_unit. |
| `target_value` | `decimal` | Intended future-state value; interpret with metric_unit. |

## `initiatives.csv` — 9 rows
Modeled investment intake and business scope.

| Column | Type | Interpretation |
|---|---|---|
| `initiative_key` | `id` | Stable identifier that joins all reference tables for one initiative. |
| `stream_id` | `ref:value_streams` | Stable identifier of the parent development value stream. |
| `initiative_title` | `text` | Plain-English name of the business improvement initiative. |
| `line_of_business` | `text` | Commercial or specialty insurance line affected. |
| `estimated_cost_usd` | `integer` | Modeled total implementation investment in US dollars; not actual spend. |
| `estimated_annual_benefit_usd` | `integer` | Modeled full-year benefit in US dollars; not a realized result. |
| `operating_volume` | `text` | Expected number of transactions and explicit measurement period. |
| `current_demo_stage` | `text` | Current simulated workflow location, not a real external release. |
| `assumption_basis` | `text` | Assumption basis for this record; use stable vocabulary and link to the parent initiative. |

## `business_steps.csv` — 49 rows
Ordered work from request through completed outcome.

| Column | Type | Interpretation |
|---|---|---|
| `step_id` | `id` | Step id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `sequence` | `integer` | Sequence for this record; use stable vocabulary and link to the parent initiative. |
| `step_name` | `text` | Step name for this record; use stable vocabulary and link to the parent initiative. |
| `actor_role` | `role` | Role performing this operational step. |
| `inputs` | `text` | Inputs for this record; use stable vocabulary and link to the parent initiative. |
| `outputs` | `text` | Outputs for this record; use stable vocabulary and link to the parent initiative. |
| `target_elapsed_hours` | `decimal` | Target elapsed hours for this record; use stable vocabulary and link to the parent initiative. |
| `exception_route` | `text` | Exception route for this record; use stable vocabulary and link to the parent initiative. |

## `requirements.csv` — 45 rows
Individually traceable business, product and control needs.

| Column | Type | Interpretation |
|---|---|---|
| `requirement_id` | `id` | Stable requirement identifier referenced by tests and contracts. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `requirement_type` | `enum:functional|nonfunctional|control` | Requirement type for this record; use stable vocabulary and link to the parent initiative. |
| `requirement` | `text` | Requirement for this record; use stable vocabulary and link to the parent initiative. |
| `acceptance_criteria` | `text` | Observable pass/fail condition agreed with the Product Owner. |
| `priority` | `enum:must|should|could` | Priority for this record; use stable vocabulary and link to the parent initiative. |
| `owner_role` | `role` | Role responsible for this item and its assigned response. |

## `business_rules.csv` — 18 rows
Insurance decision logic and human authority limits.

| Column | Type | Interpretation |
|---|---|---|
| `rule_id` | `id` | Rule id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `rule_name` | `text` | Rule name for this record; use stable vocabulary and link to the parent initiative. |
| `rule_description` | `text` | Rule description for this record; use stable vocabulary and link to the parent initiative. |
| `negative_case` | `text` | Invalid or unauthorized business scenario that must not silently pass. |
| `decision_owner_role` | `role` | Decision owner role for this record; use stable vocabulary and link to the parent initiative. |
| `human_decision_required` | `boolean` | Human decision required for this record; use stable vocabulary and link to the parent initiative. |

## `data_fields.csv` — 54 rows
Data contracts, types, required fields and permitted system owners.

| Column | Type | Interpretation |
|---|---|---|
| `field_id` | `id` | Field id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `business_entity` | `text` | Business entity for this record; use stable vocabulary and link to the parent initiative. |
| `field_name` | `text` | Field name for this record; use stable vocabulary and link to the parent initiative. |
| `data_type` | `enum:string|date|money|integer|boolean|document|identifier` | Data type for this record; use stable vocabulary and link to the parent initiative. |
| `is_required` | `boolean` | Is required for this record; use stable vocabulary and link to the parent initiative. |
| `system_of_record` | `text` | External system authoritative for this field; not this demo. |
| `validation` | `text` | Validation for this record; use stable vocabulary and link to the parent initiative. |
| `classification` | `enum:internal|confidential|restricted` | Sensitivity classification used for role and data safeguards. |

## `interfaces.csv` — 18 rows
Cross-system integration and failure behavior.

| Column | Type | Interpretation |
|---|---|---|
| `interface_id` | `id` | Interface id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `source_system` | `text` | Source system for this record; use stable vocabulary and link to the parent initiative. |
| `target_system` | `text` | Target system for this record; use stable vocabulary and link to the parent initiative. |
| `integration_style` | `enum:REST API|event|batch|managed upload` | Integration style for this record; use stable vocabulary and link to the parent initiative. |
| `direction` | `enum:inbound|outbound|bidirectional` | Direction for this record; use stable vocabulary and link to the parent initiative. |
| `idempotency_policy` | `text` | Idempotency policy for this record; use stable vocabulary and link to the parent initiative. |
| `failure_response` | `text` | Failure response for this record; use stable vocabulary and link to the parent initiative. |
| `owner_role` | `role` | Role responsible for this item and its assigned response. |

## `test_cases.csv` — 90 rows
Independent, not-yet-executed verification scenarios.

| Column | Type | Interpretation |
|---|---|---|
| `test_id` | `id` | Test id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `requirement_id` | `ref:requirements` | Stable requirement identifier referenced by tests and contracts. |
| `test_type` | `enum:functional|negative|security|integration` | Test type for this record; use stable vocabulary and link to the parent initiative. |
| `scenario` | `text` | Scenario for this record; use stable vocabulary and link to the parent initiative. |
| `expected_result` | `text` | Observable outcome that a test must demonstrate. |
| `execution_status` | `enum:not_run|passed|failed|blocked` | Whether a test was actually executed; examples are not_run. |
| `test_evidence_ref` | `text` | Test evidence ref for this record; use stable vocabulary and link to the parent initiative. |

## `risks.csv` — 18 rows
Potential causes and planned mitigations, separate from actual issues.

| Column | Type | Interpretation |
|---|---|---|
| `risk_id` | `id` | Risk id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `category` | `enum:technology|business|security|delivery|vendor|data` | Category for this record; use stable vocabulary and link to the parent initiative. |
| `risk_statement` | `text` | Risk statement for this record; use stable vocabulary and link to the parent initiative. |
| `likelihood` | `enum:low|medium|high` | Likelihood for this record; use stable vocabulary and link to the parent initiative. |
| `impact` | `enum:low|medium|high` | Impact for this record; use stable vocabulary and link to the parent initiative. |
| `mitigation` | `text` | Mitigation for this record; use stable vocabulary and link to the parent initiative. |
| `owner_role` | `role` | Role responsible for this item and its assigned response. |
| `status` | `enum:open|mitigating|closed` | Status for this record; use stable vocabulary and link to the parent initiative. |

## `dependencies.csv` — 32 rows
Cross-team, shared-platform and vendor prerequisites.

| Column | Type | Interpretation |
|---|---|---|
| `dependency_id` | `id` | Dependency id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `external_system` | `text` | External system for this record; use stable vocabulary and link to the parent initiative. |
| `provider_role` | `role` | Role responsible for the external dependency. |
| `needed_for` | `text` | Needed for for this record; use stable vocabulary and link to the parent initiative. |
| `delivery_condition` | `text` | Delivery condition for this record; use stable vocabulary and link to the parent initiative. |
| `status` | `enum:planned|confirmed|blocked|delivered` | Status for this record; use stable vocabulary and link to the parent initiative. |

## `stakeholder_assignments.csv` — 65 rows
Scenario-specific responsibility assignments; not corporate HR access.

| Column | Type | Interpretation |
|---|---|---|
| `assignment_id` | `id` | Assignment id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `role` | `role` | Internal stakeholder role key from the 29-role catalog. |
| `raci_code` | `enum:R|A|C|I` | Raci code for this record; use stable vocabulary and link to the parent initiative. |
| `responsibility` | `text` | Responsibility for this record; use stable vocabulary and link to the parent initiative. |

## `metrics.csv` — 9 rows
Baseline, target, ownership and measurement source for business benefits.

| Column | Type | Interpretation |
|---|---|---|
| `metric_id` | `id` | Metric id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `metric_name` | `text` | Metric name for this record; use stable vocabulary and link to the parent initiative. |
| `metric_unit` | `text` | Unit in which the KPI is measured, such as hours or days. |
| `baseline_value` | `decimal` | Measured or modeled current-state value; interpret with metric_unit. |
| `target_value` | `decimal` | Intended future-state value; interpret with metric_unit. |
| `direction` | `enum:decrease|increase` | Direction for this record; use stable vocabulary and link to the parent initiative. |
| `measurement_source` | `text` | Authoritative operational measurement source for the defined KPI. |
| `measurement_frequency` | `enum:daily|weekly|monthly|quarterly` | Measurement frequency for this record; use stable vocabulary and link to the parent initiative. |
| `benefit_owner_role` | `role` | Benefit owner role for this record; use stable vocabulary and link to the parent initiative. |
| `actual_status` | `enum:unmeasured|measured` | Whether the KPI has a verified actual measurement; examples are unmeasured. |

## `cost_estimates.csv` — 45 rows
Budget assumption breakdown, matching total requested funding.

| Column | Type | Interpretation |
|---|---|---|
| `cost_id` | `id` | Cost id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `cost_category` | `enum:engineering|integration|testing|change_management|contingency` | Type of estimate; all components reconcile to the investment total. |
| `planned_cost_usd` | `integer` | Modeled component cost in US dollars, reconciled to initiative investment. |
| `estimate_basis` | `text` | Estimate basis for this record; use stable vocabulary and link to the parent initiative. |
| `forecast_status` | `enum:assumption|verified` | Forecast status for this record; use stable vocabulary and link to the parent initiative. |

## `release_controls.csv` — 36 rows
Specific release criteria and required verification evidence.

| Column | Type | Interpretation |
|---|---|---|
| `control_id` | `id` | Control id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `control_name` | `text` | Control name for this record; use stable vocabulary and link to the parent initiative. |
| `acceptance_requirement` | `text` | Acceptance requirement for this record; use stable vocabulary and link to the parent initiative. |
| `verifier_role` | `role` | Role authorized to verify this release control. |
| `evidence_source` | `text` | System or attachment where independently verified evidence is stored. |
| `verification_status` | `enum:not_run|accepted|rejected` | Verification status for this record; use stable vocabulary and link to the parent initiative. |

## `handover_tasks.csv` — 27 rows
Practical service acceptance and transition obligations.

| Column | Type | Interpretation |
|---|---|---|
| `handover_id` | `id` | Handover id for this record; use stable vocabulary and link to the parent initiative. |
| `initiative_key` | `ref:initiatives` | Stable identifier that joins all reference tables for one initiative. |
| `task_name` | `text` | Task name for this record; use stable vocabulary and link to the parent initiative. |
| `receiving_role` | `role` | Receiving role for this record; use stable vocabulary and link to the parent initiative. |
| `expected_evidence` | `text` | Expected evidence for this record; use stable vocabulary and link to the parent initiative. |
| `completion_status` | `enum:pending|accepted` | Completion status for this record; use stable vocabulary and link to the parent initiative. |

## `role_approval_controls.csv` — 29 rows
One actionable human review control per modeled stakeholder role.

| Column | Type | Interpretation |
|---|---|---|
| `control_code` | `id` | Control code for this record; use stable vocabulary and link to the parent initiative. |
| `stage` | `text` | Stage for this record; use stable vocabulary and link to the parent initiative. |
| `role` | `role` | Internal stakeholder role key from the 29-role catalog. |
| `decision_title` | `text` | Decision title for this record; use stable vocabulary and link to the parent initiative. |
| `decision_action` | `enum:approve|confirm|attest|acknowledge` | Decision action for this record; use stable vocabulary and link to the parent initiative. |
| `mandatory` | `boolean` | Whether the approval blocks the next gate, subject to its condition. |
| `condition` | `text` | When this stakeholder review applies and may be blocking. |
| `evidence_needed` | `text` | Evidence needed for this record; use stable vocabulary and link to the parent initiative. |


## How the joins work

`value_streams.stream_id` → `initiatives.stream_id` → `*.initiative_key` → individual record IDs. `test_cases.requirement_id` points to `requirements.requirement_id`. Cost lines in `cost_estimates.csv` total to `initiatives.estimated_cost_usd` by initiative. This budget is a modeled plan, not actual spending.

## Rules to prevent misunderstanding

- Use one unit per metric and include the period on operating volumes; never compare hours and days without conversion.
- Do not mark unexecuted example tests as Pass or business benefits as Realized.
- Treat financial assumptions as restricted to authorized portfolio/financial roles.
- Make source records read-only after portfolio approval; implement later revisions through authorized change control.
- Run `python scripts/validate_reference_csv.py`; it detects missing headers and required fields, duplicate identifiers, invalid roles, unresolved references, nonnumeric amounts, missing positive/negative tests, incorrect stage names, and cost/budget mismatches.

