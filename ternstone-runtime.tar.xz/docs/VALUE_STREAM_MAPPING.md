# Interactive Value Stream Mapping — Commercial & Specialty Insurance

**Open:** Value streams → select a stream → **◇ Interactive value map ↗**. An initiative journey also links back to its parent value stream map.

## Purpose and boundaries

This is an **operational value stream** map: from an event in a customer-facing insurance process to a verified completed customer outcome. It complements the existing **development value streams** that fund and build the technical capabilities. One is a business workflow; the other is the organization that improves the workflow.

## The six-step mapping practice

1. **Define customer value:** Customer/beneficiary, trigger, accepted outcome, first/final event, exclusions, guardrails and volume. Avoid defining value as a technical output.
2. **Meet stakeholders:** Invite Business Owner, Value Stream Owner, insurance SME, Product, PM, ART/RTE, FDE/Engineering, Architects, Integration, QA, Security, Operations/DevOps, Customer Care and Analytics. Record actual meeting attendance, observations, disagreements, proposed decisions, action owner and due date. Suggested agendas are **not** historical meeting records.
3. **Map current state:** Record the real sequence of six example steps, accountable process owners, source systems, active handling time, queue/wait time, first-pass completion and the pain point. Edit and add/reorder conceptual steps as necessary; map edits are versioned.
4. **Identify bottlenecks:** Rank the largest waiting-time stages, examine rework and producer/consumer handoffs. Recommendations are hypotheses requiring evidence and portfolio prioritization.
5. **Design future state:** Propose improved queue time, accountable ownership, integrated system behavior, quality checks and evidence. Compare current and future modeled values.
6. **Validate and hand off:** Required stakeholder roles confirm **the exact map revision**; a mapping confirmation does **not** approve funding, compliance exceptions or deployment. Export the versioned Markdown packet and submit a candidate initiative through LPM.

## Example value streams

| Value stream | Operational example | Modeled start → target |
|---|---|---|
| Commercial & Specialty Underwriting | Broker submission through binding confirmation for accepted risks | 12.4 → 6.7 calendar days |
| Claims Resolution & Recovery | Commercial FNOL through approved settlement and payment confirmation | 18.6 → 11.0 calendar days |
| Cyber Incident Response | Incident notice through confirmed response partner assignment | 9.1 → 3.6 elapsed hours |
| Commercial Policy Servicing & Billing | Endorsement request through synchronized policy and billing completion | 5.2 → 2.1 calendar days |
| Risk Engineering & Prevention | Inspection referral through reviewed risk report | 21.0 → 12.0 calendar days |
| Broker & Distribution Experience | Broker inquiry through verified resolution | 4.6 → 1.8 calendar days |

All numbers are **fictional modeling assumptions**, not actual insurer performance. Each reference map has six current and six proposed steps, recommended roles, real insurance systems/process considerations, and candidate improvements. Example submission volumes are also modeled.

## Calculations

- **Modeled elapsed hours:** Sum of estimated process touch hours and waiting hours.
- **Flow efficiency:** Total touch hours divided by total elapsed hours, × 100.
- **First-pass yield:** Product of step first-pass rates (simplified assumption; real case-level rework may be correlated).
- **Bottleneck share:** Step waiting time divided by modeled whole-flow elapsed time.

**Critical measurement caution:** You cannot derive the actual median end-to-end cycle time by summing step medians. These reference figures are allocation examples tied to the value stream headline, not real measurements. Before calculating baselines or ROI, use timestamped source-system case events, clear process boundaries, segmentation, case-level distributions and finance validation.

## Edit and approval policy

- A mapping **facilitator** (authorized PM, business/value stream leader, Product, RTE or LPM/VMO role) can make structured revisions. For new value streams the original creator remains the author; seeded examples can be claimed by the first authorized editor. Other users view the map read-only.
- Each participating role can record a new workshop note if invited. A meeting note can be revised **only by its author**. Every version retains a digest and audit event.
- Assigned reviewer roles may **Confirm** or **Request changes** for their own role only. They cannot sign for another role. An actual workshop note must exist before confirmation. New map content or workshop minutes invalidate previously recorded mapping confirmations.
- Passing mapping confirmation does not advance the existing initiative approval gates or authorize LPM spending. Use the existing portfolio contracts and role decisions for those approvals.
- Business records, maps and workshop notes are hidden from platform administrators without business roles. Map data contains no budgets, and Finance remains authoritative for financial actuals.
- Meeting attendance is recorded by its author, not independently certified. Review confirmations are separate, role-authenticated records.

## Data contracts and retention

- `seed/maps/<stream>.json` is the authoritative **read-only reference template** for each of the six streams.
- `seed/maps/value_definitions.csv`, `process_steps.csv`, `stakeholder_participation.csv`, `discovery_agenda.csv` and `improvement_candidates.csv` are small **derived exports** useful for human review and analytics. Do not edit them independently of the JSON source.
- Application edits, meetings, approvals, map revision history and MD exports are stored in the application database. Existing hash-linked audit events record creation, edits and decisions.
- The public Render demo currently uses non-durable SQLite. Use managed PostgreSQL, enterprise SSO, fine-grained authorization, retention policies and verified integration event logs before using this with real company data.

## Suggested discovery meeting prompts

Ask the broker/insured what outcome constitutes success, ask domain SMEs which regulatory decisions cannot be automated, ask Integration/DevOps where the authoritative timestamps live, ask QA for rework/defect rates, ask Operations about after-hours constraints, and ask Analytics which evidence can actually support the claimed benefit.

## Interactive decision and graphical evidence revision (November 2026)

Each of the six seeded commercial/specialty operational value-stream maps includes six current-state and six future-state steps. Each step has a modeled touch time, waiting time, first-pass percentage, owner and source-system label. The graphical maps now include:

- A common-scale touch-versus-wait time bar for every step.
- A paired before/target comparison by process position.
- Hover and keyboard-accessible definitions of the measurements.
- Click-to-inspect evidence panels showing business inputs, source-system evidence to collect, handoffs, required human controls, exception paths and candidate improvements.
- Workshop prompts that help cross-functional groups identify required evidence, without misrepresenting prompts as meetings that actually occurred.

The three new supporting CSV tables are in `seed/maps/`:

| Source | Row count | Keys | Meaning |
|---|---:|---|---|
| `step_evidence.csv` | 72 | `stream_key + state + step_id` | Process-step record, handoff, source to check, risk control, exceptions and modeled demand |
| `role_review_guidance.csv` | 48 | `stream_key + review_role` | Responsibility-specific decision question and evidence required |
| `workshop_questions.csv` | 30 | `stream_key + agenda_order` | Five suggested questions per stream, with role and evidence to bring |

These records are **illustrative planning references**. They are not observations obtained from policy, claims, cyber incident or broker production systems. Real baselines require case-level timestamps and explicitly defined segments and date ranges.

### Map-review decisions

Each assigned reviewer has three distinct decisions for the current map revision:

- **Approve:** Confirms the mapping evidence and boundary for the reviewer's assigned responsibility; a recorded workshop and evidence comment are required. This does *not* approve investment funding.
- **Decline:** The reviewer rejects the map with a specific reason and proposed corrective action. The map is not fully approved; it can be revised and resubmitted.
- **Ask for more information:** The reviewer records the exact missing evidence. A separate facilitator (never the original requesting reviewer) answers with an explanation and optional evidence source. The original reviewer must take a new decision; an answer is not automatic approval.

These decisions are role-restricted, revision-specific and logged with the actor and a digest of the decision text. Any map or meeting edit increments the mapping version, which invalidates its prior approvals. Responses remain traceable to the question that elicited them and are included in the Markdown decision export.

The `approve`, `decline` and `request_information` choices are now the primary UI; older API integrations using `confirm` and `request_changes` are still supported. The server does not allow users to answer their own information requests or approve a request for information that has not been answered.

### Operational scenario context

- **Underwriting:** Commercial broker submission through binding; identify payroll and class-code completeness issues, account-clearance queues, delegated underwriting authority and rating/binding evidence.
- **Claims:** Commercial FNOL through settlement; examine coverage checks, adjuster assignments, loss investigations, reserve approvals and segregated payment controls.
- **Cyber:** Notification through response-panel assignment; focus on 24×7 intake, caller verification, coverage triage, severity, incident response partner dispatch and acknowledgement times.
- **Policy servicing:** Endorsement submission to confirmation; focus on effective dates, referrals, rating, billing synchronization and insured/broker notification.
- **Risk engineering:** Referral through published inspection report; identify appointment scheduling, field survey capacity, review quality and publication authority.
- **Broker distribution:** Broker inquiry through verified response; assess identity and producer entitlements, policy status, document access, exception management and secure communication.

### Verification

Run `pytest -q tests/` (30 tests) and `PYTHONPATH=. python scripts/browser_vsm_offline_review.py` for the desktop interaction simulation. A mobile-specific script tests all six maps in a 390-pixel viewport. The tests check schema links, access controls, decision flows, current/future metrics, flow graphics, tooltip evidence and historical audit events. Direct access to the remote Render site from a restricted test browser may be unavailable; Render deployment status should be validated separately.
