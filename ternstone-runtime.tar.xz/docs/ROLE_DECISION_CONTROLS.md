# Role-specific decisions and human controls

Each stakeholder receives an action appropriate to their professional responsibility. An action is not always final approval: the roles with **Confirm** or **Attest** only verify their own evidence; they do not authorize funding or product release. The assigned user must sign in with that role. The system captures the decision, comment, artifact digest and time. Required controls block stage advancement. Advisory controls do not.

| Stage | Stakeholder role | Decision / confirmation | Default required? | What they must examine |
|---|---|---|---|---|
| Portfolio | Executive | Confirm strategic sponsorship (approve) | Conditional / no | Sponsor mandate and rationale |
| Portfolio | Lpm | Authorize portfolio sequencing (approve) | Yes | Strategic alignment and prioritization decision |
| Portfolio | Vmo | Verify Kanban intake completeness (confirm) | Yes | Epic hypothesis and decision criteria |
| Portfolio | Finance | Confirm funding envelope (approve) | Yes | Funding budget and guardrails |
| Portfolio | Epic Owner | Confirm epic analysis ready (confirm) | Conditional / no | Lean business case and MVP hypothesis |
| Architecture | Enterprise Architect | Approve architectural alignment (approve) | Conditional / no | Architectural standards assessment |
| Product | Value Owner | Confirm value stream baseline (approve) | Conditional / no | Baseline definition and business value |
| Product | Business Owner | Approve operational rules and outcomes (approve) | Yes | Business rules and acceptance criteria |
| Product | Product Manager | Approve roadmap fit (approve) | Conditional / no | Roadmap and feature scope |
| Product | Product Owner | Confirm backlog acceptance criteria (confirm) | Yes | Feature split and acceptance tests |
| Architecture | Rte | Confirm ART dependencies and PI plan (confirm) | Yes | PI objectives, dependency owners and capacity |
| Portfolio | Program Manager | Verify delivery feasibility and RAID (confirm) | Conditional / no | Resource and delivery assumptions |
| Build | Team Coach | Confirm team execution readiness (confirm) | Conditional / no | Impediments and WIP limits |
| Build | Fde | Attest implementation evidence handoff (attest) | Yes | Commit, build, plan and approval lineage |
| Build | Engineer | Approve peer engineering review (approve) | Conditional / no | Code quality and maintainability review |
| Architecture | Architect | Approve solution design (approve) | Conditional / no | Architecture and interface contract |
| Architecture | Integration | Approve integration data reconciliation (approve) | Conditional / no | Schema, mapping and retries |
| Quality | Qa | Confirm independent validation coverage (confirm) | Yes | Test IDs, results and defects |
| Quality | Security | Approve security control readiness (approve) | Conditional / no | Security evidence and exceptions |
| Quality | Risk | Approve compliance and legal exceptions (approve) | Conditional / no | Risk register and control exception review |
| Benefits | Audit | Attest audit trace completeness (attest) | Conditional / no | Version and approval trace |
| Release | Release | Approve release window and rollback (approve) | Yes | Specific build and deployment controls |
| Operations | Ops | Accept runbook and on-call ownership (approve) | Yes | Runbook and SLO checks |
| Operations | Customer Care | Confirm support and knowledge transfer (confirm) | Yes | Knowledge base and escalation mapping |
| Benefits | Analytics | Attest benefits measurement method (attest) | Yes | Baseline and data-source mapping |
| Product | Actuarial | Confirm underwriting and pricing constraints (approve) | Yes | Classification, approval and authority rules |
| Product | Claims Sme | Confirm claims authority and workflows (approve) | Yes | Coverage, reserve and adjustment authority |
| Architecture | Vendor | Confirm vendor readiness (confirm) | Conditional / no | Vendor contract, SLA and test environment |
| Architecture | Admin | Attest connector permission provisioning (attest) | Conditional / no | Least-privilege connector configuration; no business-data approval |

**Conditional controls:** Executive sponsorship is required above the established portfolio threshold; underwriting and claims SMEs are required for applicable lines of business; the compliance/Risk review is mandatory for selected sensitive changes; vendor review is mandatory for selected supplier-dependent work. System administration is a provisioning attestation, **never** business-data approval.

**Approval safety:** Stage-specific documents must exist before confirmation. A new input digest invalidates earlier confirmations. Only the assigned role may act. A rejection returns work for rework and is preserved in the audit trail.

**SAFe scope:** These additional review controls are a fictional organization's policy model, not universal mandatory SAFe roles or canonical SAFe events. Existing ART/PI and LPM governance remain separate.
