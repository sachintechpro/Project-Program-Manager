# Editing, accountability, and register governance

## Purpose
Ternstone demonstrates how a PM starts a new value stream or initiative, authors management records, and coordinates review under human authority. The UI and API enforce author-level editing for RACI and RAID; other authorized business users have read-only access. Platform administrators do not receive business-data access by virtue of their infrastructure role.

## RACI
R = Responsible (one or more roles); A = Accountable (exactly one role); C = Consulted; I = Informed. Authorized initial authors: Program Manager, RTE, VMO, Value Stream Owner, Product Owner. Ownership is bound to the **individual author account and role**, not merely the role label. Changes require an optimistic version match and create a historical Markdown revision and audit event.

## RAID
Categories: Risk, Assumption, Issue, Dependency. Fields: title, category, priority, status, accountable owner role, resolution/mitigation, due date, evidence reference, value stream or initiative scope. Authorized authors include Program Manager, RTE, VMO, Value Stream Owner, Product Owner, Team Coach, FDE, QA, Risk & Legal, Release, Operations and Vendor leads. Each record remains editable only by its original individual author. Other business users are readers; Admin is not.

## Editable initiative and value stream intake
The Program Manager may create a fresh value stream and then a new initiative under it, or start from seed data. The creator can revise draft details; changes produce immutable snapshots and audit events. A stale edit returns 409 instead of overwriting another version. All user-entered changes are persisted by the configured SQL database.

**Approved-scope safeguard:** Approved initiative scope cannot be silently rewritten. Once a portfolio gate is approved, detailed changes require a separate change-control authorization workflow. The current reference system blocks direct edits after approval; it does not yet implement a complete formal change request module. Likewise a value stream with active beyond-portfolio initiatives is protected against unreviewed material edits.

## Exports and feedback
Initiative evidence ZIP includes relevant initiative- and stream-scoped RACI/RAID Markdown files plus all their historical revision files. The event ledger records who created or modified the record, revision and digest. Connected systems remain authoritative for operational metrics; Markdown is the traceable delivery contract, not an invented actual-benefit record.

## Security limitations
Demonstration uses role-based views and author identity; enterprise use requires tenant, team, value-stream, and initiative-level ABAC/ACLs, authoritative SSO, data classification, segregation of duties, legal retention, concurrency-safe audit writes, source-system synchronization, and independent assessment before regulated production use.
