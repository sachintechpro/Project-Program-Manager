"""Interactive value-stream-map feature: inputs, lifecycle, author controls and evidence."""
from copy import deepcopy
from fastapi.testclient import TestClient
from app.main import app
from app.value_mapping import measures,validate_map
from app.catalog import STREAM_TEMPLATES

def sign(c,role):
    r=c.post('/api/login',json={'role':role});assert r.status_code==200,r.text
    return {'X-CSRF-Token':r.json()['csrf']}

def test_all_six_insurance_maps_are_linked_and_consistent():
    with TestClient(app) as c:
        h=sign(c,'program_manager')
        seeded={x['key'] for x in STREAM_TEMPLATES}
        for stream in [s for s in c.get('/api/streams').json() if s['key'] in seeded]:
            r=c.get(f"/api/streams/{stream['id']}/map")
            assert r.status_code==200,r.text
            d=r.json();assert d['value_stream']['id']==stream['id']
            assert len(d['map']['current'])==len(d['map']['future'])==6
            assert len(d['map']['invited_roles'])>=10
            assert 'qa' in d['map']['review_roles'] or stream['key']=='cyber'
            assert not d['meetings'] and not d['reviews']
            assert not d['approved_for_mapping']
            assert len(d['recommendations'])==3
            assert d['current']['elapsed_hours']>d['future']['elapsed_hours']
            expected=stream['baseline']*(1 if stream['key']=='cyber' else 24)
            assert abs(d['current']['elapsed_hours']-expected)<.01
            assert validate_map(d['map'])
            md=c.get(f"/api/streams/{stream['id']}/map/download")
            assert md.status_code==200 and 'What value does this stream deliver?' in md.text
            assert 'No actual workshop' in md.text

def test_map_revision_enforces_editor_optimistic_lock_and_review_staleness():
    with TestClient(app) as c:
        h=sign(c,'program_manager');sid=c.get('/api/streams').json()[0]['id']
        d=c.get(f'/api/streams/{sid}/map').json();v=d['version'];doc=deepcopy(d['map'])
        doc['value']['statement']='Provide a verifiable customer outcome with human approval.'
        r=c.put(f'/api/streams/{sid}/map',headers=h,json={'expected_version':v,'map':doc});assert r.status_code==200,r.text
        v2=r.json()['version'];assert v2==v+1
        assert c.put(f'/api/streams/{sid}/map',headers=h,json={'expected_version':v,'map':doc}).status_code==409
        history=c.get(f'/api/streams/{sid}/map/history').json();assert len(history)>=2
        h=sign(c,'qa');assert not c.get(f'/api/streams/{sid}/map').json()['can_edit']
        assert c.put(f'/api/streams/{sid}/map',headers=h,json={'expected_version':v2,'map':doc}).status_code==403
        if 'qa' in d['review_roles']:
            # No speculative review: a real, recorded meeting is a prerequisite.
            r=c.post(f'/api/streams/{sid}/map/reviews',headers=h,json={'expected_version':v2,'decision':'confirm','comment':'Reviewed current process and boundary'})
            assert r.status_code==409
            h=sign(c,'program_manager')
            mp={'title':'Map verification and stakeholder discovery','meeting_date':'2026-11-17','purpose':'Validate customer value',
                'invited_roles':['program_manager','qa'],'attended_roles':['program_manager','qa'],
                'notes':'Discussed wait durations and controls','decisions':'Verify external queue timestamps',
                'actions':'Obtain a source event sample','action_owner':'qa','action_due':'2026-11-24'}
            assert c.post(f'/api/streams/{sid}/map/meetings',headers=h,json=mp).status_code==200
            v2=c.get(f'/api/streams/{sid}/map').json()['version']
            h=sign(c,'qa')
            r=c.post(f'/api/streams/{sid}/map/reviews',headers=h,json={'expected_version':v2,'decision':'confirm','comment':'Reviewed current process and boundary'})
            assert r.status_code==200,r.text
            assert any(x['role']=='qa' and x['decision']=='confirm' for x in r.json()['reviews'])
        h=sign(c,'program_manager');doc['current'][0]['wait_hours']+=1
        r=c.put(f'/api/streams/{sid}/map',headers=h,json={'expected_version':v2,'map':doc});assert r.status_code==200,r.text
        assert not r.json()['reviews']
        assert c.get('/api/audit/verify').json()['valid']

def test_mapping_meeting_recorded_by_author_only():
    with TestClient(app) as c:
        h=sign(c,'program_manager');sid=c.get('/api/streams').json()[1]['id']
        doc=c.get(f'/api/streams/{sid}/map').json()['map']
        payload={'title':'Cross-functional current-state validation','meeting_date':'2026-11-17','purpose':'Agree current customer value and handoffs',
                 'invited_roles':['program_manager','business_owner','qa'],'attended_roles':['program_manager','qa'],
                 'notes':'Observed manual document handoff and requested evidence.','decisions':'No funding decision; verify waiting time.',
                 'actions':'Get 30-day timestamps for claims and policy checks','action_owner':'qa','action_due':'2026-11-24'}
        r=c.post(f'/api/streams/{sid}/map/meetings',headers=h,json=payload);assert r.status_code==200,r.text
        meeting=r.json();assert meeting['version']==1 and meeting['can_edit']
        h=sign(c,'qa');assert not c.get(f'/api/streams/{sid}/map').json()['meetings'][0]['can_edit']
        assert c.put(f"/api/streams/{sid}/map/meetings/{meeting['id']}",headers=h,json={**payload,'expected_version':1}).status_code==403
        h=sign(c,'program_manager');payload['notes']='Validated the issue; still need transaction timestamps.';payload['expected_version']=1
        r=c.put(f"/api/streams/{sid}/map/meetings/{meeting['id']}",headers=h,json=payload);assert r.status_code==200 and r.json()['version']==2
        hist=c.get(f"/api/streams/{sid}/map/meetings/{meeting['id']}/history").json();assert len(hist)==2
        assert c.get(f'/api/streams/{sid}/map/download').text.count('Cross-functional current-state validation')==1
        assert c.get('/api/audit/verify').json()['valid']

def test_admin_and_unassigned_role_cannot_override_mapping_reviews():
    with TestClient(app) as c:
        h=sign(c,'program_manager');sid=c.get('/api/streams').json()[0]['id']
        d=c.get(f'/api/streams/{sid}/map').json()
        h=sign(c,'admin')
        assert c.get(f'/api/streams/{sid}/map').status_code==403
        assert c.get(f'/api/streams/{sid}/map/download').status_code==403
        h=sign(c,'rte');r=c.post(f'/api/streams/{sid}/map/reviews',headers=h,json={'expected_version':d['version'],'decision':'confirm','comment':'I am not a formal reviewer'});assert r.status_code==403
        h=sign(c,'qa')
        assert c.post(f'/api/streams/{sid}/map/reviews',headers=h,json={'expected_version':999,'decision':'confirm','comment':'Not current'}).status_code==409
        assert c.post(f'/api/streams/{sid}/map/reviews',headers=h,json={'expected_version':d['version'],'decision':'request_changes','comment':''}).status_code==422

def test_new_stream_has_editable_blank_start_and_no_claimed_meeting():
    with TestClient(app) as c:
        h=sign(c,'program_manager')
        r=c.post('/api/streams',headers=h,json={'name':'Specialty Aviation Claims and Recovery'});assert r.status_code==200,r.text
        sid=r.json()['id'];d=c.get(f'/api/streams/{sid}/map').json()
        assert len(d['map']['current'])==3 and d['can_edit']
        assert not d['meetings'] and not d['reviews']
        assert d['map']['reference']=='blank/custom'

def test_all_required_reviewers_can_confirm_and_map_edit_invalidates():
    with TestClient(app) as c:
        h=sign(c,'program_manager')
        r=c.post('/api/streams',headers=h,json={'name':'Specialty Warranty Inspection Recovery Stream'});assert r.status_code==200
        sid=r.json()['id'];doc=c.get(f'/api/streams/{sid}/map').json()
        meeting={'title':'Agree improvement boundaries and customer value','meeting_date':'2026-11-17',
                 'purpose':'Review starter map','invited_roles':['program_manager','qa','business_owner'],
                 'attended_roles':['program_manager','business_owner'],
                 'notes':'Confirmed that the map is a draft requiring measurement.','decisions':'Keep funding decision separate.',
                 'actions':'Gather first 30 actual cases','action_owner':'business_owner','action_due':'2026-11-25'}
        assert c.post(f'/api/streams/{sid}/map/meetings',headers=h,json=meeting).status_code==200
        version=c.get(f'/api/streams/{sid}/map').json()['version']
        for role in doc['review_roles']:
            rh=sign(c,role)
            out=c.post(f'/api/streams/{sid}/map/reviews',headers=rh,json={'expected_version':version,'decision':'confirm','comment':'Checked reference and mapping boundary'})
            assert out.status_code==200,out.text
        assert out.json()['approved_for_mapping']
        h=sign(c,'program_manager');fresh=c.get(f'/api/streams/{sid}/map').json()
        updated=fresh['map'];updated['value']['statement']='Observed request-to-recommendation improvement'
        r=c.put(f'/api/streams/{sid}/map',headers=h,json={'expected_version':version,'map':updated});assert r.status_code==200
        assert not r.json()['approved_for_mapping']
        assert not r.json()['reviews']
        assert c.get('/api/audit/verify').json()['valid']
