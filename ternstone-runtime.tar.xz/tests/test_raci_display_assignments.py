from fastapi.testclient import TestClient
from app.main import app
from app.catalog import INIT_MAP


def sign(c,role):
    r=c.post('/api/login',json={'role':role});assert r.status_code==200
    return {'X-CSRF-Token':r.json()['csrf']}


def test_seeded_raci_has_separate_role_assignments_across_stages():
    with TestClient(app) as c:
        sign(c,'program_manager')
        initiatives=c.get('/api/initiatives').json()
        data=c.get('/api/registers?kind=raci').json()
        seeded=[i for i in initiatives if i['key'] in INIT_MAP]
        assert len(data)>=6*len(seeded)
        for initiative in seeded:
            rows=[r for r in data if r['initiative_id']==initiative['id']]
            assert len(rows)>=6
            owners={r['fields']['accountable'][0] for r in rows}
            assert len(owners)>=4, owners
            assert 'lpm' in owners and 'qa' in owners and 'release' in owners
            for r in rows:
                assert len(r['fields']['accountable'])==1
                assert r['fields']['responsible']
                assert r['author_role']=='program_manager'  # Author is not the assignment
        qa=next(r for r in data if r['fields']['accountable']==['qa'])
        md=c.get('/api/registers/'+str(qa['id'])+'/download')
        assert md.status_code==200
        assert b'QA / Validation' in md.content or b'QA Lead' in md.content or b'Quality and Validation' in md.content
        assert b'(qa)' in md.content


def test_newly_selected_roles_are_saved_and_exported_as_titles():
    with TestClient(app) as c:
        h=sign(c,'program_manager')
        sid=c.get('/api/streams').json()[0]['id']
        assigned={'responsible':['product_owner','actuarial'],'accountable':['business_owner'],'consulted':['rte','qa'],'informed':['finance']}
        created=c.post('/api/registers',headers=h,json={'kind':'raci','value_stream_id':sid,'title':'Validate commercial underwriting requirements','fields':assigned})
        assert created.status_code==200,created.text
        item=created.json()
        assert item['fields']==assigned
        md=c.get(f"/api/registers/{item['id']}/download").text
        assert 'Business Owner (business_owner)' in md
        assert 'Release Train Engineer (rte)' in md
        sign(c,'qa')
        view=c.get('/api/registers?kind=raci').json()
        found=next(r for r in view if r['id']==item['id'])
        assert found['fields']['accountable']==['business_owner']
        assert found['can_edit'] is False
