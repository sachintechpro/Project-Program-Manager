"""QA release evidence and audit controls; only demonstration sign-offs exist."""
import os
os.environ.setdefault('DEMO_MODE','true')
os.environ.setdefault('DATABASE_URL','sqlite:///./test_valueops.db')
os.environ.setdefault('SECRET_KEY','test-only-secret-key')
from fastapi.testclient import TestClient
from app.main import app


def login(c, role):
    r=c.post('/api/login', json={'role':role})
    assert r.status_code==200
    return {'X-CSRF-Token':r.json()['csrf']}


def test_qa_public_endpoint_requires_session_and_smoke_is_safe():
    with TestClient(app) as c:
        assert c.get('/api/qa/report').status_code==401
        login(c,'qa')
        r=c.get('/api/qa/report')
        assert r.status_code==200
        assert 'tests' in r.json() and r.json()['release_id']
        m=c.get('/api/qa/smoke')
        assert m.status_code==200,m.text
        assert m.json()['overall']=='PASS',m.text
        assert len(m.json()['checks'])==5
        assert c.get('/api/qa/signoffs').json()['production_decision'].startswith('NO-GO')


def test_qa_signoff_enforces_roles_csrf_immutability_and_audit():
    with TestClient(app) as c:
        h=login(c,'program_manager');release_id=c.get('/api/qa/report').json()['release_id']
        req={'decision':'go_demo','rationale':'I inspected the local report and checked the role-specific evidence.', 'release_id':release_id}
        assert c.post('/api/qa/signoffs',headers=h,json=req).status_code==403
        h=login(c,'qa')
        assert c.post('/api/qa/signoffs',json=req).status_code==403
        assert c.post('/api/qa/signoffs',headers=h,json={**req,'release_id':'stale'}).status_code==409
        assert c.post('/api/qa/signoffs',headers=h,json={**req,'rationale':'short'}).status_code==422
        assert c.post('/api/qa/signoffs',headers=h,json=req).status_code==200
        h=login(c,'release')
        assert c.post('/api/qa/signoffs',headers=h,json=req).status_code==200
        status=c.get('/api/qa/signoffs').json()
        assert status['demo_decision']=='GO (DEMO ONLY)'
        assert status['production_decision'].startswith('NO-GO')
        assert len(status['decisions'])==2
        req['decision']='no_go'
        assert c.post('/api/qa/signoffs',headers=h,json=req).status_code==200
        assert c.get('/api/qa/signoffs').json()['demo_decision']=='NO-GO'
        h=login(c,'qa')
        assert c.get('/api/audit/verify').json()['valid']
