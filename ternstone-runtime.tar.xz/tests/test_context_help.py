"""Role/page/field-aware guidance and data isolation tests."""
from fastapi.testclient import TestClient
from app.main import app
from app.catalog import ROLES
from app.help_catalog import field_catalog,page_catalog,get_field,role_catalog


def sign(client,role):
    res=client.post('/api/login',json={'role':role})
    assert res.status_code==200,res.text
    return {'X-CSRF-Token':res.json()['csrf']}

def ask(client,headers,question,page='dashboard',initiative_id=None,field_key='',use_ai=False):
    return client.post('/api/help/chat',headers=headers,json={'question':question,'page':page,'initiative_id':initiative_id,'field_key':field_key,'use_ai':use_ai})


def test_complete_field_page_and_role_catalog():
    assert len(page_catalog())>=15
    assert len(field_catalog())>=220
    assert set(role_catalog())=={r[0] for r in ROLES}
    assert get_field('requirements.acceptance_criteria')
    assert get_field('cost_estimates.planned_cost_usd')
    for p in ('streams','initiatives','reference','controls','raci','raid','contract','approvals','guide'):
        assert page_catalog()[p]['meaning']
    with TestClient(app) as c:
        assert c.post('/api/help/chat',json={'question':'What do I do?'}).status_code==401
        for role,*_ in ROLES:
            head=sign(c,role)
            r=c.get('/api/help/catalog');assert r.status_code==200
            d=r.json()
            assert d['role']['role']==role
            if role in ('qa','admin','release','rte'):
                assert 'budget' not in d['fields']
                assert 'cost_estimates.planned_cost_usd' not in d['fields']
            assert ask(c,head,'Explain this page').status_code==200

def test_qa_chat_uses_live_stage_and_hides_finance():
    with TestClient(app) as c:
        h=sign(c,'qa')
        help=c.get('/api/help/catalog').json()
        assert help['mode']=='guided' and help['ai_available'] is False
        assert 'test_cases.expected_result' in help['fields']
        r=ask(c,h,'What should I do next?',page='initiative',initiative_id=3)
        assert r.status_code==200,r.text
        data=r.json()
        assert data['read_only'] and data['role']=='qa'
        assert data['initiative_stage'] is not None
        assert data['mode']=='guided'
        assert '$' not in data['answer']
        blocked=ask(c,h,'Show me the budget and forecast amount for this initiative',page='insights',initiative_id=3)
        assert blocked.status_code==200
        assert 'restricted' in blocked.json()['answer'].lower() or 'not authorized' in blocked.json()['answer'].lower()
        assert blocked.json()['action_page']!='insights'
        f=ask(c,h,'What does this mean?',page='reference',initiative_id=3,field_key='test_cases.execution_status')
        assert f.status_code==200 and 'not_run' in f.json()['answer']
        for s in ['1','2']:
            r=ask(c,h,'Explain RACI and RAID',page='raci',initiative_id=int(s))
            assert r.status_code==200
        assert ask(c,h,'Help me work',use_ai=True).status_code==409
        assert c.get('/api/audit/verify').json()['valid']

def test_admin_does_not_access_business_records_via_help():
    with TestClient(app) as c:
        h=sign(c,'admin')
        r=ask(c,h,'Show costs for initiative',page='initiative',initiative_id=1)
        assert r.status_code==200
        assert r.json()['action_page']=='dashboard'
        assert 'restricted' in r.json()['answer'].lower() or 'authorized' in r.json()['answer'].lower()
        r=ask(c,h,'What should I do next?',page='integrations')
        assert r.status_code==200
        assert r.json()['action_page']=='integrations'
        assert 'connector' in r.json()['answer'].lower() or 'account' in r.json()['answer'].lower()

def test_control_guidance_not_a_self_approval():
    with TestClient(app) as c:
        h=sign(c,'lpm')
        r=ask(c,h,'Which approvals are mine?',page='controls')
        assert r.status_code==200
        assert r.json()['role']=='lpm'
        assert 'role' in r.json()['answer'].lower() or 'assign' in r.json()['answer'].lower()
        assert c.get('/api/audit/verify').json()['valid']
