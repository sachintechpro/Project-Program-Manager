"""Contract tests for all six reference maps, evidence, and three independent review choices."""
import csv,json
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app
from app.catalog import STREAM_TEMPLATES
from app.value_mapping import reference_evidence,measures

def login(c,role):
    resp=c.post('/api/login',json={'role':role})
    assert resp.status_code==200,resp.text
    return {'X-CSRF-Token':resp.json()['csrf']}


def meeting(c,sid,h):
    body={
      'title':'Value stream discovery and verification workshop','meeting_date':'2026-11-17',
      'purpose':'Discuss value, current queue evidence and next-state controls',
      'invited_roles':['program_manager','business_owner','qa'],
      'attended_roles':['program_manager','business_owner'],
      'notes':'Reviewed illustrative stream handoffs. Source system event timestamps still need independent verification.',
      'decisions':'Map approved values remain proposed until reviewers sign. No investment decision at this meeting.',
      'actions':'Request sample case timestamps from operations','action_owner':'business_owner','action_due':'2026-11-24'
    }
    x=c.post(f'/api/streams/{sid}/map/meetings',headers=h,json=body)
    assert x.status_code==200,x.text


def test_each_of_six_stream_maps_has_relevant_illustrative_graph_data():
    with TestClient(app) as c:
        login(c,'program_manager')
        streams={s['key']:s for s in c.get('/api/streams').json()}
        assert all(s['key'] in streams for s in STREAM_TEMPLATES)
        for key in ['underwriting','claims','cyber','servicing','risk','distribution']:
            stream=streams[key]
            r=c.get(f'/api/streams/{stream["id"]}/map')
            assert r.status_code==200,r.text
            obj=r.json();ref=obj['reference_evidence']
            assert len(obj['map']['current'])==6 and len(obj['map']['future'])==6
            assert len(ref['steps'])==12 and len(ref['workshop_questions'])==5
            assert len(ref['review_roles'])==len(obj['review_roles'])
            assert obj['current']['elapsed_hours']>obj['future']['elapsed_hours']>0
            assert 0<obj['current']['flow_efficiency_pct']<100
            assert 0<obj['future']['modeled_first_pass_pct']<=100
            for state in ('current','future'):
                for step in obj['map'][state]:
                    ev=ref['steps'][f'{state}:{step["id"]}']
                    assert ev['step_name']==step['name']
                    assert ev['source_to_check'] and ev['handoff'] and ev['required_control'] and ev['exception_to_test']
                    assert ev['reported_basis'].startswith('Illustrative')
            assert not obj['approved_for_mapping']
            assert obj['review_status']=='in_review'


def test_decline_request_information_answer_and_approve_are_separate_audited_decisions():
    with TestClient(app) as c:
        h=login(c,'program_manager')
        stream=next(s for s in c.get('/api/streams').json() if s['key']=='claims')
        sid=stream['id']; meeting(c,sid,h)
        obj=c.get(f'/api/streams/{sid}/map').json();v=obj['version']
        h=login(c,'business_owner')
        req=f'/api/streams/{sid}/map/reviews'
        resp=c.post(req,headers=h,json={'expected_version':v,'decision':'request_information','comment':'Show system-of-record loss notice timestamps for claimed queue wait.'})
        assert resp.status_code==200,resp.text
        status=resp.json()
        assert status['review_status']=='needs_information' and not status['approved_for_mapping']
        item=next(x for x in status['reviews'] if x['role']=='business_owner')
        assert item['response'] is None and item['kind']=='request_information'
        # Cannot self-approve while the requested evidence is missing.
        resp=c.post(req,headers=h,json={'expected_version':v,'decision':'approve','comment':'Reviewed documented process constraints'})
        assert resp.status_code==409
        # A different reviewer cannot respond on behalf of the facilitator.
        resp=c.post(f'/api/streams/{sid}/map/reviews/{item["id"]}/answer',headers=h,json={'expected_version':v,'response':'Here are the requested coverage and FNOL timestamps.'})
        assert resp.status_code==403
        h=login(c,'program_manager')
        ans=c.post(f'/api/streams/{sid}/map/reviews/{item["id"]}/answer',headers=h,json={
          'expected_version':v,'response':'The event timestamps have been requested; example records show the recommended data fields to capture.',
          'evidence_reference':'FNOL receipt and claims assignment event schemas'})
        assert ans.status_code==200,ans.text
        d=ans.json();assert d['review_status']=='needs_information'
        x=next(x for x in d['reviews'] if x['role']=='business_owner')
        assert x['response'] and x['response']['evidence_reference'].startswith('FNOL')
        # Duplicate answers not allowed.
        assert c.post(f'/api/streams/{sid}/map/reviews/{item["id"]}/answer',headers=h,json={
          'expected_version':v,'response':'Second unapproved reply attempt.'}).status_code==409
        h=login(c,'business_owner')
        resp=c.post(req,headers=h,json={'expected_version':v,'decision':'approve','comment':'Reviewed exception paths and source-timestamp requirements'})
        assert resp.status_code==200 and resp.json()['review_status']=='in_review'
        # A separate quality reviewer can explicitly decline with a reason.
        h=login(c,'qa')
        resp=c.post(req,headers=h,json={'expected_version':v,'decision':'decline','comment':'Settlement release must retain an independently verifiable control.'})
        assert resp.status_code==200 and resp.json()['review_status']=='declined'
        assert not resp.json()['approved_for_mapping']
        assert c.get(f'/api/streams/{sid}/map/download').status_code==200
        md=c.get(f'/api/streams/{sid}/map/download').text
        assert 'request_information' in md and 'Facilitator response' in md and 'decline' in md
        assert c.get('/api/audit/verify').json()['valid']
        # Editing current-state process invalidates every prior decision on that revision.
        h=login(c,'program_manager')
        d=c.get(f'/api/streams/{sid}/map').json();nextmap=d['map'];nextmap['current'][0]['wait_hours']+=.2
        resp=c.put(f'/api/streams/{sid}/map',headers=h,json={'expected_version':v,'map':nextmap})
        assert resp.status_code==200 and resp.json()['review_status']=='in_review'
        assert not resp.json()['reviews']


def test_review_authority_enforced_for_each_six_stream_and_all_roles():
    with TestClient(app) as c:
        login(c,'program_manager');streams={x['key']:x for x in c.get('/api/streams').json()}
        for key in ['underwriting','claims','cyber','servicing','risk','distribution']:
            sid=streams[key]['id'];data=c.get(f'/api/streams/{sid}/map').json();version=data['version']
            h=login(c,'rte')
            if 'rte' not in data['review_roles']:
                assert c.post(f'/api/streams/{sid}/map/reviews',headers=h,json={'expected_version':version,'decision':'approve','comment':'I reviewed dependencies and queue times'}).status_code==403
            h=login(c,'admin')
            assert c.get(f'/api/streams/{sid}/map').status_code==403
            h=login(c,data['review_roles'][0])
            assert c.post(f'/api/streams/{sid}/map/reviews',headers=h,json={'expected_version':version,'decision':'decline','comment':''}).status_code==422
            assert c.post(f'/api/streams/{sid}/map/reviews',headers=h,json={'expected_version':9999,'decision':'approve','comment':'This is a stale, unapproved decision'}).status_code==409


def test_csv_source_keys_unique_linked_and_free_of_ambiguous_status():
    root=Path(__file__).resolve().parents[1]/'seed/maps'
    for name,keys in [
      ('step_evidence.csv',('stream_key','state','step_id')),
      ('role_review_guidance.csv',('stream_key','review_role')),
      ('workshop_questions.csv',('stream_key','agenda_order')),
    ]:
      with (root/name).open(newline='',encoding='utf-8') as f:rows=list(csv.DictReader(f))
      assert rows and all(all(cell.strip() for cell in row.values()) for row in rows)
      unique={tuple(row[key] for key in keys) for row in rows}
      assert len(unique)==len(rows)
      assert all(row['stream_key'] in {'underwriting','claims','cyber','servicing','risk','distribution'} for row in rows)
      if name=='step_evidence.csv':assert len(rows)==72 and all('Illustrative' in r['reported_basis'] for r in rows)
      if name=='role_review_guidance.csv':assert len(rows)==48
      if name=='workshop_questions.csv':assert len(rows)==30 and all('not_a_recorded_meeting' in r['status'] for r in rows)
