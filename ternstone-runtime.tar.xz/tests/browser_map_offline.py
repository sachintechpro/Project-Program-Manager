"""Local transport mock because Chromium blocks loopback network requests in this environment."""
import re
from pathlib import Path
from fastapi.testclient import TestClient
from playwright.sync_api import sync_playwright
from app.main import app
root=Path(__file__).resolve().parents[1]
with TestClient(app) as c:
    public=c.get('/api/public').json()
    data={}
    for role in ('program_manager','qa'):
        c.post('/api/login',json={'role':role})
        data[role]={}
        paths={'me':'/api/me','catalog':'/api/catalog','summary':'/api/summary','streams':'/api/streams','initiatives':'/api/initiatives','audit':'/api/audit?limit=6','connectors':'/api/connectors','help':'/api/help/catalog'}
        for key,url in paths.items():
            r=c.get(url);data[role][key]=r.json() if r.status_code==200 else []
        first=data[role]['streams'][0]
        data[role]['map']=c.get(f"/api/streams/{first['id']}/map").json()
html=(root/'app/static/index.html').read_text().replace('<script src="/assets/app.js"></script>','').replace('<script src="/assets/map_ui.js"></script>','').replace('<link rel="stylesheet" href="/assets/style.css">','')
css=re.sub(r'@import[^;]+;','',(root/'app/static/style.css').read_text())
source=(root/'app/static/app.js').read_text();map_source=(root/'app/static/map_ui.js').read_text()
with sync_playwright() as pw:
    b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    for name,w in [('desktop',1450),('mobile',390)]:
        page=b.new_page(viewport={'width':w,'height':860})
        errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
        page.set_content(html,wait_until='domcontentloaded')
        page.add_style_tag(content=css)
        page.evaluate('''({data,publicData})=>{
            window.__role='program_manager';window.__data=data;window.__public=publicData;
            window.EventSource=class{constructor(){} close(){}};
            window.fetch=async(url,opts={})=>{
                if(url==='/api/public')return new Response(JSON.stringify(window.__public),{status:200});
                if(url==='/api/login'){window.__role=JSON.parse(opts.body).role;return new Response(JSON.stringify({csrf:'fake'}),{status:200})}
                const paths={'/api/me':'me','/api/catalog':'catalog','/api/summary':'summary','/api/streams':'streams','/api/initiatives':'initiatives','/api/audit?limit=6':'audit','/api/connectors':'connectors','/api/help/catalog':'help'};
                if(paths[url])return new Response(JSON.stringify(window.__data[window.__role][paths[url]]),{status:200});
                if(url.startsWith('/api/streams/')&&url.endsWith('/map'))return new Response(JSON.stringify(window.__data[window.__role]['map']),{status:200});
                if(url.startsWith('/api/help/chat'))return new Response(JSON.stringify({role:window.__role,answer:'Map the customer outcome and review the bottleneck.',mode:'guided',followups:[],action_page:'value_map'}),{status:200});
                return new Response(JSON.stringify({detail:'Not in mocked browser scenario: '+url}),{status:404});
            };
        }''',{'data':data,'publicData':public})
        page.add_script_tag(content=map_source)
        page.add_script_tag(content=source)
        page.wait_for_timeout(200)
        if name=='mobile':page.locator('#menu-toggle').click()
        page.locator('nav button[data-page="streams"]').click()
        page.locator('[data-map-stream]').first.wait_for()
        page.locator('[data-map-stream]').first.click()
        page.locator('.vsm-tabs').wait_for()
        assert 'Define value' in page.locator('#view').inner_text()
        page.screenshot(path=str(root/f'vsm_{name}_define.png'),full_page=True)
        for t in ('workshop','current','improve','future','validate'):
            page.locator(f'[data-vsm-tab="{t}"]').click()
            page.wait_for_timeout(110)
            if t=='current':
                assert page.locator('.vsm-flow-step').count()==6
                page.screenshot(path=str(root/f'vsm_{name}_current.png'),full_page=True)
            if t=='improve':
                assert page.locator('.vsm-recommend').count()==3
                page.screenshot(path=str(root/f'vsm_{name}_bottlenecks.png'),full_page=True)
        page.locator('[data-vsm-tab="workshop"]').click()
        page.locator('[data-vsm-new-meeting]').click()
        assert page.locator('[data-vsm-form="meeting"]').is_visible()
        assert page.locator('input[name="meeting_date"]').is_visible()
        assert not errs,errs
        print(name,'OK', 'bubble',page.locator('[data-map-stream]').count(),'fields',page.locator('[data-vsm-form="meeting"]').count())
        page.close()
    b.close()
