import json,os,zipfile,io,subprocess,sys
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app
def sign_as(client,role):
    r=client.post('/api/login',json={'role':role});assert r.status_code==200,r.text
    return {'X-CSRF-Token':r.json()['csrf']}

def test_schema_tables_and_all_stakeholder_actions():
    root=Path(__file__).parents[1]
    p=subprocess.run([sys.executable,str(root/'scripts'/'validate_reference_csv.py')],capture_output=True,text=True,check=True,cwd=root)
    assert 'VALIDATED' in p.stdout
    import csv
    with (root/'seed'/'data'/'role_approval_controls.csv').open() as f:roles=list(csv.DictReader(f))
    assert len(roles)==29 and len({x['role'] for x in roles})==29
    with TestClient(app) as c:
        assert len(c.get('/api/public').json()['personas'])==29
        for x in roles:
            sign_as(c,x['role'])
            resp=c.get('/api/control-reviews');assert resp.status_code==200,resp.text
            assert all(y['control']['role']==x['role'] for y in resp.json())

def test_scenario_binding_edit_security_trace_and_export():
    with TestClient(app) as c:
        h=sign_as(c,'program_manager')
        streams=c.get('/api/streams').json()
        stream=next(x for x in streams if x['key']=='underwriting')
        base={'stream_id':stream['id'],'template':'wc-submission','title':'Workers Compensation new submission quality gate','lob':'Workers Compensation','budget':420000,'annual_benefit':920000,'baseline':11.8,'target':6.2,'unit':'days','volume':'4,200 submissions / month','workflow':'Broker → validation → review → quote','rules':'Preserve underwriter authority','risk':'Data quality','dependencies':'Producer portal'}
        r=c.post('/api/initiatives',headers=h,json=base);assert r.status_code==200,r.text;id=r.json()['id']
        d=c.get(f'/api/initiatives/{id}/reference');assert d.status_code==200
        data=d.json();assert data['template_key']=='wc-submission';assert len(data['tables']['test_cases'])==10
        assert all(x['execution_status']=='not_run' for x in data['tables']['test_cases'])
        row=data['tables']['business_rules'][0];assert row['__can_edit'];rid=row['__record_id']
        fields={k:v for k,v in row.items() if not k.startswith('__')}
        fields['rule_description']='Route any missing classification or payroll evidence to an authorized underwriter.'
        bad=sign_as(c,'qa')
        assert c.put('/api/scenario-records/'+str(rid),headers=bad,json={'expected_version':1,'fields':fields}).status_code==403
        h=sign_as(c,'program_manager')
        save=c.put('/api/scenario-records/'+str(rid),headers=h,json={'expected_version':1,'fields':fields});assert save.status_code==200,save.text
        assert save.json()['version']==2
        assert c.put('/api/scenario-records/'+str(rid),headers=h,json={'expected_version':1,'fields':fields}).status_code==409
        exported=c.get(f'/api/initiatives/{id}/reference-export');assert exported.status_code==200
        with zipfile.ZipFile(io.BytesIO(exported.content)) as z:
            assert 'business_rules.csv' in z.namelist()
            assert 'Route any missing classification' in z.read('business_rules.csv').decode()
        author=sign_as(c,'epic_owner')
        assert c.post(f'/api/initiatives/{id}/generate',headers=author).status_code==200
        art=c.get(f'/api/initiatives/{id}').json()['artifacts'][0]
        assert 'Initiative-specific reference data' in art['markdown']
        assert 'Operational workflow steps' in art['markdown']
        assert c.get('/api/audit/verify').json()['valid']

def test_control_roles_and_stale_approval():
    with TestClient(app) as c:
        h=sign_as(c,'epic_owner')
        stream=next(x for x in c.get('/api/streams').json() if x['key']=='underwriting')
        r=c.post('/api/initiatives',headers=h,json={'stream_id':stream['id'],'title':'Approval controls provenance pilot'});assert r.status_code==200
        iid=r.json()['id'];assert c.post(f'/api/initiatives/{iid}/generate',headers=h).status_code==200
        sign_as(c,'program_manager')
        info=c.get(f'/api/initiatives/{iid}/control-reviews').json();vmo=next(x for x in info['controls'] if x['role']=='vmo')
        wrong=sign_as(c,'qa')
        r=c.post(f"/api/initiatives/{iid}/control-reviews/{vmo['control_code']}",headers=wrong,json={'decision':'approved','expected_stage':'portfolio','input_digest':vmo['input_digest']});assert r.status_code==403
        v=sign_as(c,'vmo')
        r=c.post(f"/api/initiatives/{iid}/control-reviews/{vmo['control_code']}",headers=v,json={'decision':'approved','expected_stage':'portfolio','input_digest':vmo['input_digest'],'comment':'Reviewed approved requirements and traceable portfolio intake.'});assert r.status_code==200 and r.json()['advanced'] is False
        a=c.get(f'/api/initiatives/{iid}').json()['artifacts'][0]
        author=sign_as(c,'epic_owner')
        content=a['markdown']+'\n## Revised risk\nExplicit business approval is required.\n'
        r=c.put(f"/api/artifacts/{a['id']}",headers=author,json={'markdown':content,'expected_version':a['version']});assert r.status_code==200
        sign_as(c,'program_manager')
        reviewed=c.get(f'/api/initiatives/{iid}/control-reviews').json()
        vm=next(x for x in reviewed['controls'] if x['role']=='vmo');assert vm['decision']=='pending' and not vm['evidence_current']
        # Changing the upstream artifact invalidates existing control decisions.
        stale=sign_as(c,'vmo')
        assert c.post(f"/api/initiatives/{iid}/control-reviews/{vm['control_code']}",headers=stale,json={'decision':'approved','expected_stage':'portfolio','input_digest':vmo['input_digest']}).status_code==409

def test_author_edit_reconciles_budget_and_metric_without_claiming_results():
    with TestClient(app) as c:
        h=sign_as(c,'program_manager')
        v=next(x for x in c.get('/api/streams').json() if x['key']=='underwriting')
        req={'stream_id':v['id'],'template':'wc-submission','title':'Workers Compensation cycle improvement','lob':'Workers Compensation','budget':390000,'annual_benefit':780000,'baseline':11.0,'target':5.5,'unit':'days','volume':'4,000 submissions / month','workflow':'Broker submission → authorized review','rules':'Underwriting decides quotes','risk':'Incorrect rules','dependencies':'Policy system'}
        response=c.post('/api/initiatives',json=req,headers=h)
        assert response.status_code==200,response.text
        iid=response.json()['id']
        ref=c.get(f'/api/initiatives/{iid}/reference').json()['tables']
        assert sum(int(x['planned_cost_usd']) for x in ref['cost_estimates'])==390000
        assert ref['metrics'][0]['baseline_value']=='11.0'
        cost=ref['cost_estimates'][0]; rid=cost['__record_id']
        vals={k:v for k,v in cost.items() if not k.startswith('__')}
        vals['planned_cost_usd']=str(int(vals['planned_cost_usd'])+1000)
        result=c.put(f'/api/scenario-records/{rid}',headers=h,json={'expected_version':1,'fields':vals})
        assert result.status_code==200,result.text
        i=c.get(f'/api/initiatives/{iid}').json()['initiative']; assert int(i['budget'])==391000
        rows=c.get(f'/api/initiatives/{iid}/reference').json()['tables']
        assert sum(int(x['planned_cost_usd']) for x in rows['cost_estimates'])==int(i['budget'])
        m=rows['metrics'][0]
        mfields={k:v for k,v in m.items() if not k.startswith('__')}
        mfields['baseline_value']='12.0';mfields['target_value']='5.0'
        upd=c.put(f"/api/scenario-records/{m['__record_id']}",headers=h,json={'expected_version':1,'fields':mfields})
        assert upd.status_code==200,upd.text
        i=c.get(f'/api/initiatives/{iid}').json()['initiative']
        assert float(i['baseline'])==12.0 and float(i['target'])==5.0
        assert c.get(f'/api/initiatives/{iid}/reference').json()['tables']['metrics'][0]['actual_status']=='unmeasured'
        h=sign_as(c,'qa'); restricted=c.get(f'/api/initiatives/{iid}/reference').json()['tables']
        assert 'cost_estimates' not in restricted
        assert c.get('/api/audit/verify').json()['valid']
