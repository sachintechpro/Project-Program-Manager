from fastapi.testclient import TestClient
from app.main import app


def sign(c,role):
    r=c.post('/api/login',json={'role':role});assert r.status_code==200,r.text
    return {'X-CSRF-Token':r.json()['csrf']}


def test_pm_can_start_and_edit_new_stream_and_initiative():
    with TestClient(app) as c:
        h=sign(c,'program_manager')
        assert c.get('/api/me').json()['permissions']['create_stream']
        r=c.post('/api/streams',headers=h,json={'name':'New Commercial Operations Stream','lob':'Workers Compensation','owner':'Operations Leadership','description':'End-to-end servicing delivery','theme':'Cut approval queues','metric':'Cycle days','baseline':15,'target':8,'budget':210000});assert r.status_code==200,r.text
        sid=r.json()['id']
        v=next(x for x in c.get('/api/streams').json() if x['id']==sid)
        assert v['edit_meta']['can_edit'] and v['edit_meta']['version']==1
        update={k:v[k] for k in ('name','lob','owner','description','theme','metric','baseline','target','budget')};update.update({'expected_version':1,'target':6})
        r=c.put(f'/api/streams/{sid}',headers=h,json=update);assert r.status_code==200,r.text
        assert r.json()['edit_meta']['version']==2
        assert c.put(f'/api/streams/{sid}',headers=h,json=update).status_code==409
        x=c.post('/api/initiatives',headers=h,json={'stream_id':sid,'title':'Commercial servicing end-to-end improvement','lob':'Workers Compensation'});assert x.status_code==200,x.text
        iid=x.json()['id']
        i=c.get(f'/api/initiatives/{iid}').json()['initiative'];assert i['edit_meta']['can_edit']
        update={k:i[k] for k in ('title','lob','budget','annual_benefit','baseline','target','unit','volume','workflow','rules','risk','dependencies')};update.update({'expected_version':1,'target':4})
        r=c.put(f'/api/initiatives/{iid}',headers=h,json=update);assert r.status_code==200,r.text
        assert r.json()['edit_meta']['version']==2
        # Non-authors cannot make changes, even though they can read.
        sign(c,'qa');assert c.put(f'/api/initiatives/{iid}',headers={'X-CSRF-Token':c.get('/api/me').json()['csrf']},json=update).status_code==403
        sign(c,'lpm');assert c.get(f'/api/initiatives/{iid}').json()['initiative']['edit_meta']['can_edit'] is False
        assert c.put(f'/api/initiatives/{iid}',headers={'X-CSRF-Token':c.get('/api/me').json()['csrf']},json=update).status_code==403
        # Portfolio approval creates a controlled baseline; this is not silently rewritten.
        h=sign(c,'epic_owner');assert c.post(f'/api/initiatives/{iid}/generate',headers=h).status_code==200
        d=c.get(f'/api/initiatives/{iid}').json()
        art=next(a for a in d['artifacts'] if a['kind']=='portfolio-epic')
        h=sign(c,'lpm');assert c.post(f"/api/artifacts/{art['id']}/review",headers=h,json={'decision':'approved','expected_version':art['version']}).status_code==200
        h=sign(c,'program_manager');assert c.put(f'/api/initiatives/{iid}',headers=h,json={**update,'expected_version':2}).status_code==409


def test_raci_raid_author_only_and_markdown_history():
    with TestClient(app) as c:
        h=sign(c,'program_manager')
        sid=c.get('/api/streams').json()[0]['id']
        r=c.post('/api/registers',headers=h,json={'kind':'raci','value_stream_id':sid,'title':'Quote and bind workflow approval','fields':{'responsible':['fde','product_owner'],'accountable':['value_owner'],'consulted':['actuarial'],'informed':['qa','ops']}})
        assert r.status_code==200,r.text
        rid=r.json()['id'];assert r.json()['can_edit']
        q=c.get('/api/registers?kind=raci').json();assert any(x['id']==rid for x in q)
        upd={'expected_version':1,'title':'Quote and bind integration approval','fields':{'responsible':['fde'],'accountable':['value_owner'],'consulted':['actuarial','qa'],'informed':['ops']}}
        u=c.put(f'/api/registers/{rid}',headers=h,json=upd);assert u.status_code==200,u.text
        assert u.json()['version']==2
        assert c.put(f'/api/registers/{rid}',headers=h,json=upd).status_code==409
        rev=c.get(f'/api/registers/{rid}/revisions').json();assert [r['version'] for r in rev]==[1,2]
        md=c.get(f'/api/registers/{rid}/download');assert md.status_code==200 and b'Quote and bind integration approval' in md.content
        r=c.post('/api/registers',headers=h,json={'kind':'raid','value_stream_id':sid,'title':'External rating engine dependency','fields':{'type':'dependency','status':'open','priority':'high','owner_role':'integration','response':'Validate API SLA and fallback','due_date':'2027-01-31','evidence_ref':'PRD-10'}})
        assert r.status_code==200,r.text
        raid=r.json()['id']
        # Other authorized roles can read, not edit or override author.
        other=sign(c,'qa')
        assert c.get('/api/registers?kind=raci').status_code==200
        assert next(x for x in c.get('/api/registers?kind=raid').json() if x['id']==raid)['can_edit'] is False
        assert c.put(f'/api/registers/{rid}',headers=other,json=upd).status_code==403
        other=sign(c,'rte')
        assert c.put(f'/api/registers/{raid}',headers=other,json={'expected_version':1,'title':'Unauthorized edit','fields':{'type':'risk','status':'open','priority':'low','owner_role':'qa','response':''}}).status_code==403
        sign(c,'admin')
        assert c.get('/api/registers').status_code==403
        assert c.get(f'/api/registers/{rid}/download').status_code==403


def test_raci_validation_and_initiative_export():
    with TestClient(app) as c:
        h=sign(c,'program_manager')
        sid=c.get('/api/streams').json()[0]['id']
        invalid=c.post('/api/registers',headers=h,json={'kind':'raci','value_stream_id':sid,'title':'Invalid multiple accountability','fields':{'responsible':['fde'],'accountable':['qa','lpm'],'consulted':[],'informed':[]}})
        assert invalid.status_code==422
        iid=c.get('/api/initiatives').json()[0]['id']
        r=c.post('/api/registers',headers=h,json={'kind':'raid','initiative_id':iid,'title':'Program release dependency','fields':{'type':'dependency','status':'open','priority':'medium','owner_role':'release','response':'Confirm downstream readiness'}})
        assert r.status_code==200,r.text
        data=c.get(f'/api/initiatives/{iid}/export');assert data.status_code==200
        import io,zipfile
        with zipfile.ZipFile(io.BytesIO(data.content)) as z:
            assert any(f'management/raid-{r.json()["id"]}-v1.md'==n for n in z.namelist())
        assert c.get('/api/audit/verify').json()['valid']
