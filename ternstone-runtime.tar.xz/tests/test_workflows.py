import os
os.environ['DEMO_MODE']='true'
os.environ['DATABASE_URL']='sqlite:///./test_valueops.db'
os.environ['SECRET_KEY']='test-only-secret-key'
from fastapi.testclient import TestClient
from app.main import app


def sign_as(client,role):
    r=client.post('/api/login',json={'role':role});assert r.status_code==200,r.text
    csrf=r.json()['csrf']
    return {'X-CSRF-Token':csrf}

def test_domain_catalog_and_rbac():
    with TestClient(app) as c:
        assert c.get('/health').json()['status']=='ok'
        assert c.get('/api/streams').status_code==401
        headers=sign_as(c,'qa')
        s=c.get('/api/streams').json();assert len(s)>=6
        assert c.post('/api/streams',json={'name':'Unauthorized stream'},headers=headers).status_code==403
        rows=c.get('/api/initiatives').json();assert len(rows)>=9
        assert any('Cyber' in r['title'] for r in rows)
        assert len(c.get('/api/catalog').json()['roles'])>=25


def test_full_approval_chain_and_evidence_export():
    with TestClient(app) as c:
        h=sign_as(c,'epic_owner')
        stream=c.get('/api/streams').json()[0]
        body={'stream_id':stream['id'],'title':'Multi-line exception resolution quality improvement','lob':'Specialty Commercial','budget':120000,'annual_benefit':190000,'baseline':10,'target':5,'unit':'days','volume':'500 cases / month','workflow':'Intake -> verify -> human approve -> notify','rules':'Manual business signoff is mandatory','risk':'Privacy and audit risk','dependencies':'Claims, policy, payment integration'}
        r=c.post('/api/initiatives',json=body,headers=h);assert r.status_code==200,r.text
        iid=r.json()['id']
        stages=c.get('/api/catalog').json()['stages']
        for si,stage in enumerate(stages):
            h=sign_as(c,stage['owner']);g=c.post(f'/api/initiatives/{iid}/generate',headers=h);assert g.status_code==200,g.text
            d=c.get(f'/api/initiatives/{iid}').json()
            assert d['initiative']['current_stage']==stage['id']
            for j,(kind,_,writer,reviewer) in enumerate(stage['artifacts']):
                art=next(x for x in d['artifacts'] if x['kind']==kind)
                bad=sign_as(c,'customer_care')
                assert c.post(f"/api/artifacts/{art['id']}/review",headers=bad,json={'decision':'approved','comment':'Unauthorized','expected_version':art['version']}).status_code==403
                h=sign_as(c,reviewer)
                res=c.post(f"/api/artifacts/{art['id']}/review",headers=h,json={'decision':'approved','comment':'Demo evidence reviewed; synthetic only','expected_version':art['version']});assert res.status_code==200,res.text
                assert res.json()['advanced'] is False  # contracts alone cannot bypass the role controls
            h=sign_as(c,'program_manager')
            control_info=c.get(f'/api/initiatives/{iid}/control-reviews').json()
            mandatory=[x for x in control_info['controls'] if x['mandatory']]
            assert mandatory
            for idx,control in enumerate(mandatory):
                role=control['role'];h=sign_as(c,role)
                res=c.post(f"/api/initiatives/{iid}/control-reviews/{control['control_code']}",headers=h,json={
                    'decision':'approved','expected_stage':stage['id'],'input_digest':control['input_digest'],
                    'comment':'Independently checked the scenario documents and the assigned authority.'})
                assert res.status_code==200,res.text
                assert res.json()['advanced']==(idx==len(mandatory)-1)
            d=c.get(f'/api/initiatives/{iid}').json()
            assert d['initiative']['current_stage']==(stages[si+1]['id'] if si<len(stages)-1 else 'closed')
        r=c.get(f'/api/initiatives/{iid}/export');assert r.status_code==200 and r.content[:2]==b'PK'
        assert c.get('/api/audit/verify').json()['valid']


def test_versioning_and_stale_review():
    with TestClient(app) as c:
        h=sign_as(c,'epic_owner')
        sid=c.get('/api/streams').json()[0]['id']
        r=c.post('/api/initiatives',headers=h,json={'stream_id':sid,'title':'Test evidence history initiative'});assert r.status_code==200
        iid=r.json()['id'];c.post(f'/api/initiatives/{iid}/generate',headers=h)
        a=c.get(f'/api/initiatives/{iid}').json()['artifacts'][0]
        new=a['markdown']+'\n## Additional checks\nEvidence must be independently verifiable.\n'
        e=c.put('/api/artifacts/'+str(a['id']),headers=h,json={'markdown':new,'expected_version':1});assert e.status_code==200 and e.json()['version']==2
        h=sign_as(c,'lpm');bad=c.post('/api/artifacts/'+str(a['id'])+'/review',headers=h,json={'decision':'approved','expected_version':1});assert bad.status_code==409
        rev=c.get('/api/artifacts/'+str(a['id'])+'/revisions').json();assert len(rev)==2 and rev[0]['markdown']!=rev[1]['markdown']


def test_connectors_do_not_fake_live_connections():
    with TestClient(app) as c:
        h=sign_as(c,'admin')
        r=c.post('/api/connectors',headers=h,json={'provider':'github','mode':'simulated','config':{}});assert r.status_code==200
        r=c.post('/api/connectors/github/check',headers=h);assert r.status_code==200 and r.json()['mode']=='simulated'
        r=c.post('/api/connectors',headers=h,json={'provider':'github','mode':'live','config':{'repo':'org/repo','token':'example'}});assert r.status_code==422

def test_admin_user_provisioning_and_independent_approvals():
    with TestClient(app) as c:
        h=sign_as(c,'admin')
        unique='new.reviewer@ternstone.example'
        r=c.post('/api/users',headers=h,json={'name':'New Reviewer','email':unique,'role':'qa','password':'VeryStrongTest!2026'})
        if r.status_code==409:
            users=c.get('/api/users').json();assert any(x['email']==unique for x in users)
        else:assert r.status_code==200,r.text
        r=c.post('/api/login',json={'email':unique,'password':'VeryStrongTest!2026'});assert r.status_code==200
        assert c.get('/api/me').json()['role']=='qa'
        h=sign_as(c,'admin')
        assert len(c.get('/api/users').json())>=18
        # Platform administrators cannot override independent subject-matter approval roles.
        assert c.get('/api/approvals').json()==[]
        qa_headers=sign_as(c,'qa')
        mine=c.get('/api/approvals').json()
        assert mine and all(x['assigned_to_me'] for x in mine)
        art=mine[0]['artifact']
        h=sign_as(c,'admin')
        assert c.post(f"/api/artifacts/{art['id']}/review",headers=h,json={'decision':'approved','expected_version':art['version']}).status_code==403
