"""Browser UI smoke with mocked transport (browser blocks local network navigation)."""
import os,re
from pathlib import Path
from fastapi.testclient import TestClient
from playwright.sync_api import sync_playwright
from app.main import app
root=Path(__file__).resolve().parents[1]
with TestClient(app) as c:
    public=c.get('/api/public').json()
    data={}
    for role in ('program_manager','qa'):
        c.post('/api/login',json={'role':role})
        data[role]={}
        for key,url in [('me','/api/me'),('catalog','/api/catalog'),('summary','/api/summary'),('streams','/api/streams'),('initiatives','/api/initiatives'),('audit','/api/audit?limit=6'),('connectors','/api/connectors'),('help','/api/help/catalog')]:
            r=c.get(url)
            data[role][key]=r.json() if r.status_code==200 else []
html=(root/'app/static/index.html').read_text().replace('<script src="/assets/app.js"></script>','').replace('<link rel="stylesheet" href="/assets/style.css">','')
script=(root/'app/static/app.js').read_text()
css=re.sub(r'@import[^;]+;','',(root/'app/static/style.css').read_text())
out=root/'test-screens';out.mkdir(exist_ok=True)
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    for viewport,label in [({'width':1450,'height':960},'desktop'),({'width':390,'height':844},'mobile')]:
        page=browser.new_page(viewport=viewport)
        err=[];page.on('pageerror',lambda e:err.append(str(e)))
        page.set_content(html,wait_until='domcontentloaded',timeout=10000)
        page.add_style_tag(content=css)
        page.evaluate('''({data,pub})=>{
          window.__d=data;window.__p=pub;window.__role='program_manager';window.EventSource=class {constructor(){} close(){}};
          window.fetch=async(url,opts={})=>{
            if(url==='/api/public')return new Response(JSON.stringify(window.__p),{status:200});
            if(url==='/api/login'){window.__role=JSON.parse(opts.body||'{}').role;return new Response(JSON.stringify({csrf:'test'}),{status:200});}
            const m={'/api/me':'me','/api/catalog':'catalog','/api/summary':'summary','/api/streams':'streams','/api/initiatives':'initiatives','/api/audit?limit=6':'audit','/api/connectors':'connectors','/api/help/catalog':'help'};
            if(url==='/api/help/chat'){
              const ask=JSON.parse(opts.body);let text='Open your assigned queue and review current evidence.';
              if(window.__role==='qa'&&ask.question.toLowerCase().includes('budget'))text='Financial amounts are restricted for your role.';
              if(ask.field_key==='metric')text='The main measure of value stream performance. Example: Median days to bind.';
              return new Response(JSON.stringify({answer:text,mode:'guided',role:window.__role,followups:['Explain this page'],action_page:'dashboard'}),{status:200});
            }
            if(m[url])return new Response(JSON.stringify(window.__d[window.__role][m[url]]),{status:200});
            return new Response(JSON.stringify({detail:'Mock endpoint unavailable: '+url}),{status:404});
          };
        }''',{'data':data,'pub':public})
        page.add_script_tag(content=script)
        page.wait_for_timeout(250)
        assert 'Integrated delivery controls' in page.locator('main').inner_text()
        page.locator('#help-launch').click()
        assert 'Program / Project Manager' in page.locator('#help-context').inner_text()
        page.locator('#help-question').fill('What should I do next?')
        page.locator('#help-send').click()
        page.wait_for_timeout(100)
        assert 'assigned queue' in page.locator('#help-messages').inner_text()
        page.locator('#help-close').click()
        if label=='mobile':page.locator('#menu-toggle').click()
        page.locator('#menu button[data-page="streams"]').click()
        page.locator('button[data-toggle="new-stream"]').first.click()
        dots=page.locator('form[data-form="stream"] .help-dot').count()
        print(label,'field context buttons',dots)
        assert dots>=8
        page.locator('form[data-form="stream"] button[data-help-field="metric"]').click()
        assert 'main measure' in page.locator('#help-messages').inner_text().lower()
        assert 'Value streams' in page.locator('#help-context').inner_text()
        page.screenshot(path=str(out/f'help_{label}_stream.png'))
        page.locator('#help-close').click()
        if label=='mobile':page.locator('#menu-toggle').click()
        page.select_option('#persona-switch','qa')
        page.wait_for_timeout(180)
        assert page.locator('#help-messages .help-message').count()==0
        page.locator('#help-launch').click()
        assert 'QA / Validation Lead' in page.locator('#help-context').inner_text()
        page.locator('#help-question').fill('Show the budget amount for this initiative')
        page.locator('#help-send').click();page.wait_for_timeout(100)
        assert 'restricted' in page.locator('#help-messages').inner_text().lower()
        page.screenshot(path=str(out/f'help_{label}_qa.png'))
        assert not err,err
        print(label,'PASS','JS_ERRORS',err)
        page.close()
    browser.close()
