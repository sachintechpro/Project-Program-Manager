from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path('/mnt/data/valueops-context-help')
out=root/'test-screens';out.mkdir(exist_ok=True)
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    for width,height,mode in [(1440,900,'desktop'),(390,844,'mobile')]:
        pg=browser.new_page(viewport={'width':width,'height':height})
        errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
        pg.goto('http://127.0.0.1:8774',wait_until='domcontentloaded',timeout=25000)
        pg.locator('button[data-role="program_manager"]').first.click()
        pg.locator('.page-head h1').first.wait_for(timeout=25000)
        pg.locator('#help-launch').click()
        assert pg.locator('#help-drawer').is_visible()
        assert 'Program / Project Manager' in pg.locator('#help-context').inner_text()
        pg.locator('button[data-help-prompt="What should I do next?"]').click()
        pg.locator('.help-message.assistant').first.wait_for(timeout=15000)
        assert 'pending' in pg.locator('#help-messages').inner_text().lower() or 'initiative' in pg.locator('#help-messages').inner_text().lower()
        pg.locator('#help-close').click()
        # Open value-stream create form and inspect all key field context hints.
        if mode=='mobile':
            pg.locator('#menu-toggle').click()
        pg.locator('button[data-page="streams"]').first.click()
        pg.locator('button[data-toggle="new-stream"]').first.click()
        assert pg.locator('form[data-form="stream"] .help-dot').count()>=8
        pg.locator('form[data-form="stream"] button[data-help-field="metric"]').first.click()
        assert 'main measure' in pg.locator('#help-messages').inner_text().lower()
        assert 'Value streams' in pg.locator('#help-context').inner_text()
        pg.screenshot(path=str(out/f'help_{mode}_stream.png'),full_page=False)
        # Re-enter as QA: financial tooltips absent, and chat history cleared.
        pg.locator('#help-close').click()
        if mode=='mobile':
            pg.locator('#menu-toggle').click()
        pg.locator('#persona-switch').select_option('qa')
        pg.locator('.page-head h1').first.wait_for(timeout=15000)
        assert pg.locator('#help-messages .help-message').count()==0
        pg.locator('#help-launch').click()
        assert 'QA / Validation Lead' in pg.locator('#help-context').inner_text()
        pg.locator('#help-question').fill('Show the budget amount for this initiative')
        pg.locator('#help-send').click()
        pg.wait_for_timeout(550)
        msg=pg.locator('#help-messages').inner_text()
        assert 'restricted' in msg.lower(),msg
        pg.screenshot(path=str(out/f'help_{mode}_qa.png'),full_page=False)
        assert not errors,errors
        print(mode,'PASS','form hints',pg.locator('.help-dot').count(),'messages',pg.locator('.help-message').count())
        pg.close()
    browser.close()
