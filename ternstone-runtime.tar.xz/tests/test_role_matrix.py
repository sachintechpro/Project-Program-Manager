"""Behavioral permission matrix checks covering every modeled stakeholder role."""
from fastapi.testclient import TestClient
from app.main import app
from app.catalog import ROLES,DEMO_USERS,STAGES
from app.role_policy import (ROLE_DOCS,ROLE_WORKSPACES,VIEW_CONNECTORS,MANAGE_CONNECTORS,APPROVAL_OVERSIGHT,AUDIT_VIEW,CREATE_INITIATIVE,CREATE_STREAM)


def sign(c,role):
    r=c.post('/api/login',json={'role':role});assert r.status_code==200,(role,r.text)
    return {'X-CSRF-Token':r.json()['csrf']}


def test_29_roles_are_dedicated_and_demo_selectable():
    assert len(ROLES)==29
    assert {r[0] for r in ROLES}==set(ROLE_DOCS)==set(ROLE_WORKSPACES)
    assert {r[0] for r in ROLES}=={r[1] for r in DEMO_USERS}
    with TestClient(app) as c:
        p=c.get('/api/public').json()
        assert len(p['personas'])==29
        assert len(p['roles'])==29
        for rid, *_ in ROLES:
            h=sign(c,rid)
            me=c.get('/api/me').json()
            assert me['role']==rid
            assert me['accessible_artifact_kinds']==sorted(ROLE_DOCS[rid])
            assert me['permissions']['create_stream']==(rid in CREATE_STREAM)
            assert me['permissions']['create_initiative']==(rid in CREATE_INITIATIVE)
            assert me['permissions']['view_connectors']==(rid in VIEW_CONNECTORS)
            assert me['permissions']['manage_connectors']==(rid in MANAGE_CONNECTORS)
            c.post('/api/logout',headers=h)


def test_role_scoped_document_visibility_and_queue_ownership():
    with TestClient(app) as c:
        sign(c,'lpm')
        everything=c.get('/api/artifacts').json()
        kinds={r['artifact']['kind'] for r in everything}
        assert set(kinds)==(set(k for stage in STAGES for k,*_ in stage['artifacts']) & ROLE_DOCS['lpm'])
        for role,*_ in ROLES:
            h=sign(c,role)
            visible=c.get('/api/artifacts').json()
            assert all(a['artifact']['kind'] in ROLE_DOCS[role] for a in visible)
            assert set(r['artifact']['kind'] for r in visible).issubset(ROLE_DOCS[role])
            pending=c.get('/api/approvals').json()
            if role not in APPROVAL_OVERSIGHT:
                assert all(x['assigned_to_me'] and x['artifact']['reviewer']==role for x in pending)
            else:
                assert all(x['artifact']['kind'] in ROLE_DOCS[role] for x in pending)
            for name,path,allowed in [
                ('connector','/api/connectors',role in VIEW_CONNECTORS),
                ('audit','/api/audit',role in AUDIT_VIEW),
                ('insights','/api/insights',role in {'executive','lpm','vmo','finance','epic_owner','business_owner','value_owner','product_manager','program_manager','analytics'}),
            ]:
                res=c.get(path)
                assert res.status_code==(200 if allowed else 403),(role,name,res.status_code)
            c.post('/api/logout',headers=h)
        # Direct document URL is protected, not merely hidden in the browser.
        sign(c,'lpm')
        restricted=next(a['artifact'] for a in everything if a['artifact']['kind']=='lean-business-case')
        sign(c,'qa')
        assert c.get('/api/artifacts/'+str(restricted['id'])+'/download').status_code==403
        assert c.get('/api/artifacts/'+str(restricted['id'])+'/revisions').status_code==403


def test_admin_cannot_publish_an_artifact_outside_its_read_scope():
    with TestClient(app) as c:
        sign(c,'lpm')
        contract=next(x['artifact'] for x in c.get('/api/artifacts').json() if x['artifact']['kind']=='lean-business-case' and x['artifact']['status']=='approved')
        h=sign(c,'admin')
        assert c.post('/api/connectors',json={'provider':'github','mode':'simulated','config':{}},headers=h).status_code==200
        res=c.post('/api/connectors/publish',json={'artifact_id':contract['id'],'provider':'github'},headers=h)
        assert res.status_code==403,res.text
        assert c.get('/api/artifacts').json()==[]
        assert c.get('/api/initiatives').status_code==403
        assert c.get('/api/streams').status_code==403
        assert c.get('/api/initiatives/1/export').status_code==403


def test_quality_role_excludes_financial_records_and_enforces_approvals():
    with TestClient(app) as c:
        h=sign(c,'qa')
        for route in ['/api/summary','/api/streams','/api/initiatives','/api/initiatives/1']:
            data=c.get(route).json()
            if isinstance(data,list):assert all('budget' not in item and 'annual_benefit' not in item for item in data)
            elif route.endswith('/summary'):assert 'total_budget' not in data
            else:
                assert 'budget' not in data['initiative']
                assert 'budget' not in data['value_stream']
        assert c.get('/api/insights').status_code==403
        assert all(a['artifact']['kind'] not in ('portfolio-epic','lean-business-case','benefits-report') for a in c.get('/api/artifacts').json())
        assert c.get('/api/approvals').status_code==200
        # A QA reviewer cannot assume a Product Manager's authority.
        sign(c,'product_manager')
        pending=c.get('/api/approvals').json()
        assert all(x['assigned_to_me'] for x in pending)
