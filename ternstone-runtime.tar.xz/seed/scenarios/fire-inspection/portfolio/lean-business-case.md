---
schema: lean-business-case/v1
scenario_id: fire-inspection
stage: portfolio
author_role: epic_owner
reviewer_role: finance
status: sample_only
---

# Lean business case & funding

## Investment decision
Requested implementation budget: $190,000 (illustrative).
Expected annualized benefit: $330,000 (illustrative; subject to validation).

## Benefit hypothesis
median process time from 14 to 6 days

## Operational baseline
2,300 risk inspections / year

## Economic assumptions
This is a modeled scenario. Finance must validate unit costs, cost avoidance vs. cash savings, operating expenses and attribution.

## Risk and contingency
Risk recommendations must not be presented as legally binding policy conditions without authority.

## Funding guardrails
Capacity and expenditure stay within approved limits; material changes return to portfolio approval.
