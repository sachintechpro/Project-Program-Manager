---
schema: portfolio-epic/v1
scenario_id: fire-inspection
stage: portfolio
author_role: epic_owner
reviewer_role: lpm
status: sample_only
---

# Epic / investment hypothesis

## Strategic alignment
Turn prevention intelligence into measurable loss control

## Business opportunity
Reduce cycle time and prevent avoidable handoffs in Commercial Property • Construction through commercial property fire prevention inspection workflow.

## Investment hypothesis
If we deliver this capability, we expect to move median process time from 14 to 6 days, with estimated annual benefit $330,000 (illustrative).

## Scope boundaries
Underwriter referral → assign engineer → field inspection → hazard recommendations → insured follow-up → status update

## Dependencies
Risk engineering portal, mobile app, document management

## Portfolio Kanban
Reviewed against strategic themes, available capacity, flow impact and compliance constraints.
