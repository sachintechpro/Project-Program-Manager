---
schema: brd/v1
scenario_id: fire-inspection
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Business objective
Reduce cycle time and prevent avoidable handoffs in Commercial Property • Construction through commercial property fire prevention inspection workflow.

## Operational value stream workflow
Underwriter referral → assign engineer → field inspection → hazard recommendations → insured follow-up → status update

## Business rules
Track sprinkler, electrical, combustible storage and business continuity recommendations; retain specialist signoff.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 14 to 6 days. Volume: 2,300 risk inspections / year.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
