---
schema: brd/v1
scenario_id: broker-evidence
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Business objective
Reduce cycle time and prevent avoidable handoffs in Commercial & Specialty Multi-line through broker self-service evidence and status center.

## Operational value stream workflow
Authenticated producer searches case → retrieves policy documents → submits inquiry → receives tracked status

## Business rules
Enforce producer-book-of-business access; keep customer data segregated.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 4.6 to 1.8 days. Volume: 3,100 broker inquiries / month.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
