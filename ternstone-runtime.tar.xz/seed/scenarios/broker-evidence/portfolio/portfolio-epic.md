---
schema: portfolio-epic/v1
scenario_id: broker-evidence
stage: portfolio
author_role: epic_owner
reviewer_role: lpm
status: sample_only
---

# Epic / investment hypothesis

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Strategic alignment
Improve broker self-service and producer responsiveness

## Business opportunity
Reduce cycle time and prevent avoidable handoffs in Commercial & Specialty Multi-line through broker self-service evidence and status center.

## Investment hypothesis
If we deliver this capability, we expect to move median process time from 4.6 to 1.8 days, with estimated annual benefit $480,000 (illustrative).

## Scope boundaries
Authenticated producer searches case → retrieves policy documents → submits inquiry → receives tracked status

## Dependencies
Producer IAM, policy admin, CRM, document store

## Portfolio Kanban
Reviewed against strategic themes, available capacity, flow impact and compliance constraints.
