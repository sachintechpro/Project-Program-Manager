---
schema: lean-business-case/v1
scenario_id: broker-evidence
stage: portfolio
author_role: epic_owner
reviewer_role: finance
status: sample_only
---

# Lean business case & funding

## Investment decision
Requested implementation budget: $255,000 (illustrative).
Expected annualized benefit: $480,000 (illustrative; subject to validation).

## Benefit hypothesis
median process time from 4.6 to 1.8 days

## Operational baseline
3,100 broker inquiries / month

## Economic assumptions
This is a modeled scenario. Finance must validate unit costs, cost avoidance vs. cash savings, operating expenses and attribution.

## Risk and contingency
Producer authorization and accidental disclosure.

## Funding guardrails
Capacity and expenditure stay within approved limits; material changes return to portfolio approval.
