---
schema: portfolio-epic/v1
scenario_id: wc-submission
stage: portfolio
author_role: epic_owner
reviewer_role: lpm
status: sample_only
---

# Epic / investment hypothesis

## Strategic alignment
Faster quote-to-bind with controlled underwriting

## Business opportunity
Reduce cycle time and prevent avoidable handoffs in Workers Compensation through workers compensation submission completeness & appetite check.

## Investment hypothesis
If we deliver this capability, we expect to move median process time from 11.8 to 6.2 days, with estimated annual benefit $920,000 (illustrative).

## Scope boundaries
Broker submits ACORD forms and payroll/class-code data → clearance → completeness → appetite → underwriter review → quote

## Dependencies
Broker portal, policy administration, underwriting rules, producer IAM

## Portfolio Kanban
Reviewed against strategic themes, available capacity, flow impact and compliance constraints.
