---
schema: lean-business-case/v1
scenario_id: wc-submission
stage: portfolio
author_role: epic_owner
reviewer_role: finance
status: sample_only
---

# Lean business case & funding

## Investment decision
Requested implementation budget: $420,000 (illustrative).
Expected annualized benefit: $920,000 (illustrative; subject to validation).

## Benefit hypothesis
median process time from 11.8 to 6.2 days

## Operational baseline
4,200 submissions / month

## Economic assumptions
This is a modeled scenario. Finance must validate unit costs, cost avoidance vs. cash savings, operating expenses and attribution.

## Risk and contingency
Incorrect appetite filtering could exclude eligible accounts or bypass underwriter review.

## Funding guardrails
Capacity and expenditure stay within approved limits; material changes return to portfolio approval.
