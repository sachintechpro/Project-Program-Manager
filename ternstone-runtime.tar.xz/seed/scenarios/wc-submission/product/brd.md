---
schema: brd/v1
scenario_id: wc-submission
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

## Business objective
Reduce cycle time and prevent avoidable handoffs in Workers Compensation through workers compensation submission completeness & appetite check.

## Operational value stream workflow
Broker submits ACORD forms and payroll/class-code data → clearance → completeness → appetite → underwriter review → quote

## Business rules
Require FEIN, state, class code, payroll, loss runs and effective date; flag prohibited classes; route exceptions to underwriter.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 11.8 to 6.2 days. Volume: 4,200 submissions / month.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
