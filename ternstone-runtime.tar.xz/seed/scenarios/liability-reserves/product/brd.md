---
schema: brd/v1
scenario_id: liability-reserves
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

## Business objective
Reduce cycle time and prevent avoidable handoffs in General Liability through general liability reserve evidence coordination.

## Operational value stream workflow
Claim received → liability investigation → supporting evidence → reserve recommendation → adjuster approval → finance updates

## Business rules
Never approve reserves automatically; retain adjuster review and reserve authority thresholds.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 7.4 to 3.2 days. Volume: 6,400 liability claims / year.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
