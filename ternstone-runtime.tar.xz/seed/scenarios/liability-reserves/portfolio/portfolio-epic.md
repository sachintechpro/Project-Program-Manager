---
schema: portfolio-epic/v1
scenario_id: liability-reserves
stage: portfolio
author_role: epic_owner
reviewer_role: lpm
status: sample_only
---

# Epic / investment hypothesis

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Strategic alignment
Reduce claim cycle time while protecting reserve and coverage quality

## Business opportunity
Reduce cycle time and prevent avoidable handoffs in General Liability through general liability reserve evidence coordination.

## Investment hypothesis
If we deliver this capability, we expect to move median process time from 7.4 to 3.2 days, with estimated annual benefit $570,000 (illustrative).

## Scope boundaries
Claim received → liability investigation → supporting evidence → reserve recommendation → adjuster approval → finance updates

## Dependencies
Claims platform, document management, financial ledger

## Portfolio Kanban
Reviewed against strategic themes, available capacity, flow impact and compliance constraints.
