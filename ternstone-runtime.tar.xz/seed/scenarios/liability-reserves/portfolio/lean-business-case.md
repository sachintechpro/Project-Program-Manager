---
schema: lean-business-case/v1
scenario_id: liability-reserves
stage: portfolio
author_role: epic_owner
reviewer_role: finance
status: sample_only
---

# Lean business case & funding

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Investment decision
Requested implementation budget: $310,000 (illustrative).
Expected annualized benefit: $570,000 (illustrative; subject to validation).

## Benefit hypothesis
median process time from 7.4 to 3.2 days

## Operational baseline
6,400 liability claims / year

## Economic assumptions
This is a modeled scenario. Finance must validate unit costs, cost avoidance vs. cash savings, operating expenses and attribution.

## Risk and contingency
Reserve recommendations affect financial controls and require human authorization.

## Funding guardrails
Capacity and expenditure stay within approved limits; material changes return to portfolio approval.
