---
schema: portfolio-epic/v1
scenario_id: cyber-response
stage: portfolio
author_role: epic_owner
reviewer_role: lpm
status: sample_only
---

# Epic / investment hypothesis

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Strategic alignment
Respond quickly and consistently to material cyber incidents

## Business opportunity
Reduce cycle time and prevent avoidable handoffs in Cyber Insurance through cyber breach response provider mobilization.

## Investment hypothesis
If we deliver this capability, we expect to move median process time from 9.1 to 3.6 hours, with estimated annual benefit $520,000 (illustrative).

## Scope boundaries
Policyholder reports breach → validate active cover → assess urgency → assign panel counsel / forensics → notify claims owner

## Dependencies
Cyber claims, panel vendor API, secure case management, IAM

## Portfolio Kanban
Reviewed against strategic themes, available capacity, flow impact and compliance constraints.
