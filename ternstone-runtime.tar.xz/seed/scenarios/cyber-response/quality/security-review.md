---
schema: security-review/v1
scenario_id: cyber-response
stage: quality
author_role: fde
reviewer_role: security
status: sample_only
---

# Security and control review

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Security boundaries
Least-privilege connectors, scoped tokens, no secrets in AI prompts, tenant isolation, redaction and human approval for sensitive changes.

## Control checklist
Authentication and authorization; OWASP API checks; dependency scan; audit immutability; secret handling; data residency review.

## Findings and decisions
Demo planning artifact: production approval must reference actual scan results and tracked findings.

## Risk-specific controls
Sensitive security and personal data must not be exposed to unauthorized agents.
