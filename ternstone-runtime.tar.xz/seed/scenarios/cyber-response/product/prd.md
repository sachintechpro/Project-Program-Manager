---
schema: prd/v1
scenario_id: cyber-response
stage: product
author_role: product_owner
reviewer_role: product_manager
status: sample_only
---

# Product requirements document

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Capability scope
Deliver a usable workflow supporting: Policyholder reports breach → validate active cover → assess urgency → assign panel counsel / forensics → notify claims owner

## Functional requirements
- REQ-001: Capture and validate required request and policy context.
- REQ-002: Enforce role-based access, audit every material state transition.
- REQ-003: Apply business rules, preserve exception review by authorized humans.
- REQ-004: Publish status changes to dependent stakeholders.
- REQ-005: Record outcome measurement and trace to investment.

## Nonfunctional requirements
Resilience, accessibility, least-privilege identity, privacy, observability, idempotency and recoverability.

## Acceptance criteria
Each REQ has positive, negative, integration and authorization tests. No unauthorized transitions.

## Explicit exclusions
Do not automate approvals reserved for an adjuster, underwriter, Finance, security or legal authority.
