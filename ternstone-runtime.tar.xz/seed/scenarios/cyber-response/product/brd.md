---
schema: brd/v1
scenario_id: cyber-response
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Business objective
Reduce cycle time and prevent avoidable handoffs in Cyber Insurance through cyber breach response provider mobilization.

## Operational value stream workflow
Policyholder reports breach → validate active cover → assess urgency → assign panel counsel / forensics → notify claims owner

## Business rules
Prioritize ransomware, business interruption and suspected exfiltration; enforce approved provider roster and escalation.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 9.1 to 3.6 hours. Volume: 520 incident notifications / year.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
