---
schema: brd/v1
scenario_id: endorsement
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Business objective
Reduce cycle time and prevent avoidable handoffs in Commercial Auto • Workers Compensation through commercial policy endorsement and document fulfillment.

## Operational value stream workflow
Broker requests change → authenticate authority → evaluate underwriting impact → endorse policy → issue documents

## Business rules
Do not automatically process material exposure changes; require appropriate underwriting approvals.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 4.4 to 1.6 days. Volume: 1,250 servicing requests / month.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
