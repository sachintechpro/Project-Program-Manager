---
schema: portfolio-epic/v1
scenario_id: billing-match
stage: portfolio
author_role: epic_owner
reviewer_role: lpm
status: sample_only
---

# Epic / investment hypothesis

## Strategic alignment
Reduce servicing friction and reconcile financial records

## Business opportunity
Reduce cycle time and prevent avoidable handoffs in Workers Compensation through workers compensation premium payment reconciliation.

## Investment hypothesis
If we deliver this capability, we expect to move median process time from 2.1 to 0.6 days, with estimated annual benefit $350,000 (illustrative).

## Scope boundaries
Payment received → validate reference → match to bill → identify exception → post ledger → notify broker

## Dependencies
Billing system, payment processor, general ledger

## Portfolio Kanban
Reviewed against strategic themes, available capacity, flow impact and compliance constraints.
