---
schema: lean-business-case/v1
scenario_id: billing-match
stage: portfolio
author_role: epic_owner
reviewer_role: finance
status: sample_only
---

# Lean business case & funding

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Investment decision
Requested implementation budget: $185,000 (illustrative).
Expected annualized benefit: $350,000 (illustrative; subject to validation).

## Benefit hypothesis
median process time from 2.1 to 0.6 days

## Operational baseline
8,300 premium transactions / month

## Economic assumptions
This is a modeled scenario. Finance must validate unit costs, cost avoidance vs. cash savings, operating expenses and attribution.

## Risk and contingency
Incorrect posting or double payment allocation.

## Funding guardrails
Capacity and expenditure stay within approved limits; material changes return to portfolio approval.
