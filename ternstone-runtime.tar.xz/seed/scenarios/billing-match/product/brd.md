---
schema: brd/v1
scenario_id: billing-match
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

## Business objective
Reduce cycle time and prevent avoidable handoffs in Workers Compensation through workers compensation premium payment reconciliation.

## Operational value stream workflow
Payment received → validate reference → match to bill → identify exception → post ledger → notify broker

## Business rules
Maintain separation of duties for adjustments, refunds and write-offs.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 2.1 to 0.6 days. Volume: 8,300 premium transactions / month.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
