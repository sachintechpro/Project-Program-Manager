---
schema: integration-contract/v1
scenario_id: cargo-surveyor
stage: architecture
author_role: fde
reviewer_role: integration
status: sample_only
---

# Data & integration contract

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Consumed systems
Claims platform, vendor directory, mobile evidence capture

## API and event contracts
Define producer, consumer, resource schema, version, idempotency key, timeout, retry, authorization and correlation ID.

## Data protection
Use least-privilege connectors; do not send regulated or personal production data to AI services without explicit authorization.

## Failure and reconciliation
Persist delivery status and failed events; support safe retry, dead-letter handling and exception review.

## Contract testing
Positive, negative, malformed, unauthorized, duplicate and failure-path tests are mandatory.
