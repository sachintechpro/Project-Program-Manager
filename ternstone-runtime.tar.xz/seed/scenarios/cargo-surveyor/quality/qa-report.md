---
schema: qa-report/v1
scenario_id: cargo-surveyor
stage: quality
author_role: fde
reviewer_role: qa
status: sample_only
---

# Validation and test report

## Test basis
Approved PRD REQ-001 through REQ-005, business rules and technical contracts.

## Test coverage
Functional, API, RBAC/ABAC, negative paths, integration, regression, accessibility, recovery and data integrity.

## Execution evidence
Demo scenario: planned evidence; no actual test execution has been claimed. Attach CI test IDs and raw results before production acceptance.

## Defect controls
Severity, reproduction, owner, verification and waiver approval are required.

## Independent review
QA must compare outputs to approved acceptance criteria, not merely trust AI's self-generated tests.
