---
schema: portfolio-epic/v1
scenario_id: cargo-surveyor
stage: portfolio
author_role: epic_owner
reviewer_role: lpm
status: sample_only
---

# Epic / investment hypothesis

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Strategic alignment
Reduce claim cycle time while protecting reserve and coverage quality

## Business opportunity
Reduce cycle time and prevent avoidable handoffs in Marine Cargo through marine cargo surveyor assignment & evidence capture.

## Investment hypothesis
If we deliver this capability, we expect to move median process time from 20 to 8 hours, with estimated annual benefit $440,000 (illustrative).

## Scope boundaries
Cargo loss notification → shipment verification → route to qualified surveyor → upload condition report → adjuster review

## Dependencies
Claims platform, vendor directory, mobile evidence capture

## Portfolio Kanban
Reviewed against strategic themes, available capacity, flow impact and compliance constraints.
