---
schema: lean-business-case/v1
scenario_id: cargo-surveyor
stage: portfolio
author_role: epic_owner
reviewer_role: finance
status: sample_only
---

# Lean business case & funding

## Investment decision
Requested implementation budget: $235,000 (illustrative).
Expected annualized benefit: $440,000 (illustrative; subject to validation).

## Benefit hypothesis
median process time from 20 to 8 hours

## Operational baseline
930 cargo claims / year

## Economic assumptions
This is a modeled scenario. Finance must validate unit costs, cost avoidance vs. cash savings, operating expenses and attribution.

## Risk and contingency
Surveyor availability and evidence chain of custody.

## Funding guardrails
Capacity and expenditure stay within approved limits; material changes return to portfolio approval.
