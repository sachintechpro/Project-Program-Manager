---
schema: brd/v1
scenario_id: cargo-surveyor
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Business objective
Reduce cycle time and prevent avoidable handoffs in Marine Cargo through marine cargo surveyor assignment & evidence capture.

## Operational value stream workflow
Cargo loss notification → shipment verification → route to qualified surveyor → upload condition report → adjuster review

## Business rules
Match geography, availability and cargo specialization; prevent cross-policy document exposure.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 20 to 8 hours. Volume: 930 cargo claims / year.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
