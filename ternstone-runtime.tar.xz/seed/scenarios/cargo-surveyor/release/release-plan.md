---
schema: release-plan/v1
scenario_id: cargo-surveyor
stage: release
author_role: fde
reviewer_role: release
status: sample_only
---

# Release and rollback approval

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Release prerequisites
Approved architecture, verified build, independent QA and security reviews, signed-off business acceptance and supported rollback.

## Deployment plan
Tag immutable artifact, run migration checks, deploy through authorized pipeline, smoke test, monitor and publish release ID.

## Rollback and recovery
Restore previous artifact; define reversible schema strategy, incident owner and customer communications.

## Cutover authorization
Release Manager approval is required for the identified build and environment.
