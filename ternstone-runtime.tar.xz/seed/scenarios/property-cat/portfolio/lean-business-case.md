---
schema: lean-business-case/v1
scenario_id: property-cat
stage: portfolio
author_role: epic_owner
reviewer_role: finance
status: sample_only
---

# Lean business case & funding

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Investment decision
Requested implementation budget: $370,000 (illustrative).
Expected annualized benefit: $810,000 (illustrative; subject to validation).

## Benefit hypothesis
median process time from 36 to 12 hours

## Operational baseline
1,800 catastrophe FNOL / month during event

## Economic assumptions
This is a modeled scenario. Finance must validate unit costs, cost avoidance vs. cash savings, operating expenses and attribution.

## Risk and contingency
Incorrect severe-loss routing may delay emergency response.

## Funding guardrails
Capacity and expenditure stay within approved limits; material changes return to portfolio approval.
