---
schema: portfolio-epic/v1
scenario_id: property-cat
stage: portfolio
author_role: epic_owner
reviewer_role: lpm
status: sample_only
---

# Epic / investment hypothesis

> Illustrative, synthetic insurance scenario. Values are not production or QBE data.

## Strategic alignment
Reduce claim cycle time while protecting reserve and coverage quality

## Business opportunity
Reduce cycle time and prevent avoidable handoffs in Commercial Property through commercial property catastrophe fnol triage.

## Investment hypothesis
If we deliver this capability, we expect to move median process time from 36 to 12 hours, with estimated annual benefit $810,000 (illustrative).

## Scope boundaries
Insured / broker reports loss → confirm coverage → catastrophe event match → severity triage → adjuster assignment → customer notification

## Dependencies
Claims administration, geospatial CAT feeds, document storage, SMS provider

## Portfolio Kanban
Reviewed against strategic themes, available capacity, flow impact and compliance constraints.
