---
schema: brd/v1
scenario_id: property-cat
stage: product
author_role: business_owner
reviewer_role: business_owner
status: sample_only
---

# Business requirements document

## Business objective
Reduce cycle time and prevent avoidable handoffs in Commercial Property through commercial property catastrophe fnol triage.

## Operational value stream workflow
Insured / broker reports loss → confirm coverage → catastrophe event match → severity triage → adjuster assignment → customer notification

## Business rules
Capture location, cause of loss, policy, coverage period, photos and urgency; preserve adjuster authority for coverage decisions.

## Actors and approvals
Business owner, service specialist, broker or policyholder, and authorized control owner.

## Exceptions
Missing information, manual overrides, system outages, duplicate cases, unauthorized access and escalation.

## Baseline and intended outcome
median process time from 36 to 12 hours. Volume: 1,800 catastrophe FNOL / month during event.

## Business acceptance
Demonstrate each required workflow with representative data, negative cases and accountable SME signoff.
