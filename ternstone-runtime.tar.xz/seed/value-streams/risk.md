# Risk Engineering & Prevention

**Key:** `risk`  
**Line(s):** Construction • Commercial Property • Fleet  
**Owner:** Risk engineering leadership

## Strategic theme
Turn prevention intelligence into measurable loss control

## Operational value stream boundary
From account risk referral through inspection, recommendations, corrective action and risk reduction.

## Measurement baseline
- Metric: Median days, inspection request to report
- Baseline: 21.0
- Target: 12.0
- Capacity / funding envelope: $870,000 (illustrative)

## LPM guardrails
Fund while expected incremental value exceeds additional cost and risk; all approvals and source evidence are retained.
