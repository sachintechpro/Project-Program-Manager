# Commercial Policy Servicing & Billing

> Fictional insurer; illustrative metric and funding assumptions.

**Key:** `servicing`  
**Line(s):** Workers Compensation • Commercial Auto • Umbrella  
**Owner:** Policy servicing leadership

## Strategic theme
Reduce servicing friction and reconcile financial records

## Operational value stream boundary
From endorsement, audit and invoice request to approved policy and financial updates.

## Measurement baseline
- Metric: Median days, service request to completion
- Baseline: 5.2
- Target: 2.1
- Capacity / funding envelope: $1,370,000 (illustrative)

## LPM guardrails
Fund while expected incremental value exceeds additional cost and risk; all approvals and source evidence are retained.
