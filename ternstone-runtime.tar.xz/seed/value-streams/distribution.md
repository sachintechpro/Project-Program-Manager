# Broker & Distribution Experience

> Fictional insurer; illustrative metric and funding assumptions.

**Key:** `distribution`  
**Line(s):** Commercial & Specialty Multi-line  
**Owner:** Distribution leadership

## Strategic theme
Improve broker self-service and producer responsiveness

## Operational value stream boundary
From producer onboarding and submissions through servicing, document access and relationship support.

## Measurement baseline
- Metric: Median days, broker inquiry to resolution
- Baseline: 4.6
- Target: 1.8
- Capacity / funding envelope: $1,090,000 (illustrative)

## LPM guardrails
Fund while expected incremental value exceeds additional cost and risk; all approvals and source evidence are retained.
