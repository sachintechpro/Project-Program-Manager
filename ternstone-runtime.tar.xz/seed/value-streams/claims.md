# Claims Resolution & Recovery

**Key:** `claims`  
**Line(s):** Commercial Property • General Liability • Marine Cargo  
**Owner:** Claims leadership

## Strategic theme
Reduce claim cycle time while protecting reserve and coverage quality

## Operational value stream boundary
From first notice of loss through coverage validation, assessment, settlement and recovery.

## Measurement baseline
- Metric: Median days, notice to settlement
- Baseline: 18.6
- Target: 11.0
- Capacity / funding envelope: $1,850,000 (illustrative)

## LPM guardrails
Fund while expected incremental value exceeds additional cost and risk; all approvals and source evidence are retained.
