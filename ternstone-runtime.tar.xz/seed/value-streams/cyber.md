# Cyber Incident Response

**Key:** `cyber`  
**Line(s):** Cyber • Professional Liability  
**Owner:** Cyber claims leadership

## Strategic theme
Respond quickly and consistently to material cyber incidents

## Operational value stream boundary
From insured incident notification to breach triage, vendor mobilization, investigation and resolution.

## Measurement baseline
- Metric: Median hours, incident to response partner assignment
- Baseline: 9.1
- Target: 3.6
- Capacity / funding envelope: $980,000 (illustrative)

## LPM guardrails
Fund while expected incremental value exceeds additional cost and risk; all approvals and source evidence are retained.
