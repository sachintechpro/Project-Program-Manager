# Commercial & Specialty Underwriting

**Key:** `underwriting`  
**Line(s):** Commercial Property • Workers Compensation • General Liability  
**Owner:** Underwriting leadership

## Strategic theme
Faster quote-to-bind with controlled underwriting

## Operational value stream boundary
From broker submission through appetite, clearance, pricing, quote, binding and policy issuance.

## Measurement baseline
- Metric: Median days, submission to bind
- Baseline: 12.4
- Target: 6.7
- Capacity / funding envelope: $2,200,000 (illustrative)

## LPM guardrails
Fund while expected incremental value exceeds additional cost and risk; all approvals and source evidence are retained.
