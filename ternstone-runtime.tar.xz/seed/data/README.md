# Commercial and specialty insurance reference data

Each CSV is small and intentionally describes one subject. These are modeled, fictional records for demonstration, not live insurer data. IDs are stable and join through `initiative_key` and `stream_id`.

Read **schema.json** for required headers and types; run `python scripts/validate_reference_csv.py` before making or importing changes. Current baseline and target values are in `metrics.csv` for initiatives and `value_streams.csv` for whole-stream measures. Budget and annual benefit assumptions are defined only in `initiatives.csv`; detailed costs in `cost_estimates.csv` reconcile to that budget. No test has been run and no benefit is claimed as realized.

For a new initiative, start with `initiatives.csv`, then select or clone related requirement, data, business-rule, integration, test, risk, dependency, metric, and operations records. Each role has a review responsibility in `role_approval_controls.csv`. Approval results are stored in the live application's audit database, not in seed files.
