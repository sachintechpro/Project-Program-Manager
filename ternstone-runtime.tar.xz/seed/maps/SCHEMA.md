# Value stream map reference inputs

Six fictional commercial and specialty insurance process maps. Steps use **elapsed clock hours**: touch_hours is active handling; wait_hours is elapsed waiting. Monthly volume and first-pass quality are illustrative, not measured. Current/future totals deliberately match the value stream headline estimates, not independently observed medians. Do not claim a measured end-to-end median by summing per-step estimates.

Each record defines customer value, start, outcome, boundaries, risks, roles, workflow steps, workshop agenda, and candidate improvements. Original reference JSON remains unchanged. Actual edits, workshop notes, and reviewer decisions are separately versioned and audited in the application database.

## Readable linked process evidence and approvals

`step_evidence.csv` contains exactly one row per stream, state and stage ID. `state` is either `current` or `future`. Each row gives source material to check, a domain-specific input or outcome artifact, an authorized handoff, a required control and a negative case. `monthly_cases_modeled` is the whole stream's assumed demand volume, **not** a measured per-step completion count. This number is deliberately repeated for stream context; it must not be added across steps.

`role_review_guidance.csv` contains one row per invited decision-making role in each stream. This is the human evidence checklist, not proof that the role performed the review. Approval history lives in the application database.

`workshop_questions.csv` contains suggested meeting questions only. Each row has `status=suggested_only_not_a_recorded_meeting` to avoid a fictional agenda being mistaken for actual minutes.

IDs are unique per table on the documented composite keys. No realistic scenario number should be represented as actual insurer operational performance until supported by source telemetry and appropriate accountable owner validation.
