# Value stream map reference inputs

Six fictional commercial and specialty insurance process maps. Steps use **elapsed clock hours**: touch_hours is active handling; wait_hours is elapsed waiting. Monthly volume and first-pass quality are illustrative, not measured. Current/future totals deliberately match the value stream headline estimates, not independently observed medians. Do not claim a measured end-to-end median by summing per-step estimates.

Each record defines customer value, start, outcome, boundaries, risks, roles, workflow steps, workshop agenda, and candidate improvements. Original reference JSON remains unchanged. Actual edits, workshop notes, and reviewer decisions are separately versioned and audited in the application database.
