# Commercial & specialty insurance scenario catalog

This reference catalog contains modeled operating volumes, financial assumptions, scenarios and sample approval histories. Actual organizational evidence must be sourced and verified before it is used for business decisions.

- `value-streams/`: one Markdown profile per development value stream, including baseline and target business metrics.
- `scenarios/<initiative-key>/scenario.json`: one structured initiative scenario for each seeded insurance improvement.
- `scenarios/<initiative-key>/<stage>/<artifact>.md`: fully written Markdown examples for each required lifecycle contract.
- `contracts/`: canonical contract schema and lifecycle index.

The app seeds selected example artifacts into PostgreSQL/SQLite on first launch in demo mode. New user changes and version history are stored in the database. The source Markdown files remain reusable reference fixtures; they are not the authoritative record of runtime edits. Export an initiative as ZIP to obtain actual runtime contract versions and manifest.
