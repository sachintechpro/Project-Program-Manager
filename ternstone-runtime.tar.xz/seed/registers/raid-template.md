# RAID — Integration dependency example

## Context
- Applies to: one value stream or initiative
- Category: Dependency
- Priority: High
- Status: Open
- Owner: Integration & Data Lead

## Dependency
A shared service API must be compatible with the agreed integration contract before the release can proceed.

## Response
Confirm interface contract, consumer acceptance criteria, dependency due date, responsible owner, mitigation and evidence link. Escalate when timing threatens a committed milestone.

## Evidence
Integration contract reference, API contract test results, owner acknowledgement and readiness decision.

## Control
Only the author can revise this register entry; each revision carries a timestamp, SHA-256 digest and preserved Markdown snapshot.
