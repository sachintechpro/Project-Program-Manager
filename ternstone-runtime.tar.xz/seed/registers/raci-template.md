# RACI — Initiative delivery responsibility example

## Context
- Applies to: one value stream or initiative (set the scope in the application)
- Scope: approved delivery activities, deliverables, decisions and gate approvals
- Author: Program / Project Manager (illustrative; other authorized owners may author)

## Responsibility assignment
- Activity: Validate integrated implementation and test readiness
- Responsible: Forward Deployed Engineer; QA / Validation Lead
- Accountable: Program / Project Manager
- Consulted: Solution Architect; Product Owner; Security / Compliance Lead
- Informed: Release Train Engineer; Business Owner; Operations / SRE Lead

## Control
Exactly one Accountable role per record. Edits create a revision and audit event. The original author alone may edit. Other authorized roles can inspect and export Markdown but cannot change the record.
