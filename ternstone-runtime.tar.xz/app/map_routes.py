"""Persistent, role-controlled and auditable value stream mapping workspace."""
import json, datetime
from copy import deepcopy
from fastapi import HTTPException, Depends, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, select
from .value_mapping import seed_map,validate_map,measures,recommendations,markdown_report,reference_evidence

MAP_EDITORS={'program_manager','value_owner','business_owner','product_manager','product_owner','rte','vmo','lpm'}
MAP_MEETING_AUTHORS=MAP_EDITORS|{'architect','integration','qa','ops','security','actuarial','claims_sme','analytics','customer_care','finance','team_coach','vendor','risk','fde','engineer'}

def install(app,m):
    Base=m.BaseModelDB
    class StreamMap(Base):
        __tablename__='stream_maps'
        id=Column(Integer,primary_key=True)
        stream_id=Column(Integer,ForeignKey('value_streams.id'),nullable=False,unique=True)
        version=Column(Integer,default=1,nullable=False)
        body=Column(Text,nullable=False)
        editor_id=Column(Integer,nullable=True)
        updated_at=Column(DateTime,default=m.now)
    class MapVersion(Base):
        __tablename__='stream_map_versions'
        id=Column(Integer,primary_key=True)
        map_id=Column(Integer,ForeignKey('stream_maps.id'),nullable=False)
        version=Column(Integer,nullable=False)
        body=Column(Text,nullable=False)
        digest=Column(String(64),nullable=False)
        editor_id=Column(Integer)
        created_at=Column(DateTime,default=m.now)
    class Meeting(Base):
        __tablename__='stream_map_meetings'
        id=Column(Integer,primary_key=True)
        stream_id=Column(Integer,ForeignKey('value_streams.id'),nullable=False)
        author_id=Column(Integer,nullable=False)
        author_name=Column(String(120),nullable=False)
        version=Column(Integer,default=1)
        title=Column(String(180),nullable=False)
        meeting_date=Column(String(10),nullable=False)
        purpose=Column(Text,default='')
        invited_roles=Column(Text,default='[]')
        attended_roles=Column(Text,default='[]')
        notes=Column(Text,default='')
        decisions=Column(Text,default='')
        actions=Column(Text,default='')
        action_owner=Column(String(80),default='')
        action_due=Column(String(10),default='')
        created_at=Column(DateTime,default=m.now)
        updated_at=Column(DateTime,default=m.now)
    class MeetingVersion(Base):
        __tablename__='stream_map_meeting_versions'
        id=Column(Integer,primary_key=True)
        meeting_id=Column(Integer,ForeignKey('stream_map_meetings.id'),nullable=False)
        version=Column(Integer,nullable=False)
        body=Column(Text,nullable=False)
        digest=Column(String(64),nullable=False)
        actor_id=Column(Integer,nullable=False)
        created_at=Column(DateTime,default=m.now)
    class MapReview(Base):
        __tablename__='stream_map_reviews'
        id=Column(Integer,primary_key=True)
        map_id=Column(Integer,ForeignKey('stream_maps.id'),nullable=False)
        map_version=Column(Integer,nullable=False)
        role=Column(String(80),nullable=False)
        actor_id=Column(Integer,nullable=False)
        actor_name=Column(String(120),nullable=False)
        decision=Column(String(30),nullable=False)
        comment=Column(Text,default='')
        created_at=Column(DateTime,default=m.now)

    class MapInquiryResponse(Base):
        __tablename__='stream_map_review_responses'
        id=Column(Integer,primary_key=True)
        review_id=Column(Integer,ForeignKey('stream_map_reviews.id'),nullable=False,unique=True)
        author_id=Column(Integer,nullable=False)
        author_name=Column(String(120),nullable=False)
        response=Column(Text,nullable=False)
        evidence_reference=Column(Text,default='')
        created_at=Column(DateTime,default=m.now)

    def decision_kind(d):
        return {'confirm':'approve','request_changes':'decline'}.get(d,d)
    def review_status(latest,required_roles):
        if all(x in latest and decision_kind(latest[x].decision)=='approve' for x in required_roles):return 'approved'
        if any(x in latest and decision_kind(latest[x].decision)=='decline' for x in required_roles):return 'declined'
        if any(x in latest and decision_kind(latest[x].decision)=='request_information' for x in required_roles):return 'needs_information'
        return 'in_review'

    def get_stream(db,sid,user):
        m.require_business_data_access(user)
        stream=db.get(m.ValueStream,sid)
        if not stream:raise HTTPException(404,'Unknown value stream')
        return stream
    def ensure(db,stream):
        obj=db.execute(select(StreamMap).where(StreamMap.stream_id==stream.id)).scalar_one_or_none()
        if obj:return obj
        data=seed_map(stream.key,name=stream.name,metric=stream.metric,baseline=stream.baseline,target=stream.target)
        validate_map(data)
        author=db.execute(select(m.ManagedRecord).where(m.ManagedRecord.resource_type=='stream',m.ManagedRecord.resource_id==stream.id)).scalar_one_or_none()
        obj=StreamMap(stream_id=stream.id,version=1,body=json.dumps(data,sort_keys=True),editor_id=author.author_id if author else None)
        db.add(obj);db.flush()
        db.add(MapVersion(map_id=obj.id,version=1,body=obj.body,digest=m.sha(obj.body),editor_id=obj.editor_id))
        db.commit()
        return obj
    def meetings(db,sid):return db.execute(select(Meeting).where(Meeting.stream_id==sid).order_by(Meeting.meeting_date.desc(),Meeting.id.desc())).scalars().all()
    def reviews(db,obj):return db.execute(select(MapReview).where(MapReview.map_id==obj.id,MapReview.map_version==obj.version).order_by(MapReview.id)).scalars().all()
    def meeting_dict(s,user):return dict(id=s.id,title=s.title,meeting_date=s.meeting_date,purpose=s.purpose,
         invited_roles=json.loads(s.invited_roles),attended_roles=json.loads(s.attended_roles),notes=s.notes,
         decisions=s.decisions,actions=s.actions,action_owner=s.action_owner,action_due=s.action_due,
         author_name=s.author_name,version=s.version,created_at=m.utcstr(s.created_at),updated_at=m.utcstr(s.updated_at),can_edit=user.id==s.author_id)
    def meeting_snapshot(s):return json.dumps({k:getattr(s,k) for k in ('title','meeting_date','purpose','invited_roles','attended_roles','notes','decisions','actions','action_owner','action_due','version')},sort_keys=True)
    def lookup(db,sid,user):
        stream=get_stream(db,sid,user)
        return stream,ensure(db,stream)
    def can_edit(user,obj):return user.role in MAP_EDITORS and (obj.editor_id is None or obj.editor_id==user.id)
    def doc_output(db,stream,obj,user):
        d=json.loads(obj.body);rev=reviews(db,obj)
        latest={r.role:r for r in rev}
        responses={x.review_id:x for x in db.execute(select(MapInquiryResponse).where(MapInquiryResponse.review_id.in_([r.id for r in latest.values()]))).scalars().all()} if latest else {}
        status=review_status(latest,d['review_roles'])
        return {'value_stream':m.visible_stream(stream,user),'version':obj.version,'map':d,
         'current':measures(d['current']),'future':measures(d['future']),'recommendations':recommendations(d),
         'reference_evidence':reference_evidence(stream.key),
         'meetings':[meeting_dict(x,user) for x in meetings(db,stream.id)],
         'reviews':[{'id':r.id,'role':r.role,'decision':r.decision,'kind':decision_kind(r.decision),'name':r.actor_name,
          'comment':r.comment,'version':r.map_version,'date':m.utcstr(r.created_at),
          'response':({'response':responses[r.id].response,'evidence_reference':responses[r.id].evidence_reference,
                       'author_name':responses[r.id].author_name,'date':m.utcstr(responses[r.id].created_at)} if r.id in responses else None)} for r in latest.values()],
         'review_roles':d['review_roles'],'review_status':status,'approved_for_mapping':status=='approved',
         'can_edit':can_edit(user,obj),
         'can_meet':user.role in MAP_MEETING_AUTHORS and user.role in d['invited_roles'],
         'can_review':user.role in d['review_roles'],
         'current_role':user.role,'editor_name':'Assigned mapping facilitator' if obj.editor_id else 'Open for authorized facilitator'}

    class MapUpdate(BaseModel):
        expected_version:int=Field(ge=1)
        map:dict
    @app.get('/api/streams/{sid}/map')
    def get_map(sid:int,user:m.User=Depends(m.get_user),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user);return doc_output(db,st,obj,user)
    @app.put('/api/streams/{sid}/map')
    def update_map(sid:int,req:MapUpdate,request:Request,user:m.User=Depends(m.guard),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user)
        if not can_edit(user,obj):raise HTTPException(403,'Only the assigned mapping facilitator may change this map')
        if obj.version!=req.expected_version:raise HTTPException(409,'Map changed. Reload before saving to avoid overwriting others')
        doc=json.loads(obj.body)
        # Clients cannot change reviewer permissions, scope roles, source provenance or reference identity.
        for f in ('review_roles','invited_roles','reference','modeled','clock','unit','metric','agenda'):
            if req.map.get(f)!=doc.get(f):raise HTTPException(403,'Governed mapping metadata cannot be edited here: '+f)
        try:validate_map(req.map)
        except ValueError as ex:raise HTTPException(422,str(ex))
        if obj.body==json.dumps(req.map,sort_keys=True):return doc_output(db,st,obj,user)
        obj.body=json.dumps(req.map,sort_keys=True);obj.version+=1;obj.editor_id=user.id;obj.updated_at=m.now()
        db.add(MapVersion(map_id=obj.id,version=obj.version,body=obj.body,digest=m.sha(obj.body),editor_id=user.id))
        m.log(db,user,'value_map.revised',f'VS-{sid}',{'revision':obj.version,'digest':m.sha(obj.body),'prior_reviews_stale':True})
        db.commit();return doc_output(db,st,obj,user)
    class MeetingInput(BaseModel):
        title:str=Field(min_length=5,max_length=180)
        meeting_date:str=Field(min_length=10,max_length=10)
        purpose:str=Field(default='',max_length=1600)
        invited_roles:list[str]=Field(default_factory=list,max_length=29)
        attended_roles:list[str]=Field(default_factory=list,max_length=29)
        notes:str=Field(default='',max_length=12000)
        decisions:str=Field(default='',max_length=6000)
        actions:str=Field(default='',max_length=6000)
        action_owner:str=Field(default='',max_length=80)
        action_due:str=Field(default='',max_length=10)
        expected_version:int|None=None
    def validate_meeting(req,doc):
        try:datetime.date.fromisoformat(req.meeting_date)
        except ValueError:raise HTTPException(422,'Meeting date must be YYYY-MM-DD')
        if req.action_due:
            try:datetime.date.fromisoformat(req.action_due)
            except ValueError:raise HTTPException(422,'Action due date must be YYYY-MM-DD')
        allowed=set(doc['invited_roles'])
        for roles in (req.invited_roles,req.attended_roles):
            if len(roles)!=len(set(roles)) or not set(roles).issubset(allowed):raise HTTPException(422,'Participant roles must be unique and on this stream’s stakeholder list')
        if not set(req.attended_roles).issubset(set(req.invited_roles)):raise HTTPException(422,'Attendees must also be invited')
        if req.action_owner and req.action_owner not in allowed:raise HTTPException(422,'Choose an action owner from the stakeholder list')
    def apply_meeting(meet,req):
        for f in ('title','meeting_date','purpose','notes','decisions','actions','action_owner','action_due'):setattr(meet,f,getattr(req,f))
        meet.invited_roles=json.dumps(req.invited_roles);meet.attended_roles=json.dumps(req.attended_roles)
    @app.post('/api/streams/{sid}/map/meetings')
    def create_meeting(sid:int,req:MeetingInput,request:Request,user:m.User=Depends(m.guard),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user);doc=json.loads(obj.body)
        if user.role not in MAP_MEETING_AUTHORS or user.role not in doc['invited_roles']:
            raise HTTPException(403,'This role is not a participant in this mapping workshop')
        validate_meeting(req,doc)
        meet=Meeting(stream_id=sid,author_id=user.id,author_name=user.name,version=1)
        apply_meeting(meet,req);db.add(meet);db.flush();snap=meeting_snapshot(meet)
        db.add(MeetingVersion(meeting_id=meet.id,version=1,body=snap,digest=m.sha(snap),actor_id=user.id))
        obj.version+=1;obj.updated_at=m.now()
        db.add(MapVersion(map_id=obj.id,version=obj.version,body=obj.body,digest=m.sha(obj.body),editor_id=obj.editor_id))
        m.log(db,user,'value_map.meeting_recorded',f'VS-{sid}',{'meeting_id':meet.id,'date':meet.meeting_date,'version':1,'map_version':obj.version,'note_digest':m.sha(snap)})
        db.commit();return meeting_dict(meet,user)
    @app.put('/api/streams/{sid}/map/meetings/{mid}')
    def edit_meeting(sid:int,mid:int,req:MeetingInput,request:Request,user:m.User=Depends(m.guard),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user);meet=db.get(Meeting,mid)
        if not meet or meet.stream_id!=sid:raise HTTPException(404,'Workshop note not found')
        if meet.author_id!=user.id:raise HTTPException(403,'Only the workshop note author can revise it')
        if req.expected_version!=meet.version:raise HTTPException(409,'Workshop notes changed; refresh before saving')
        validate_meeting(req,json.loads(obj.body));apply_meeting(meet,req);meet.version+=1;meet.updated_at=m.now()
        snap=meeting_snapshot(meet)
        db.add(MeetingVersion(meeting_id=meet.id,version=meet.version,body=snap,digest=m.sha(snap),actor_id=user.id))
        obj.version+=1;obj.updated_at=m.now()
        db.add(MapVersion(map_id=obj.id,version=obj.version,body=obj.body,digest=m.sha(obj.body),editor_id=obj.editor_id))
        m.log(db,user,'value_map.meeting_revised',f'VS-{sid}',{'meeting_id':mid,'version':meet.version,'map_version':obj.version,'digest':m.sha(snap)})
        db.commit();return meeting_dict(meet,user)
    @app.get('/api/streams/{sid}/map/meetings/{mid}/history')
    def meeting_history(sid:int,mid:int,user:m.User=Depends(m.get_user),db:m.Session=Depends(m.db_session)):
        get_stream(db,sid,user);meet=db.get(Meeting,mid)
        if not meet or meet.stream_id!=sid:raise HTTPException(404,'Meeting not found')
        v=db.execute(select(MeetingVersion).where(MeetingVersion.meeting_id==mid).order_by(MeetingVersion.version)).scalars().all()
        return [{'version':x.version,'digest':x.digest,'state':json.loads(x.body),'time':m.utcstr(x.created_at)} for x in v]
    class MapDecision(BaseModel):
        expected_version:int=Field(ge=1)
        decision:str
        comment:str=Field(default='',max_length=2400)
    @app.post('/api/streams/{sid}/map/reviews')
    def review_map(sid:int,req:MapDecision,request:Request,user:m.User=Depends(m.guard),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user);doc=json.loads(obj.body)
        if user.role not in doc['review_roles']:raise HTTPException(403,'This role is not an assigned map reviewer')
        if req.decision not in ('approve','decline','request_information','confirm','request_changes'):
            raise HTTPException(422,'Choose Approve, Decline, or Request more information')
        if obj.version!=req.expected_version:raise HTTPException(409,'The map has changed; review the latest version')
        kind=decision_kind(req.decision)
        if kind in ('decline','request_information') and len(req.comment.strip())<8:
            raise HTTPException(422,'Explain the reason and evidence needed (at least 8 characters)')
        if kind=='approve' and not meetings(db,sid):
            raise HTTPException(409,'Record at least one actual stakeholder discovery workshop before approving the map')
        if kind=='approve' and req.decision=='approve' and len(req.comment.strip())<8:
            raise HTTPException(422,'Cite the evidence checked before approving (at least 8 characters)')
        prior=db.execute(select(MapReview).where(MapReview.map_id==obj.id,MapReview.map_version==obj.version,MapReview.role==user.role).order_by(MapReview.id.desc())).scalars().first()
        if kind=='approve' and prior and decision_kind(prior.decision)=='request_information':
            answer=db.execute(select(MapInquiryResponse).where(MapInquiryResponse.review_id==prior.id)).scalar_one_or_none()
            if not answer:raise HTTPException(409,'The facilitator must answer your information request before approval')
        review=MapReview(map_id=obj.id,map_version=obj.version,role=user.role,actor_id=user.id,actor_name=user.name,
                         decision=req.decision,comment=req.comment.strip())
        db.add(review);db.flush()
        m.log(db,user,'value_map.review_recorded',f'VS-{sid}',{'review_id':review.id,'role':user.role,
            'decision':kind,'map_version':obj.version,'comment_digest':m.sha(review.comment)})
        db.commit();return doc_output(db,st,obj,user)

    class MapInquiryAnswer(BaseModel):
        expected_version:int=Field(ge=1)
        response:str=Field(min_length=12,max_length=3000)
        evidence_reference:str=Field(default='',max_length=500)
    @app.post('/api/streams/{sid}/map/reviews/{review_id}/answer')
    def answer_map_review(sid:int,review_id:int,req:MapInquiryAnswer,request:Request,user:m.User=Depends(m.guard),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user)
        if not can_edit(user,obj):raise HTTPException(403,'Only the mapping facilitator can answer this information request')
        if obj.version!=req.expected_version:raise HTTPException(409,'The map was revised; answer on the current version')
        review=db.get(MapReview,review_id)
        if not review or review.map_id!=obj.id or review.map_version!=obj.version or decision_kind(review.decision)!='request_information':
            raise HTTPException(404,'Current information request not found')
        if review.actor_id==user.id:
            raise HTTPException(403,'Reviewers cannot answer their own evidence requests; a different facilitator must respond')
        latest=db.execute(select(MapReview).where(MapReview.map_id==obj.id,MapReview.map_version==obj.version,MapReview.role==review.role).order_by(MapReview.id.desc())).scalars().first()
        if latest.id!=review.id:raise HTTPException(409,'Reviewer has already issued a newer decision')
        if db.execute(select(MapInquiryResponse).where(MapInquiryResponse.review_id==review.id)).scalar_one_or_none():
            raise HTTPException(409,'Already answered; ask reviewer to assess the response')
        row=MapInquiryResponse(review_id=review.id,author_id=user.id,author_name=user.name,response=req.response.strip(),
                               evidence_reference=req.evidence_reference.strip())
        db.add(row)
        m.log(db,user,'value_map.information_provided',f'VS-{sid}',{'review_id':review.id,
            'reviewer_role':review.role,'map_version':obj.version,'response_digest':m.sha(row.response)})
        db.commit();return doc_output(db,st,obj,user)

    @app.get('/api/streams/{sid}/map/history')
    def history(sid:int,user:m.User=Depends(m.get_user),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user)
        versions=db.execute(select(MapVersion).where(MapVersion.map_id==obj.id).order_by(MapVersion.version.desc())).scalars().all()
        return [{'version':v.version,'digest':v.digest,'updated_at':m.utcstr(v.created_at),'editor_id':v.editor_id} for v in versions]
    @app.get('/api/streams/{sid}/map/download')
    def download_map(sid:int,user:m.User=Depends(m.get_user),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user)
        rev=reviews(db,obj)
        answers={x.review_id:x for x in db.execute(select(MapInquiryResponse).where(MapInquiryResponse.review_id.in_([r.id for r in rev]))).scalars().all()} if rev else {}
        text=markdown_report(st,json.loads(obj.body),meetings(db,sid),rev,obj.version,answers)
        return Response(text,media_type='text/markdown',headers={'Content-Disposition':f'attachment; filename="value-stream-{st.id}-map-v{obj.version}.md"'})
