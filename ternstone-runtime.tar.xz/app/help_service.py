"""Read-only contextual work guidance. All initiative facts are selected by the authenticated server role."""
import re
from .help_catalog import page_catalog, get_field, role_catalog, canonical
from .role_policy import ROLE_DOCS, STAGE_GENERATORS
from .catalog import STAGES

STAGE_TITLES={s['id']:s['title'] for s in STAGES}
STAGE_TITLES['closed']='Closed'
FINANCE_TERMS={'budget','budgets','cost','costs','finance','funding','investment','roi','profit','revenue','spending','expense','financial','forecast','benefit amount','money','savings'}
SENSITIVE_TERMS={'token','password','client secret','api key','secret'}
PAGE_RESTRICTED={'insights':'financial','integrations':'connector','connector':'connector','evidence':'audit'}

def permitted_page(role, page, permissions):
    why=PAGE_RESTRICTED.get(page)
    if why=='financial' and not permissions.get('can_view_financials'):return False
    if why=='connector' and not permissions.get('view_connectors'):return False
    if why=='audit' and not permissions.get('view_audit'):return False
    if role=='admin' and page in {'streams','initiatives','initiative','contracts','contract','reference','raci','raid','value_map'}:return False
    return True

def next_work(role, initiative, contracts, controls, has_generate=False):
    """Give a grounded next action, without granting or performing approvals."""
    if role=='admin':
        return ('Integrations','integrations','Manage connector settings or user access. Business contract approvals belong to business roles.')
    if initiative is None:
        if role in {'program_manager','lpm','epic_owner','product_manager'}:
            return ('Initiative journeys','initiatives','Open or create an initiative and inspect its current stage.')
        if role in {'qa','security','architect','engineer','finance','release','ops','product_owner','product_manager','value_owner','business_owner'}:
            return ('Approval inbox','approvals','Review contracts that are specifically assigned to your role.')
        return ('My role decisions','controls','Open your role-specific confirmations or approvals.')
    stage=initiative.current_stage
    if stage=='closed':return ('Initiative journeys','initiative','This initiative is closed. Review retained evidence and ongoing operational benefit ownership.')
    missing=[a for a in contracts if a.reviewer==role and a.status!='approved' and a.stage==stage]
    if missing:
        a=missing[0]
        return ('Approval inbox','approvals',f'Review the current {a.kind.replace("-"," ")} contract (version {a.version}). Inspect evidence and approve or request changes.')
    mine=[c for c in controls if c['role']==role and c['decision']!='approved']
    if mine:
        c=mine[0]
        return ('My role decisions','controls',f'Check evidence for "{c["decision_title"]}" then record the authorized decision. {"Mandatory for this stage." if c["mandatory"] else "Advisory control."}')
    if has_generate and stage!='closed' and not contracts:
        return ('Initiative journey','initiative','Generate the required Markdown stage contracts, then submit them to assigned reviewers.')
    return ('Initiative journey','initiative',f'This initiative is at {STAGE_TITLES.get(stage,stage)}. Inspect pending work. Do not approve for another role.')

def answer(question, role, page, field, initiative, contracts, controls, perms, can_generate=False, queue=None):
    q=re.sub(r'\s+',' ',question.strip().lower())
    queue=queue or []
    role_help=role_catalog().get(role,{})
    page_help=page_catalog().get(page,page_catalog()['dashboard'])
    if not permitted_page(role,page,perms):
        return ('Your role is not authorized to open that workspace. Use your own dashboard and assigned decisions.', 'dashboard', ['What should I work on?','Which approvals are mine?'])
    if any(w in q for w in ('my password','show token','show api key','share secret','client secret value')):
        return ('I cannot retrieve or repeat credentials. Use the approved connector configuration and secret-management process.', 'integrations' if perms.get('view_connectors') else 'dashboard', ['What can my role access?'])
    financial=any(re.search(r'\b'+re.escape(k)+r'\b',q) for k in FINANCE_TERMS)
    if financial and not perms.get('can_view_financials') and any(t in q for t in ('show','see','actual','how much','number','total','give me','our','initiative','what is the','amount','display','why can not')):
        return ('Financial amounts and investment records are restricted for your role. Finance and authorized portfolio roles can review those figures. You can still review delivery, quality and operational evidence relevant to your role.', 'dashboard', ['What should I review?','Explain the current stage'])
    fkey=canonical(field)
    # Explicit help selection is authoritative for the focused field.
    match=get_field(fkey)
    if not match:
        # Question may refer to a named parameter in the current form.
        for key,item in sorted(__import__('app.help_catalog',fromlist=['field_catalog']).field_catalog().items(),key=lambda it:-len(it[0])):
            readable=key.replace('_',' ').replace('.',' ')
            if len(readable)>3 and (readable in q or key in q):
                match=item;break
    if match and (field or any(x in q for x in ('what is','define','meaning','explain','example','field','parameter','why'))):
        if match.get('scope')=='finance' and not perms.get('can_view_financials'):
            return ('That field describes restricted financial information. Your role does not have access to investment amounts.', 'dashboard',['What should I work on?'])
        text=match['explanation']+' Example: '+match['example']+'. '+match['note']
        return (text,page,['What should I do next?','Which evidence is required?'])
    if page=='value_map' or any(x in q for x in ('value stream map','current state map','future state map','flow efficiency','touch time','waiting time')):
        return ('Define value as a measurable result for the customer. Invite Business, Product, RTE/DevOps, Engineering, QA, Operations and Analytics. Record actual workshop notes, current waits, handoffs and controls. Compare a feasible future state, collect role confirmations, then propose initiatives to LPM. Estimated durations are not realized benefits.', 'value_map',['What is customer value?','What waiting time matters?','Who validates this map?'])
    if 'raci' in q or ('responsible' in q and 'accountable' in q):
        return ('RACI: Responsible does the work; Accountable owns the outcome (normally one role); Consulted gives input; Informed receives updates. Open RACI matrix to add an assignment. The author can edit; other authorized users have read-only access.', 'raci',['What is RAID?','Who approves my work?'])
    if 'raid' in q or 'risk log' in q or 'dependency log' in q:
        return ('RAID tracks Risks (might occur), Assumptions (need checking), Issues (already happening), and Dependencies (needed from others). Each entry needs an owner, next action, due date and evidence reference. Only the author can revise it.', 'raid',['Explain RACI','What is my next action?'])
    if 'safe' in q or 'pi planning' in q or 'art ' in q or 'lean portfolio' in q or 'agile release train' in q:
        return ('SAFe connects portfolio priorities to coordinated Agile delivery. LPM aligns strategy and funding; Product roles define value; the ART synchronizes teams through Planning Intervals; specialists review quality and risk; Operations and business owners sustain outcomes. This demo models selected controls rather than a full SAFe implementation.', 'guide',['What does my role own?','Explain the current stage'])
    if 'approval' in q or 'approve' in q or 'sign off' in q or 'control' in q or 'evidence required' in q:
        if initiative is None and queue:
            return ('Your pending assignments: '+' '.join(queue[:3])+' Open the appropriate approval or role decision queue to inspect the evidence.', 'controls', ['What should I do next?', 'Explain this page'])
        mine=[c for c in controls if c['role']==role]
        if mine:
            lines=[]
            for c in mine[:3]:
                status='complete' if c['decision']=='approved' else 'not approved'
                lines.append(f'{c["decision_title"]}: {status}. Evidence needed: {c.get("evidence_needed") or "review relevant current contracts"}.')
            return ('Your assigned role controls: '+' '.join(lines)+' Use My role decisions; a different role cannot approve on your behalf.', 'controls',['What should I do next?','Explain this page'])
        open_contract=[a for a in contracts if a.reviewer==role and a.status!='approved']
        if open_contract:return (f'You have a contract review: {open_contract[0].kind.replace("-"," ")}. Open Approval inbox, inspect the current version and underlying evidence, then approve or request corrections.', 'approvals',['What should I do next?'])
        return ('There is no current approval assigned to your role for this initiative. Do not sign on another role’s behalf. Open My role decisions to see assigned work across the portfolio.', 'controls',['What should I do next?'])
    if 'next' in q or 'start' in q or 'do now' in q or 'my task' in q or 'help me work' in q or 'deadline' in q or 'what should' in q or 'where do i' in q:
        if initiative is None and queue:
            return ('Start with your pending assigned work: '+' '.join(queue[:3])+' Review the underlying evidence before recording a decision.', 'controls', ['Which approvals are mine?', 'Explain this page'])
        label,target,detail=next_work(role,initiative,contracts,controls,can_generate)
        return (detail+' Open '+label+' to continue.',target,['Explain this page','What needs approval?'])
    if any(s in q for s in ('who am i','my role','responsibilit','what can i','what do i own')):
        return (f'You are working as {role_help.get("focus",role)}. {role_help.get("next_step","")} {role_help.get("boundary","")}',page,['What should I do next?','Which approvals are mine?'])
    if any(s in q for s in ('missing','blocked','complete stage','advance','status of initiative','stage gate','ready')):
        if not initiative:
            return ('Select an initiative first. I can then explain its current stage, required contracts and the decisions assigned to your role.', 'initiatives',['What should I do next?'])
        stage=initiative.current_stage
        required=[a for a in contracts if a.stage==stage and a.status!='approved']
        pending=[c for c in controls if c['mandatory'] and c['decision']!='approved' and (c['role']==role or perms.get('can_view_financials'))]
        pieces=[f'Current stage: {STAGE_TITLES.get(stage,stage)}.']
        if required:pieces.append(f'{len(required)} generated contract(s) are still awaiting review.')
        if pending:pieces.append(f'{len(pending)} applicable mandatory role decision(s) are still pending in your authorized view.')
        pieces.append('The workflow will advance after all mandatory current-stage controls and contract approvals are satisfied.')
        return (' '.join(pieces),'initiative',['What should I do next?','Which evidence is required?'])
    if any(s in q for s in ('test','qa','quality','defect')):
        return ('QA checks requirements, negative scenarios, integration behavior, regression, security-sensitive flows and observed test results. Planned test cases begin not_run; report a pass only when execution logs prove it. Human QA independently reviews the evidence.', 'reference',['What needs approval?','What should I do next?'])
    if any(s in q for s in ('contract','brd','prd','markdown','document')):
        return ('Each stage produces a versioned Markdown contract linked to its parent requirements and initiative. The authorized author edits it; the assigned reviewer approves its exact version. Changes can invalidate earlier approvals.', 'contracts',['What should I do next?','Explain RACI'])
    if any(s in q for s in ('metric','kpi','baseline','target','benefit','roi','outcome')):
        return ('Baseline is the verified starting KPI; target is the intended result; actual is measured after release. Keep measurement source, unit, frequency and benefit owner consistent. Predicted benefits are not realized cash or operational results.', 'reference',['What should I do next?'])
    if any(s in q for s in ('integration','jira','github','confluence','sharepoint','openai','llm','connector')):
        return ('The application can simulate connectors and has limited live publish/verification actions when separately configured. Connected systems stay authoritative for their own data. Check connector mode before claiming a remote action occurred.', 'integrations' if perms.get('view_connectors') else 'guide',['How do approvals work?'])
    label,target,detail=next_work(role,initiative,contracts,controls,can_generate)
    return (f'{page_help["meaning"]} {role_help.get("next_step","")} Next: {detail} {page_help.get("safe_note","")}',target,['What should I do next?','Explain this page','What needs approval?'])
