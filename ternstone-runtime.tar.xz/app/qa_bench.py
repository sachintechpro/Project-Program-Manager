"""Read-only release evidence and bounded in-process readiness checks."""
import json
from pathlib import Path
from sqlalchemy import text

PATH=Path(__file__).resolve().parent.parent/'seed'/'qa'/'release_report.json'

def qa_report_payload():
    return json.loads(PATH.read_text(encoding='utf-8'))

def qa_smoke_payload(db,base):
    checks=[]
    def c(name,fn):
        try:fn();checks.append({'check':name,'status':'pass'})
        except Exception as e:checks.append({'check':name,'status':'fail','detail':type(e).__name__})
    c('Database query',lambda:db.execute(text('SELECT 1')).scalar_one()==1 or (_ for _ in ()).throw(ValueError('Unexpected database result')))
    c('Application HTML',lambda:(base/'app/static/index.html').is_file() or (_ for _ in ()).throw(FileNotFoundError()))
    c('Frontend scripts',lambda:all((base/'app/static'/f).is_file() for f in ('app.js','map_ui.js','qa_bench.js')) or (_ for _ in ()).throw(FileNotFoundError()))
    c('QA release report',lambda: bool(qa_report_payload().get('tests')) or (_ for _ in ()).throw(ValueError('Missing evidence')))
    c('Insurance reference CSVs',lambda:all((base/'seed/data'/f).is_file() for f in ('initiatives.csv','test_cases.csv','schema.json')) or (_ for _ in ()).throw(FileNotFoundError()))
    return {'overall':'PASS' if all(x['status']=='pass' for x in checks) else 'FAIL','checks':checks,'scope':'safe in-process checks only; not load/stress or external connectivity','real_time':True}
