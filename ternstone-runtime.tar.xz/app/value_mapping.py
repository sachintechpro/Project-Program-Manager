"""Value stream mapping: modeling and schema validation (illustrative, not insurer facts)."""
from pathlib import Path
from copy import deepcopy
import json,csv

ROOT=Path(__file__).resolve().parents[1]
MAP_DIR=ROOT/'seed'/'maps'

def reference_evidence(stream_key):
    """Read verified-schema, illustrative process references; never declare these real observations."""
    tables={}
    for name in ('step_evidence','role_review_guidance','workshop_questions'):
        path=MAP_DIR/(name+'.csv')
        with path.open(encoding='utf-8',newline='') as f:
            tables[name]=[r for r in csv.DictReader(f) if r['stream_key']==stream_key]
    return {'steps':{r['state']+':'+r['step_id']:r for r in tables['step_evidence']},
            'review_roles':{r['review_role']:r for r in tables['role_review_guidance']},
            'workshop_questions':tables['workshop_questions']}

def seed_map(key,**_):
    p=MAP_DIR/(key+'.json')
    if p.exists():return json.loads(p.read_text(encoding='utf-8'))
    return {'reference':'blank/custom','modeled':True,'value':{
       'customer':'Who receives value?','statement':'What useful outcome do they receive?',
       'trigger':'Which event starts the workflow?','outcome':'What means it is done?',
       'boundary':'Define first and final business steps','exclusions':'What is out of scope?',
       'guardrails':'Which human, compliance and quality controls are mandatory?'},
       'monthly_volume':0,'clock':'elapsed clock hours','metric':'End-to-end elapsed hours',
       'unit':'hours','note':'New stream: replace the starter figures with verified baseline evidence.',
       'invited_roles':['business_owner','value_owner','product_manager','product_owner','program_manager','rte','architect','integration','qa','security','ops','customer_care','analytics'],
       'review_roles':['business_owner','value_owner','product_manager','architect','qa','ops','analytics'],
       'agenda':['Agree customer value','Confirm process boundaries','Verify queues and handoffs','Review safe future state'],
       'candidate_initiatives':['Investigate the largest verified waiting-time bottleneck'],
       'current':[make_step('C1','Request received','product_owner',1,5,94,'Confirm baseline'),make_step('C2','Work performed','business_owner',2,8,93,'Confirm bottleneck'),make_step('C3','Outcome delivered','ops',1,4,98,'Confirm handoff')],
       'future':[make_step('F1','Request received','product_owner',1,2,98,'Validate proposed change'),make_step('F2','Work performed','business_owner',2,3,98,'Validate proposed change'),make_step('F3','Outcome delivered','ops',1,1,99,'Validate proposed change')]}

def make_step(id,name,owner,touch,wait,quality,problem='',system='Enterprise workflow'):
    return {'id':id,'name':name,'owner_role':owner,'system':system,
            'touch_hours':touch,'wait_hours':wait,'first_pass_pct':quality,
            'problem':problem,'improvement':''}

def measures(steps):
    active=round(sum(float(x['touch_hours']) for x in steps),2)
    wait=round(sum(float(x['wait_hours']) for x in steps),2)
    total=round(active+wait,2)
    fty=100.
    for x in steps:fty*=float(x['first_pass_pct'])/100
    return {'touch_hours':active,'wait_hours':wait,'elapsed_hours':total,
            'flow_efficiency_pct':round(100*active/total,1) if total else 0,
            'modeled_first_pass_pct':round(fty,1)}

def validate_map(doc):
    if not isinstance(doc,dict):raise ValueError('Map must be an object')
    value=doc.get('value')
    if not isinstance(value,dict):raise ValueError('Value definition is required')
    for k in ('customer','statement','trigger','outcome','boundary','exclusions','guardrails'):
        if not isinstance(value.get(k),str) or len(value[k])>2500:raise ValueError('Invalid value field: '+k)
    volume=doc.get('monthly_volume')
    if isinstance(volume,bool) or not isinstance(volume,(float,int)) or not 0<=volume<=100000000:raise ValueError('Invalid monthly volume')
    for state in ('current','future'):
        steps=doc.get(state)
        if not isinstance(steps,list) or not 2<=len(steps)<=12:raise ValueError('Each state needs 2–12 steps')
        seen=set()
        for s in steps:
            if not isinstance(s,dict):raise ValueError('Invalid process step')
            for name in ('id','name','owner_role','system','problem','improvement'):
                if not isinstance(s.get(name),str) or len(s[name])>800:raise ValueError('Invalid step field: '+name)
            if not s['id'] or s['id'] in seen or not s['name']:raise ValueError('Step names and IDs must be unique and nonempty')
            if s['owner_role'] not in doc.get('invited_roles',[]):raise ValueError('Step owner must be one of the stream stakeholders: '+s['owner_role'])
            seen.add(s['id'])
            for name in ('touch_hours','wait_hours','first_pass_pct'):
                n=s.get(name)
                if isinstance(n,bool) or not isinstance(n,(int,float)) or not 0<=n<=50000:raise ValueError('Invalid numeric step field: '+name)
            if s['first_pass_pct']>100:raise ValueError('First-pass percent must not exceed 100')
        if measures(steps)['elapsed_hours']==0:raise ValueError('Elapsed time must be positive')
    return True

def recommendations(doc):
    total=measures(doc['current'])['elapsed_hours'] or 1
    ranked=sorted(doc['current'],key=lambda s:s['wait_hours'],reverse=True)[:3]
    return [{'id':s['id'],'step':s['name'],'wait_hours':s['wait_hours'],'share_pct':round(100*s['wait_hours']/total,1),
             'problem':s['problem'],'action':next((x['improvement'] for x in doc['future'] if x['name']==s['name']), 'Investigate and redesign this handoff'),
             'owner_role':s['owner_role']} for i,s in enumerate(ranked)]

def markdown_report(stream,doc,meetings,reviews,version,responses=None):
    curr,future=measures(doc['current']),measures(doc['future'])
    parts=[f'# Value stream map — {stream.name}',f'\nRevision: {version}',f'Reference basis: {doc.get("reference","manual")}',
           'Status: planning assumptions; no measured operating improvement is claimed.',
           '\n## What value does this stream deliver?']
    for k,v in doc['value'].items():parts.append(f'- **{k.replace("_"," ").title()}:** {v}')
    parts+=['\n## Summary','| Metric | Current modeled | Future proposed |','|---|---:|---:|']
    for name,key in [('Elapsed clock hours','elapsed_hours'),('Touch hours','touch_hours'),('Waiting hours','wait_hours'),('Flow efficiency %','flow_efficiency_pct'),('Modeled first-pass %','modeled_first_pass_pct')]:parts.append(f'| {name} | {curr[key]} | {future[key]} |')
    for state in ('current','future'):
        parts += [f'\n## {state.title()} map','| Step | Owner | System | Touch h | Wait h | First-pass % | Issue / proposed change |','|---|---|---|---:|---:|---:|---|']
        for s in doc[state]:parts.append('| '+' | '.join(str(v).replace('|','/') for v in (s['name'],s['owner_role'],s['system'],s['touch_hours'],s['wait_hours'],s['first_pass_pct'],s.get('problem') or s.get('improvement','')))+' |')
    parts+=['\n## Improvement candidates']+['- '+x for x in doc.get('candidate_initiatives',[])]
    parts+=['\n## Workshop history']
    if not meetings:parts.append('No actual workshop recorded; suggested agenda is not evidence of an actual meeting.')
    for m in meetings:parts+=['\n### '+m.title+' — '+m.meeting_date, f'Recorder: {m.author_name}',f'Invited roles: {m.invited_roles}',f'Attended roles: {m.attended_roles}',f'Notes: {m.notes}',f'Decisions: {m.decisions}',f'Actions: {m.actions}']
    parts+=['\n## Review decisions for this map revision']
    if not reviews:parts.append('No current-revision reviews.')
    for r in reviews:
        parts.append(f'- {r.role}: {r.decision}; {r.actor_name}; {r.comment}')
        if responses and r.id in responses:
            answer=responses[r.id]
            parts.append(f'  - Facilitator response by {answer.author_name}: {answer.response}; evidence: {answer.evidence_reference}')
    parts+=['\n## Measurement caveats','All numbers are illustrative estimates. Summing step estimates is not the same as measuring the median of actual end-to-end cases. First-pass yield multiplies step rates under a simplifying assumption; verify with observed case-level data.']
    return '\n'.join(parts)+'\n'
