"""Ternstone ValueOps — role-governed, evidence-linked value stream delivery demo.
Single organization app. No real company data is included.
"""
import os, json, re, hmac, hashlib, secrets, io, zipfile, html, datetime, base64, asyncio
from pathlib import Path
from typing import Optional, Any
from urllib.parse import urlparse
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, Text, Float, ForeignKey, Boolean, DateTime, select, func
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from cryptography.fernet import Fernet
import httpx
from .catalog import ROLES, ROLE_LOOKUP, STAGES, STAGE_IDS, STREAM_TEMPLATES, INITIATIVE_TEMPLATES, INIT_MAP, DEMO_USERS, contract_text
from .enterprise_data import preview as scenario_preview, doc_appendix, table as scenario_table, schemas as scenario_schemas
from .control_policy import controls_for
from .role_policy import ROLE_DOCS, ROLE_WORKSPACES, CREATE_STREAM, CREATE_INITIATIVE, VIEW_CONNECTORS, MANAGE_CONNECTORS, PUBLISH_CONTRACT, APPROVAL_OVERSIGHT, AUDIT_VIEW, AUDIT_FULL, AGENT_DRAFT, STAGE_GENERATORS

BASE=Path(__file__).resolve().parent.parent
DEMO=os.getenv('DEMO_MODE','true').lower()=='true'
SECRET=os.getenv('SECRET_KEY') or ('unsafe-local-demo-only-key' if DEMO else None)
if not SECRET: raise RuntimeError('SECRET_KEY required outside demo')
ENCRYPTION_KEY=os.getenv('ENCRYPTION_KEY')
FERNET=Fernet(ENCRYPTION_KEY.encode()) if ENCRYPTION_KEY else None
DB_URL=os.getenv('DATABASE_URL','sqlite:///./valueops.db')
if DB_URL.startswith('postgres://'): DB_URL='postgresql+psycopg://'+DB_URL[len('postgres://'):]
if DB_URL.startswith('postgresql://'): DB_URL='postgresql+psycopg://'+DB_URL[len('postgresql://'):]
engine=create_engine(DB_URL, connect_args={'check_same_thread':False} if DB_URL.startswith('sqlite') else {},pool_pre_ping=True)
SessionLocal=sessionmaker(bind=engine,autoflush=False,expire_on_commit=False)
BaseModelDB=declarative_base()
def now():return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
def utcstr(dt):return dt.replace(tzinfo=datetime.timezone.utc).isoformat() if dt else None

class User(BaseModelDB):
    __tablename__='users'
    id=Column(Integer,primary_key=True); name=Column(String(120),nullable=False); email=Column(String(200),unique=True,nullable=False); role=Column(String(80),nullable=False); password_hash=Column(String(250),nullable=False); active=Column(Boolean,default=True)
class ValueStream(BaseModelDB):
    __tablename__='value_streams'
    id=Column(Integer,primary_key=True); key=Column(String(120),unique=True,nullable=False); name=Column(String(200),nullable=False); lob=Column(String(300)); owner=Column(String(200)); description=Column(Text); theme=Column(Text); metric=Column(String(200)); baseline=Column(Float,default=0); target=Column(Float,default=0); budget=Column(Float,default=0); created_at=Column(DateTime,default=now)
class Initiative(BaseModelDB):
    __tablename__='initiatives'
    id=Column(Integer,primary_key=True); key=Column(String(120),unique=True,nullable=False); value_stream_id=Column(Integer,ForeignKey('value_streams.id'),nullable=False); title=Column(String(220),nullable=False); lob=Column(String(160)); budget=Column(Float,default=0); annual_benefit=Column(Float,default=0); baseline=Column(Float,default=0); target=Column(Float,default=0); unit=Column(String(30),default='days'); volume=Column(String(180),default=''); workflow=Column(Text,default=''); rules=Column(Text,default=''); risk=Column(Text,default=''); dependencies=Column(Text,default=''); current_stage=Column(String(60),default='portfolio'); status=Column(String(40),default='active'); created_at=Column(DateTime,default=now)
class Artifact(BaseModelDB):
    __tablename__='artifacts'
    id=Column(Integer,primary_key=True); initiative_id=Column(Integer,ForeignKey('initiatives.id'),nullable=False); kind=Column(String(80),nullable=False); stage=Column(String(60),nullable=False); markdown=Column(Text,nullable=False); version=Column(Integer,default=1); status=Column(String(30),default='draft'); hash=Column(String(64)); author=Column(String(120)); reviewer=Column(String(80)); approved_by=Column(String(120)); approved_at=Column(DateTime); updated_at=Column(DateTime,default=now)
class ArtifactRevision(BaseModelDB):
    __tablename__='artifact_revisions'
    id=Column(Integer,primary_key=True); artifact_id=Column(Integer,ForeignKey('artifacts.id'),nullable=False); version=Column(Integer,nullable=False); markdown=Column(Text,nullable=False); hash=Column(String(64),nullable=False); author=Column(String(120)); created_at=Column(DateTime,default=now)
class Approval(BaseModelDB):
    __tablename__='approvals'
    id=Column(Integer,primary_key=True); artifact_id=Column(Integer,ForeignKey('artifacts.id'),nullable=False); version=Column(Integer,nullable=False); reviewer_id=Column(Integer,ForeignKey('users.id'),nullable=False); decision=Column(String(30)); comment=Column(Text); content_hash=Column(String(64)); created_at=Column(DateTime,default=now)
class AuditEvent(BaseModelDB):
    __tablename__='audit_events'
    id=Column(Integer,primary_key=True); user_id=Column(Integer); actor=Column(String(120)); action=Column(String(120)); target=Column(String(120)); details=Column(Text); prev_hash=Column(String(64)); hash=Column(String(64)); created_at=Column(DateTime,default=now)
class RegisterItem(BaseModelDB):
    __tablename__='management_registers'
    id=Column(Integer,primary_key=True)
    kind=Column(String(16),nullable=False)  # raci or raid
    initiative_id=Column(Integer,ForeignKey('initiatives.id'),nullable=True)
    value_stream_id=Column(Integer,ForeignKey('value_streams.id'),nullable=True)
    title=Column(String(250),nullable=False)
    fields=Column(Text,nullable=False)
    author_id=Column(Integer,ForeignKey('users.id'),nullable=False)
    author_role=Column(String(80),nullable=False)
    version=Column(Integer,default=1)
    created_at=Column(DateTime,default=now)
    updated_at=Column(DateTime,default=now)
class RegisterRevision(BaseModelDB):
    __tablename__='management_register_revisions'
    id=Column(Integer,primary_key=True)
    item_id=Column(Integer,ForeignKey('management_registers.id'),nullable=False)
    version=Column(Integer,nullable=False)
    payload=Column(Text,nullable=False)
    digest=Column(String(64),nullable=False)
    author_id=Column(Integer,nullable=False)
    created_at=Column(DateTime,default=now)
class ManagedRecord(BaseModelDB):
    __tablename__='managed_record_versions'
    id=Column(Integer,primary_key=True)
    resource_type=Column(String(30),nullable=False)
    resource_id=Column(Integer,nullable=False)
    author_id=Column(Integer,nullable=False)
    author_role=Column(String(80),nullable=False)
    version=Column(Integer,default=1)
class ManagedRecordRevision(BaseModelDB):
    __tablename__='managed_record_revisions'
    id=Column(Integer,primary_key=True)
    managed_id=Column(Integer,ForeignKey('managed_record_versions.id'),nullable=False)
    version=Column(Integer,nullable=False)
    state=Column(Text,nullable=False)
    author_id=Column(Integer,nullable=False)
    digest=Column(String(64),nullable=False)
    created_at=Column(DateTime,default=now)

class ScenarioLink(BaseModelDB):
    __tablename__='scenario_links'
    id=Column(Integer,primary_key=True)
    initiative_id=Column(Integer,ForeignKey('initiatives.id'),unique=True,nullable=False)
    template_key=Column(String(120),nullable=False)
    created_at=Column(DateTime,default=now)

class ScenarioRecord(BaseModelDB):
    __tablename__='initiative_reference_records'
    id=Column(Integer,primary_key=True)
    initiative_id=Column(Integer,ForeignKey('initiatives.id'),nullable=False)
    table_name=Column(String(80),nullable=False)
    source_record_id=Column(String(150),nullable=False)
    payload=Column(Text,nullable=False)
    author_id=Column(Integer,ForeignKey('users.id'),nullable=False)
    version=Column(Integer,default=1)
    updated_at=Column(DateTime,default=now)

class ScenarioRecordRevision(BaseModelDB):
    __tablename__='initiative_reference_revisions'
    id=Column(Integer,primary_key=True)
    record_id=Column(Integer,ForeignKey('initiative_reference_records.id'),nullable=False)
    version=Column(Integer,nullable=False)
    payload=Column(Text,nullable=False)
    digest=Column(String(64),nullable=False)
    author_id=Column(Integer,nullable=False)
    created_at=Column(DateTime,default=now)

class ControlReview(BaseModelDB):
    __tablename__='role_control_reviews'
    id=Column(Integer,primary_key=True)
    initiative_id=Column(Integer,ForeignKey('initiatives.id'),nullable=False)
    stage=Column(String(50),nullable=False)
    control_code=Column(String(100),nullable=False)
    role=Column(String(80),nullable=False)
    actor_id=Column(Integer,ForeignKey('users.id'),nullable=False)
    actor_name=Column(String(120),nullable=False)
    decision=Column(String(30),nullable=False)
    comment=Column(Text,default='')
    evidence_ref=Column(String(350),default='')
    input_digest=Column(String(64),nullable=False)
    created_at=Column(DateTime,default=now)

class Connector(BaseModelDB):
    __tablename__='connectors'
    id=Column(Integer,primary_key=True); provider=Column(String(40),unique=True); mode=Column(String(20),default='simulated'); config_encrypted=Column(Text); label=Column(String(100)); status=Column(String(40),default='configured'); last_check=Column(DateTime)

app=FastAPI(title='Ternstone ValueOps',version='0.4.0',docs_url='/api/docs' if DEMO else None,redoc_url=None)
app.mount('/assets',StaticFiles(directory=str(BASE/'app'/'static')),name='static')
serializer=URLSafeTimedSerializer(SECRET,salt='valueops-session')

def db_session():
    with SessionLocal() as db: yield db

def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def password_hash(p):
    salt=secrets.token_hex(16);digest=hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(salt),220_000).hex();return salt+':'+digest
def password_check(p,stored):
    try:
        salt,digest=stored.split(':');actual=hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(salt),220_000).hex();return hmac.compare_digest(actual,digest)
    except Exception:return False

def log(db,user,action,target,details=None):
    # Hash-chained audit events; PostgreSQL production deployments should serialize writers per org.
    last=db.execute(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(1)).scalar_one_or_none()
    prev=last.hash if last else 'GENESIS'; actor=user.name if user else 'system'
    timestamp=now()
    obj={'actor':actor,'action':action,'target':target,'details':details or {},'previous':prev,'time':timestamp.isoformat()}
    payload=json.dumps(obj,sort_keys=True,default=str)
    e=AuditEvent(user_id=getattr(user,'id',None),actor=actor,action=action,target=target,details=json.dumps(details or {},default=str),prev_hash=prev,hash=sha(payload),created_at=timestamp)
    db.add(e);db.flush();return e

def get_user(request:Request,db:Session=Depends(db_session)):
    cookie=request.cookies.get('ternstone_session')
    if not cookie:raise HTTPException(401,'Sign in to continue')
    try:p=serializer.loads(cookie,max_age=60*60*10)
    except (BadSignature,SignatureExpired):raise HTTPException(401,'Session expired; sign in again')
    user=db.get(User,p.get('uid'))
    if not user or not user.active:raise HTTPException(401,'Account unavailable')
    request.state.csrf=p.get('csrf');return user

def guard(request:Request,user:User=Depends(get_user)):
    if request.method in ('POST','PUT','PATCH','DELETE'):
        if not hmac.compare_digest(request.headers.get('x-csrf-token',''),request.state.csrf or ''):
            raise HTTPException(403,'Missing or invalid CSRF token')
    return user

def role_required(user,*roles):
    if user.role not in roles:raise HTTPException(403,'This action requires '+', '.join(roles))

# Financial visibility is intentionally separate from technical/quality responsibilities.
# The platform administrator has infrastructure privileges, not automatic financial access.
REGISTER_AUTHORS = {
    'raci':frozenset({'program_manager','rte','vmo','value_owner','product_owner'}),
    'raid':frozenset({'program_manager','rte','vmo','value_owner','product_owner','team_coach','fde','qa','risk','release','ops','vendor'})
}
REGISTER_READERS = frozenset(ROLE_LOOKUP) - {'admin'}
RECORD_EDIT_ROLES=frozenset({'program_manager','lpm','vmo','value_owner','epic_owner','product_manager'})

FINANCIAL_ROLES = frozenset({'executive','lpm','vmo','finance','epic_owner','business_owner','value_owner','product_manager','program_manager','analytics'})
FINANCIAL_ARTIFACTS = frozenset({'portfolio-epic','lean-business-case','benefits-report'})
def can_view_financials(user): return user.role in FINANCIAL_ROLES
def require_business_data_access(user):
    if user.role=='admin':raise HTTPException(403,'Platform administration does not grant business data access')
def visible_stream(v,user):
    data=stream_obj(v)
    if not can_view_financials(user): data.pop('budget',None)
    return data
def visible_initiative(i,stream,user):
    data=init_obj(i,stream)
    if not can_view_financials(user):
        data.pop('budget',None)
        data.pop('annual_benefit',None)
    if user.role=='customer_care':
        for field in ('rules','risk','dependencies'):data.pop(field,None)
    if user.role=='vendor':
        for field in ('rules','risk'):data.pop(field,None)
    return data
def can_read_artifact(a,user):
    return a.kind in ROLE_DOCS.get(user.role,frozenset()) and (a.kind not in FINANCIAL_ARTIFACTS or can_view_financials(user))
def assert_can_read_artifact(a,user):
    if not can_read_artifact(a,user):raise HTTPException(403,'This contract is outside your assigned role access')

def stream_obj(v):return {'id':v.id,'key':v.key,'name':v.name,'lob':v.lob,'owner':v.owner,'description':v.description,'theme':v.theme,'metric':v.metric,'baseline':v.baseline,'target':v.target,'budget':v.budget,'created_at':utcstr(v.created_at)}
def init_obj(i,stream=None):return {'id':i.id,'key':i.key,'value_stream_id':i.value_stream_id,'stream_name':stream.name if stream else None,'title':i.title,'lob':i.lob,'budget':i.budget,'annual_benefit':i.annual_benefit,'baseline':i.baseline,'target':i.target,'unit':i.unit,'volume':i.volume,'workflow':i.workflow,'rules':i.rules,'risk':i.risk,'dependencies':i.dependencies,'current_stage':i.current_stage,'status':i.status,'created_at':utcstr(i.created_at)}
def artifact_obj(a):return {'id':a.id,'initiative_id':a.initiative_id,'kind':a.kind,'stage':a.stage,'markdown':a.markdown,'version':a.version,'status':a.status,'hash':a.hash,'author':a.author,'reviewer':a.reviewer,'approved_by':a.approved_by,'approved_at':utcstr(a.approved_at),'updated_at':utcstr(a.updated_at)}
def needed(i):return STAGES[STAGE_IDS.index(i.current_stage)]['artifacts'] if i.current_stage!='closed' else []

def seed_demo(db):
    if db.execute(select(User.id).limit(1)).first():return
    for n,r,_ in DEMO_USERS:
        slug=re.sub(r'[^a-z0-9]+','.',n.lower())
        db.add(User(name=n,email=slug+'@ternstone.demo',role=r,password_hash=password_hash('DemoPass!2026')))
    db.flush()
    user_by_role={u.role:u for u in db.execute(select(User)).scalars().all()}
    streams={}
    for t in STREAM_TEMPLATES:
        v=ValueStream(**t);db.add(v);db.flush();streams[t['key']]=v
    for temp in INITIATIVE_TEMPLATES:
        data={k:v for k,v in temp.items() if k not in ('stream','status')};i=Initiative(**data,value_stream_id=streams[temp['stream']].id,current_stage=temp['status']);db.add(i);db.flush()
        # Previous stages are seeded as reviewed illustrative stage history; current stage remains actionable.
        end=STAGE_IDS.index(temp['status'])
        for si in range(end+1):
            st=STAGES[si]
            for kind,title,writer,reviewer in st['artifacts']:
                content=contract_text(kind, data, {**stream_obj(streams[temp['stream']]),'theme':streams[temp['stream']].theme})
                a=Artifact(initiative_id=i.id,kind=kind,stage=st['id'],markdown=content,hash=sha(content),version=1,status='approved' if si<end else 'draft',author='Synthetic sample',reviewer=reviewer,updated_at=now(),approved_by='Synthetic example' if si<end else None,approved_at=now() if si<end else None)
                db.add(a);db.flush()
                db.add(ArtifactRevision(artifact_id=a.id,version=1,markdown=content,hash=a.hash,author=a.author))
                if si<end:
                    rv=user_by_role.get(reviewer)
                    if rv:db.add(Approval(artifact_id=a.id,version=1,reviewer_id=rv.id,decision='approved',comment='Illustrative prior stage approval (seed data only)',content_hash=a.hash))
        log(db,None,'initiative.seeded',f'INIT-{i.id}',{'scenario':i.key,'stage':i.current_stage,'synthetic':True})
    for p in ['jira','confluence','sharepoint','github','openai']:
        db.add(Connector(provider=p,mode='simulated',label=p.title(),status='simulated'))
    db.commit()

def setup():
    BaseModelDB.metadata.create_all(engine)
    with SessionLocal() as db:
        if DEMO:
            seed_demo(db)
            seed_register_examples(db)
            for base in INITIATIVE_TEMPLATES:
                seeded=db.execute(select(Initiative).where(Initiative.key==base['key'])).scalar_one_or_none()
                if seeded and not db.execute(select(ScenarioLink.id).where(ScenarioLink.initiative_id==seeded.id)).first():
                    db.add(ScenarioLink(initiative_id=seeded.id,template_key=base['key']))
            existing_roles={u.role for u in db.execute(select(User)).scalars().all()}
            for n,r,_ in DEMO_USERS:
                if r not in existing_roles:
                    slug=re.sub(r'[^a-z0-9]+','.',n.lower())
                    db.add(User(name=n,email=slug+'@ternstone.demo',role=r,password_hash=password_hash('DemoPass!2026')))
                    existing_roles.add(r)
            db.commit()
        else:
            email=os.getenv('ADMIN_EMAIL');pw=os.getenv('ADMIN_PASSWORD')
            if not (email and pw and len(pw)>=14): raise RuntimeError('Set ADMIN_EMAIL and strong ADMIN_PASSWORD for production')
            if not db.execute(select(User).limit(1)).first():
                db.add(User(name='Platform Administrator',email=email,role='admin',password_hash=password_hash(pw)));db.commit()
            for p in ['jira','confluence','sharepoint','github','openai']:
                if not db.execute(select(Connector).where(Connector.provider==p)).scalar_one_or_none():db.add(Connector(provider=p,mode='simulated',label=p.title(),status='simulated'))
            db.commit()

@app.on_event('startup')
def startup():setup()

@app.get('/')
def root():return FileResponse(BASE/'app'/'static'/'index.html')
@app.get('/health')
def health():return {'status':'ok','service':'ternstone-valueops','mode':'demo' if DEMO else 'production'}
@app.get('/api/public')
def public():return {'demo':DEMO,'roles':list(ROLE_LOOKUP.values()),'personas':[{'name':n,'role':r,'email':re.sub(r'[^a-z0-9]+','.',n.lower())+'@ternstone.demo'} for n,r,_ in DEMO_USERS] if DEMO else [],'company':'Ternstone Specialty Insurance'}
class LoginReq(BaseModel):
    email:str='';password:str='';role:str=''
@app.post('/api/login')
def login(req:LoginReq,db:Session=Depends(db_session)):
    if DEMO and req.role:
        user=db.execute(select(User).where(User.role==req.role).order_by(User.id).limit(1)).scalar_one_or_none()
    else:
        user=db.execute(select(User).where(User.email==req.email.strip().lower())).scalar_one_or_none()
        if not user or not password_check(req.password,user.password_hash):raise HTTPException(401,'Invalid credentials')
    if not user:raise HTTPException(401,'Unknown demo role')
    csrf=secrets.token_urlsafe(24);token=serializer.dumps({'uid':user.id,'csrf':csrf})
    resp=Response(content=json.dumps({'user':{'name':user.name,'role':user.role,'email':user.email},'csrf':csrf}),media_type='application/json')
    resp.set_cookie('ternstone_session',token,max_age=36000,httponly=True,secure=os.getenv('SECURE_COOKIES','false').lower()=='true',samesite='lax')
    return resp
@app.post('/api/logout')
def logout(request:Request,user:User=Depends(guard)):
    resp=Response(content='{}',media_type='application/json');resp.delete_cookie('ternstone_session');return resp
@app.get('/api/me')
def me(request:Request,user:User=Depends(get_user)):
    return {'name':user.name,'email':user.email,'role':user.role,'csrf':request.state.csrf,'demo':DEMO,'role_name':ROLE_LOOKUP[user.role]['name'], 'can_view_financials':can_view_financials(user), 'accessible_artifact_kinds':sorted(ROLE_DOCS.get(user.role, ())), 'permissions':{
        'create_stream':user.role in CREATE_STREAM,
        'create_initiative':user.role in CREATE_INITIATIVE,
        'view_connectors':user.role in VIEW_CONNECTORS,
        'manage_connectors':user.role in MANAGE_CONNECTORS,
        'publish_contract':user.role in PUBLISH_CONTRACT,
        'see_all_approvals':user.role in APPROVAL_OVERSIGHT,
        'view_audit':user.role in AUDIT_VIEW,
        'agent_draft':user.role in AGENT_DRAFT,
        'register_author_raci': user.role in REGISTER_AUTHORS['raci'],
        'register_author_raid': user.role in REGISTER_AUTHORS['raid'],
        'edit_records': user.role in RECORD_EDIT_ROLES,
        'reviewer':any(any(a[3]==user.role for a in stage['artifacts']) for stage in STAGES), 'control_reviewer':True
    }}
class NewUser(BaseModel):
    name:str=Field(min_length=3,max_length=120)
    email:str=Field(min_length=6,max_length=200)
    role:str
    password:str=Field(min_length=14,max_length=128)
@app.get('/api/users')
def list_users(user:User=Depends(get_user),db:Session=Depends(db_session)):
    role_required(user,'admin')
    rows=db.execute(select(User).order_by(User.name)).scalars().all()
    return [{'id':u.id,'name':u.name,'email':u.email,'role':u.role,'active':u.active} for u in rows]
@app.post('/api/users')
def create_user(req:NewUser,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'admin')
    if req.role not in ROLE_LOOKUP:raise HTTPException(422,'Unknown organizational role')
    email=req.email.strip().lower()
    if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email):raise HTTPException(422,'Invalid email')
    if db.execute(select(User).where(User.email==email)).scalar_one_or_none():raise HTTPException(409,'Email is already registered')
    u=User(name=req.name.strip(),email=email,role=req.role,password_hash=password_hash(req.password))
    db.add(u);db.flush();log(db,user,'user.created',f'USER-{u.id}',{'role':u.role,'email':u.email});db.commit()
    return {'id':u.id,'name':u.name,'email':u.email,'role':u.role}
@app.post('/api/users/{uid}/disable')
def disable_user(uid:int,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'admin')
    if user.id==uid:raise HTTPException(409,'Cannot disable your own account')
    u=db.get(User,uid)
    if not u:raise HTTPException(404,'User not found')
    u.active=False;log(db,user,'user.disabled',f'USER-{uid}',{'role':u.role});db.commit()
    return {'id':uid,'active':False}

# --- Author-controlled program registers and editable intake records ---
def init_managed_record(db,typ,rid,user,state):
    r=ManagedRecord(resource_type=typ,resource_id=rid,author_id=user.id,author_role=user.role,version=1)
    db.add(r);db.flush()
    snapshot=json.dumps(state,sort_keys=True,default=str)
    db.add(ManagedRecordRevision(managed_id=r.id,version=1,state=snapshot,author_id=user.id,digest=sha(snapshot)))
    return r

def edit_meta(db,typ,rid,user):
    m=db.execute(select(ManagedRecord).where(ManagedRecord.resource_type==typ,ManagedRecord.resource_id==rid)).scalar_one_or_none()
    authorized=(user.role in RECORD_EDIT_ROLES and (not m or (m.author_id==user.id and m.author_role==user.role)))
    if typ=='stream':
        authorized=authorized and not db.execute(select(Initiative.id).where(Initiative.value_stream_id==rid,Initiative.current_stage!='portfolio').limit(1)).first()
    elif typ=='initiative':
        i=db.get(Initiative,rid)
        authorized=authorized and i is not None and i.current_stage=='portfolio' and not db.execute(select(Artifact.id).where(Artifact.initiative_id==rid,Artifact.status=='approved').limit(1)).first()
    return {'version':m.version if m else 1,'can_edit':bool(authorized),'author_role':m.author_role if m else None}

def require_record_author(db,typ,rid,user):
    if user.role not in RECORD_EDIT_ROLES:raise HTTPException(403,'Your role has read-only access to this record')
    m=db.execute(select(ManagedRecord).where(ManagedRecord.resource_type==typ,ManagedRecord.resource_id==rid)).scalar_one_or_none()
    if m and (m.author_id!=user.id or m.author_role!=user.role):raise HTTPException(403,'Only the author may edit this record')
    if not m:  # existing seeded example, no historical individual author
        m=init_managed_record(db,typ,rid,user,{'seeded':True})
    return m

class EditStream(BaseModel):
    expected_version:int=Field(ge=1)
    name:str=Field(min_length=5,max_length=200)
    lob:str=Field(default='',max_length=300)
    owner:str=Field(default='',max_length=200)
    description:str=Field(default='',max_length=2500)
    theme:str=Field(default='',max_length=1000)
    metric:str=Field(default='',max_length=200)
    baseline:float=Field(ge=0)
    target:float=Field(ge=0)
    budget:Optional[float]=Field(default=None,ge=0,le=1e10)
class EditInitiative(BaseModel):
    expected_version:int=Field(ge=1)
    title:str=Field(min_length=7,max_length=220)
    lob:str=Field(default='',max_length=160)
    budget:Optional[float]=Field(default=None,ge=0,le=1e10)
    annual_benefit:Optional[float]=Field(default=None,ge=0,le=1e10)
    baseline:float=Field(ge=0)
    target:float=Field(ge=0)
    unit:str=Field(max_length=30)
    volume:str=Field(default='',max_length=180)
    workflow:str=Field(default='',max_length=3000)
    rules:str=Field(default='',max_length=3000)
    risk:str=Field(default='',max_length=2000)
    dependencies:str=Field(default='',max_length=1000)

def revise_managed(db,user,m,old,new):
    m.version+=1
    j=json.dumps(new,sort_keys=True,default=str)
    db.add(ManagedRecordRevision(managed_id=m.id,version=m.version,state=j,author_id=user.id,digest=sha(j)))
    log(db,user,f'{m.resource_type}.revised',f'{m.resource_type.upper()}-{m.resource_id}',{'version':m.version,'fields_changed':[k for k in new if old.get(k)!=new.get(k)],'sha256':sha(j)})

@app.put('/api/streams/{sid}')
def edit_stream(sid:int,req:EditStream,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    v=db.get(ValueStream,sid)
    if not v:raise HTTPException(404,'Value stream not found')
    m=require_record_author(db,'stream',sid,user)
    if m.version!=req.expected_version:raise HTTPException(409,'Value stream was modified. Refresh before editing')
    impacted=db.execute(select(Initiative).where(Initiative.value_stream_id==sid)).scalars().all()
    if any(i.current_stage!='portfolio' for i in impacted):
        raise HTTPException(409,'This stream has active approved initiatives. Change the approved scope through portfolio change control, not a silent edit')
    old=stream_obj(v)
    changes=req.model_dump(exclude={'expected_version'},exclude_none=True)
    for k,value in changes.items():setattr(v,k,value)
    revise_managed(db,user,m,old,stream_obj(v));db.commit()
    return dict(visible_stream(v,user),edit_meta=edit_meta(db,'stream',sid,user))

@app.put('/api/initiatives/{iid}')
def edit_initiative(iid:int,req:EditInitiative,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    m=require_record_author(db,'initiative',iid,user)
    if m.version!=req.expected_version:raise HTTPException(409,'Initiative was modified. Refresh before editing')
    arts=db.execute(select(Artifact).where(Artifact.initiative_id==iid)).scalars().all()
    if i.current_stage!='portfolio' or any(a.status=='approved' for a in arts):
        raise HTTPException(409,'Approved initiative contracts are read-only; use the formal change process to amend approved requirements')
    old=init_obj(i)
    changes=req.model_dump(exclude={'expected_version'},exclude_none=True)
    for k,value in changes.items():setattr(i,k,value)
    # Existing unapproved draft artifacts might contain the previous requirements. Force regeneration after editing.
    for a in arts:
        if a.status!='approved':
            v=db.get(ValueStream,i.value_stream_id)
            updated=contract_text(a.kind,init_obj(i),stream_obj(v))
            if updated!=a.markdown:
                a.markdown=updated;a.version+=1;a.hash=sha(updated);a.author='System: initiative amendment';a.status='draft';a.updated_at=now()
                db.add(ArtifactRevision(artifact_id=a.id,version=a.version,markdown=updated,hash=a.hash,author=a.author))
                log(db,user,'contract.refreshed_from_initiative',f'ART-{a.id}',{'version':a.version,'sha256':a.hash})
    sync_reference_summary(db,i,user,old)
    revise_managed(db,user,m,old,init_obj(i));db.commit()
    return dict(visible_initiative(i,None,user),edit_meta=edit_meta(db,'initiative',iid,user))

def seed_register_examples(db):
    """Create role-specific reference assignments, never overwrite user records."""
    if db.execute(select(RegisterItem.id).limit(1)).first():return
    author=db.execute(select(User).where(User.role=='program_manager')).scalar_one_or_none()
    if not author:return
    initiatives=db.execute(select(Initiative)).scalars().all()
    for i in initiatives:
        domain_role = 'claims_sme' if any(term in (i.lob or '').lower() for term in ('claim','marine','liability','cyber','cargo')) or i.key in ('property-cat','liability-reserves','cargo-surveyor','cyber-response') else 'actuarial'
        raci_rows = [
            ('Portfolio investment and prioritization',
             dict(responsible=['epic_owner','vmo'],accountable=['lpm'],consulted=['finance','value_owner'],informed=['program_manager','rte','product_manager'])),
            (f'{i.lob} business rules and acceptance',
             dict(responsible=['product_owner',domain_role],accountable=['business_owner'],consulted=['product_manager','risk'],informed=['rte','fde','program_manager'])),
            ('Solution design, build and integrations',
             dict(responsible=['fde','integration'],accountable=['architect'],consulted=['enterprise_architect','security','qa'],informed=['product_owner','rte','program_manager'])),
            ('Independent quality and security verification',
             dict(responsible=['qa','security'],accountable=['qa'],consulted=[domain_role,'architect'],informed=['product_owner','release','rte'])),
            ('Production release and operations handover',
             dict(responsible=['release','ops','customer_care'],accountable=['release'],consulted=['qa','security','product_owner'],informed=['business_owner','program_manager'])),
            ('Business benefits review and portfolio feedback',
             dict(responsible=['analytics','value_owner'],accountable=['value_owner'],consulted=['finance','customer_care',domain_role],informed=['lpm','vmo','program_manager'])),
        ]
        for title,fields in raci_rows:
            validate_register('raci',fields)
            x=RegisterItem(kind='raci',initiative_id=i.id,title=title,fields=json.dumps(fields,sort_keys=True),author_id=author.id,author_role=author.role,version=1)
            db.add(x);db.flush();payload=register_markdown(x)
            db.add(RegisterRevision(item_id=x.id,version=1,payload=payload,digest=sha(payload),author_id=author.id))
        risk=RegisterItem(kind='raid',initiative_id=i.id,title=i.risk[:160] or 'Delivery risk',
            fields=json.dumps({'type':'risk','priority':'high','status':'open','owner_role':'program_manager',
            'response':'Confirm risk controls, assign mitigation and validate acceptance criteria with the relevant SME.',
            'due_date':'','evidence_ref':''},sort_keys=True),author_id=author.id,author_role=author.role,version=1)
        db.add(risk);db.flush();payload=register_markdown(risk)
        db.add(RegisterRevision(item_id=risk.id,version=1,payload=payload,digest=sha(payload),author_id=author.id))
    log(db,None,'register.examples_seeded','PROGRAM-REGISTERS',{'initiatives':len(initiatives),'raci_records':6*len(initiatives),'synthetic':True})
    db.commit()

class NewRegisterItem(BaseModel):
    kind:str
    initiative_id:Optional[int]=None
    value_stream_id:Optional[int]=None
    title:str=Field(min_length=4,max_length=250)
    fields:dict
class EditRegisterItem(BaseModel):
    expected_version:int=Field(ge=1)
    title:str=Field(min_length=4,max_length=250)
    fields:dict

def validate_register(kind,fields):
    if kind=='raci':
        required=('responsible','accountable','consulted','informed')
        for k in required:
            if k not in fields or not isinstance(fields[k],list):raise HTTPException(422,f'{k}: list of role identifiers required')
            if any(r not in ROLE_LOOKUP for r in fields[k]):raise HTTPException(422,f'{k}: unknown role')
        if len(fields['accountable'])!=1:raise HTTPException(422,'Exactly one Accountable role is required')
        if not fields['responsible']:raise HTTPException(422,'At least one Responsible role is required')
        if any(len(v)!=len(set(v)) for v in (fields[k] for k in required)):raise HTTPException(422,'Duplicate roles are not allowed within a RACI category')
        fields={k:fields[k] for k in required}
    elif kind=='raid':
        if fields.get('type') not in ('risk','assumption','issue','dependency'):raise HTTPException(422,'Invalid RAID category')
        if fields.get('status') not in ('open','monitoring','mitigating','escalated','resolved','closed'):raise HTTPException(422,'Invalid RAID status')
        if fields.get('priority') not in ('low','medium','high','critical'):raise HTTPException(422,'Invalid priority')
        if fields.get('owner_role') not in ROLE_LOOKUP:raise HTTPException(422,'Assigned owner role is required')
        if len(str(fields.get('response','')))>5000:raise HTTPException(422,'Response exceeds limit')
        fields={k:str(fields.get(k,'')) for k in ('type','status','priority','owner_role','response','due_date','evidence_ref')}
    else:raise HTTPException(422,'Unsupported register')
    return fields

def reg_obj(x,user):
    return {'id':x.id,'kind':x.kind,'initiative_id':x.initiative_id,'value_stream_id':x.value_stream_id,'title':x.title,'fields':json.loads(x.fields),'author_id':x.author_id,'author_role':x.author_role,'version':x.version,'created_at':utcstr(x.created_at),'updated_at':utcstr(x.updated_at),'can_edit':x.author_id==user.id and x.author_role==user.role and user.role in REGISTER_AUTHORS[x.kind]}

def register_markdown(r):
    data=json.loads(r.fields)
    lines=[f'# {r.kind.upper()} — {r.title}', '', '## Record identity',f'- Record: {r.kind.upper()}-{r.id}',f'- Initiative: INIT-{r.initiative_id}' if r.initiative_id else f'- Value stream: VS-{r.value_stream_id}',f'- Author role: {r.author_role}', f'- Version: {r.version}', '', '## Recorded responsibilities or resolution']
    for k,v in data.items():
        if r.kind=='raci' and isinstance(v,list):
            display=', '.join(f"{ROLE_LOOKUP[role]['name']} ({role})" if role in ROLE_LOOKUP else str(role) for role in v) or 'None assigned'
        elif r.kind=='raid' and k=='owner_role':
            display=f"{ROLE_LOOKUP[v]['name']} ({v})" if v in ROLE_LOOKUP else str(v)
        else:display=', '.join(v) if isinstance(v,list) else str(v)
        lines.append(f'- **{k.replace("_"," ").title()}**: {display}')
    lines.extend(['','## Verification','This record is versioned and auditable; review the linked evidence and current status.'])
    return '\n'.join(lines)+'\n'

@app.get('/api/registers')
def list_registers(kind:str='',initiative_id:int=0,value_stream_id:int=0,user:User=Depends(get_user),db:Session=Depends(db_session)):
    if user.role not in REGISTER_READERS:raise HTTPException(403,'Register access is not assigned to this role')
    if kind and kind not in REGISTER_AUTHORS:raise HTTPException(422,'Unknown register kind')
    q=select(RegisterItem).order_by(RegisterItem.updated_at.desc(),RegisterItem.id.desc())
    if kind:q=q.where(RegisterItem.kind==kind)
    if initiative_id:q=q.where(RegisterItem.initiative_id==initiative_id)
    if value_stream_id:q=q.where(RegisterItem.value_stream_id==value_stream_id)
    return [reg_obj(x,user) for x in db.execute(q).scalars().all()]

@app.post('/api/registers')
def create_register(req:NewRegisterItem,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    if req.kind not in REGISTER_AUTHORS:raise HTTPException(422,'Unknown register kind')
    role_required(user,*REGISTER_AUTHORS[req.kind])
    if bool(req.initiative_id)==bool(req.value_stream_id):raise HTTPException(422,'Choose exactly one initiative or value stream')
    if req.initiative_id and not db.get(Initiative,req.initiative_id):raise HTTPException(404,'Initiative not found')
    if req.value_stream_id and not db.get(ValueStream,req.value_stream_id):raise HTTPException(404,'Value stream not found')
    fields=validate_register(req.kind,req.fields)
    x=RegisterItem(kind=req.kind,initiative_id=req.initiative_id,value_stream_id=req.value_stream_id,title=req.title.strip(),fields=json.dumps(fields,sort_keys=True),author_id=user.id,author_role=user.role,version=1)
    db.add(x);db.flush();payload=register_markdown(x)
    db.add(RegisterRevision(item_id=x.id,version=1,payload=payload,digest=sha(payload),author_id=user.id))
    log(db,user,'register.created',f'{req.kind.upper()}-{x.id}',{'kind':req.kind,'version':1,'scope':f'INIT-{req.initiative_id}' if req.initiative_id else f'VS-{req.value_stream_id}','hash':sha(payload)})
    db.commit();return reg_obj(x,user)

@app.put('/api/registers/{rid}')
def update_register(rid:int,req:EditRegisterItem,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    x=db.get(RegisterItem,rid)
    if not x:raise HTTPException(404,'Register record not found')
    if x.author_id!=user.id or x.author_role!=user.role or user.role not in REGISTER_AUTHORS[x.kind]:
        raise HTTPException(403,'Read-only: only the original author may edit this record')
    if x.version!=req.expected_version:raise HTTPException(409,'This register has been modified. Refresh before editing')
    fields=validate_register(x.kind,req.fields)
    if x.title==req.title.strip() and json.loads(x.fields)==fields:return reg_obj(x,user)
    x.title=req.title.strip();x.fields=json.dumps(fields,sort_keys=True);x.version+=1;x.updated_at=now()
    payload=register_markdown(x)
    db.add(RegisterRevision(item_id=x.id,version=x.version,payload=payload,digest=sha(payload),author_id=user.id))
    log(db,user,'register.revised',f'{x.kind.upper()}-{x.id}',{'version':x.version,'hash':sha(payload)})
    db.commit();return reg_obj(x,user)

@app.get('/api/registers/{rid}/revisions')
def register_revisions(rid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    if user.role not in REGISTER_READERS:raise HTTPException(403,'Not authorized')
    x=db.get(RegisterItem,rid)
    if not x:raise HTTPException(404,'Unknown register record')
    rows=db.execute(select(RegisterRevision).where(RegisterRevision.item_id==rid).order_by(RegisterRevision.version)).scalars().all()
    return [{'version':r.version,'sha256':r.digest,'author_id':r.author_id,'created_at':utcstr(r.created_at),'markdown':r.payload} for r in rows]

@app.get('/api/registers/{rid}/download')
def register_download(rid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    if user.role not in REGISTER_READERS:raise HTTPException(403,'Not authorized')
    x=db.get(RegisterItem,rid)
    if not x:raise HTTPException(404,'Not found')
    return Response(content=register_markdown(x),media_type='text/markdown; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="{x.kind.upper()}-{rid}-v{x.version}.md"'})

@app.get('/api/catalog')
def catalog(user:User=Depends(get_user)):
    return {'roles':list(ROLE_LOOKUP.values()),'stages':STAGES,'workspaces':ROLE_WORKSPACES,'streams':([] if user.role=='admin' else [dict(t) if can_view_financials(user) else {k:v for k,v in t.items() if k!='budget'} for t in STREAM_TEMPLATES]),'initiatives':([] if user.role=='admin' else [dict(t) if can_view_financials(user) else {k:v for k,v in t.items() if k not in ('budget','annual_benefit')} for t in INITIATIVE_TEMPLATES]),'insurance_products':['Workers Compensation','Commercial Property','General Liability','Cyber Insurance','Marine Cargo','Commercial Auto','Professional Liability','Construction','Aviation','Risk Engineering']}
@app.get('/api/summary')
def summary(user:User=Depends(get_user),db:Session=Depends(db_session)):
    streams=db.execute(select(ValueStream)).scalars().all();initiatives=db.execute(select(Initiative)).scalars().all();arts=db.execute(select(Artifact)).scalars().all()
    needs_review=[a for a in arts if a.status=='draft' and a.reviewer==user.role and any(x.id==a.initiative_id and x.current_stage==a.stage for x in initiatives)]
    result={'streams':len(streams),'initiatives':len(initiatives),'active':sum(i.current_stage!='closed' for i in initiatives),'approved_artifacts':sum(a.status=='approved' and can_read_artifact(a,user) for a in arts),'role_approved':sum(a.status=='approved' and a.reviewer==user.role for a in arts),'pending_review':len(needs_review),'by_stage':[{'stage':s,'count':sum(i.current_stage==s for i in initiatives)} for s in STAGE_IDS]}
    if can_view_financials(user):
        result['total_budget']=sum(i.budget for i in initiatives)
        result['expected_annual_benefit']=sum(i.annual_benefit for i in initiatives)
    return result
@app.get('/api/streams')
def streams(user:User=Depends(get_user),db:Session=Depends(db_session)):
    require_business_data_access(user)
    vals=db.execute(select(ValueStream).order_by(ValueStream.name)).scalars().all()
    return [dict(visible_stream(v,user),edit_meta=edit_meta(db,'stream',v.id,user),initiative_count=db.scalar(select(func.count(Initiative.id)).where(Initiative.value_stream_id==v.id)) or 0) for v in vals]
class NewStream(BaseModel):
    template:str='';name:str=Field(min_length=5,max_length=200);lob:str=Field(default='',max_length=300);owner:str=Field(default='',max_length=200);description:str=Field(default='',max_length=2500);theme:str=Field(default='',max_length=1000);metric:str=Field(default='Median end-to-end days',max_length=200);baseline:float=Field(default=10,ge=0);target:float=Field(default=5,ge=0);budget:float=Field(default=100000,ge=0,le=1e10)
@app.post('/api/streams')
def create_stream(req:NewStream,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,*CREATE_STREAM)
    key=re.sub('[^a-z0-9]+','-',req.name.lower()).strip('-')[:85]+'-'+secrets.token_hex(3)
    v=ValueStream(key=key,**req.model_dump(exclude={'template'}));db.add(v);db.flush();init_managed_record(db,'stream',v.id,user,stream_obj(v));log(db,user,'stream.created',f'VS-{v.id}',{'name':v.name,'from_template':req.template});db.commit();return stream_obj(v)
@app.get('/api/initiatives')
def initiatives(stream_id:int=0,user:User=Depends(get_user),db:Session=Depends(db_session)):
    require_business_data_access(user)
    q=select(Initiative).order_by(Initiative.id.desc())
    if stream_id:q=q.where(Initiative.value_stream_id==stream_id)
    vals=db.execute(q).scalars().all();vmap={v.id:v for v in db.execute(select(ValueStream)).scalars()}
    return [dict(visible_initiative(i,vmap.get(i.value_stream_id),user),edit_meta=edit_meta(db,'initiative',i.id,user)) for i in vals]
class NewInitiative(BaseModel):
    stream_id:int;template:str='';title:str=Field(min_length=7,max_length=220);lob:str=Field(default='Commercial & Specialty Insurance',max_length=160);budget:float=Field(default=150000,ge=0);annual_benefit:float=Field(default=225000,ge=0);baseline:float=Field(default=12,ge=0);target:float=Field(default=7,ge=0);unit:str=Field(default='days',max_length=30);volume:str=Field(default='Illustrative operating volume',max_length=180);workflow:str=Field(default='Intake → validate → review → fulfill → measure',max_length=3000);rules:str=Field(default='Human authority required for material insurance decisions.',max_length=3000);risk:str=Field(default='Access and data quality controls are required.',max_length=2000);dependencies:str=Field(default='Policy, claims or billing administration',max_length=1000)
@app.post('/api/initiatives')
def create_init(req:NewInitiative,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,*CREATE_INITIATIVE)
    v=db.get(ValueStream,req.stream_id)
    if not v:raise HTTPException(404,'Unknown value stream')
    key=re.sub('[^a-z0-9]+','-',req.title.lower()).strip('-')[:82]+'-'+secrets.token_hex(3)
    i=Initiative(key=key,value_stream_id=v.id,**req.model_dump(exclude={'stream_id','template'}));db.add(i);db.flush()
    if req.template:
        base=next((x for x in INITIATIVE_TEMPLATES if x['key']==req.template),None)
        if not base:raise HTTPException(422,'Unknown scenario example')
        # Reuse example context only within the matching value stream.
        if next((x['key'] for x in STREAM_TEMPLATES if x['key']==v.key or x['name']==v.name),None) not in (None,base['stream']):
            raise HTTPException(422,'Choose an example for the selected value stream')
        db.add(ScenarioLink(initiative_id=i.id,template_key=req.template))
        create_reference_snapshot(db,i,req.template,user)
    init_managed_record(db,'initiative',i.id,user,init_obj(i,v));log(db,user,'initiative.created',f'INIT-{i.id}',{'title':i.title,'value_stream':v.name,'example_source':req.template or None});db.commit();return init_obj(i,v)
@app.get('/api/initiatives/{iid}')
def initiative_detail(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    require_business_data_access(user)
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    v=db.get(ValueStream,i.value_stream_id)
    arts=db.execute(select(Artifact).where(Artifact.initiative_id==iid).order_by(Artifact.id)).scalars().all()
    return {'initiative':dict(visible_initiative(i,v,user),edit_meta=edit_meta(db,'initiative',i.id,user)),'value_stream':dict(visible_stream(v,user),edit_meta=edit_meta(db,'stream',v.id,user)),'artifacts':[artifact_obj(a) for a in arts if can_read_artifact(a,user)], 'stages':STAGES,'needed':[{'kind':a[0],'title':a[1],'author_role':a[2],'reviewer_role':a[3]} for a in needed(i)]}
@app.post('/api/initiatives/{iid}/generate')
def generate_contracts(iid:int,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Unknown initiative')
    if i.current_stage=='closed':raise HTTPException(409,'This initiative has been closed')
    stage=STAGES[STAGE_IDS.index(i.current_stage)]
    allowed={stage['owner'],*STAGE_GENERATORS}
    role_required(user,*allowed)
    if i.current_stage in ('portfolio','benefits') and not can_view_financials(user):
        raise HTTPException(403,'Financial-stage contract generation requires portfolio access')
    if not all(kind in ROLE_DOCS.get(user.role,()) for kind,_,_,_ in stage['artifacts']):
        raise HTTPException(403,'Required stage contracts are outside your role access')
    v=db.get(ValueStream,i.value_stream_id)
    made=[]
    for kind,title,writer,reviewer in stage['artifacts']:
        if db.execute(select(Artifact).where(Artifact.initiative_id==i.id,Artifact.kind==kind)).scalar_one_or_none():continue
        linked=db.execute(select(ScenarioLink).where(ScenarioLink.initiative_id==i.id)).scalar_one_or_none()
        copies=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id)).scalars().all()
        overrides={}
        for rec in copies:overrides.setdefault(rec.table_name,[]).append(json.loads(rec.payload))
        context=doc_appendix(kind,linked.template_key,overrides if overrides else None) if linked else ''
        content=contract_text(kind,init_obj(i),stream_obj(v)) + context
        a=Artifact(initiative_id=i.id,kind=kind,stage=i.current_stage,markdown=content,hash=sha(content),author=user.name,reviewer=reviewer,status='draft')
        db.add(a);db.flush();db.add(ArtifactRevision(artifact_id=a.id,version=1,markdown=content,hash=a.hash,author=user.name));made.append(kind);log(db,user,'contract.generated',f'ART-{a.id}',{'type':kind,'initiative':i.key,'sha256':a.hash})
    db.commit();return {'generated':made,'message':'Contracts created. Approval is never automatic.'}
class ArtifactEdit(BaseModel):
    markdown:str=Field(min_length=80,max_length=80000);expected_version:int=Field(ge=1)
@app.put('/api/artifacts/{aid}')
def update_artifact(aid:int,req:ArtifactEdit,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    a=db.get(Artifact,aid)
    if not a:raise HTTPException(404,'Artifact not found')
    assert_can_read_artifact(a,user)
    i=db.get(Initiative,a.initiative_id)
    if i.current_stage!=a.stage:raise HTTPException(409,'This stage is not active; historical contracts are read only')
    writer=next(x[2] for x in STAGES[STAGE_IDS.index(a.stage)]['artifacts'] if x[0]==a.kind)
    role_required(user,writer)
    if req.expected_version!=a.version:raise HTTPException(409,'Artifact changed since you opened it. Refresh to prevent overwriting work.')
    if a.markdown==req.markdown:return artifact_obj(a)
    a.markdown=req.markdown;a.version+=1;a.hash=sha(req.markdown);a.author=user.name;a.status='draft';a.approved_at=None;a.approved_by=None;a.updated_at=now()
    db.add(ArtifactRevision(artifact_id=a.id,version=a.version,markdown=req.markdown,hash=a.hash,author=user.name))
    log(db,user,'contract.revised',f'ART-{a.id}',{'version':a.version,'sha256':a.hash,'previous_approvals_invalidated':True});db.commit();return artifact_obj(a)
class ReviewReq(BaseModel):
    decision:str;comment:str=Field(default='',max_length=3000);expected_version:int=Field(ge=1)
@app.post('/api/artifacts/{aid}/review')
def review_artifact(aid:int,req:ReviewReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    a=db.get(Artifact,aid)
    if not a:raise HTTPException(404,'Artifact not found')
    assert_can_read_artifact(a,user)
    i=db.get(Initiative,a.initiative_id)
    if i.current_stage!=a.stage:raise HTTPException(409,'Only current-stage contracts are reviewable')
    if req.decision not in ('approved','rejected'):raise HTTPException(422,'Decision must be approved or rejected')
    if req.expected_version!=a.version:raise HTTPException(409,'Artifact version has changed; review current evidence')
    role_required(user,a.reviewer)
    if a.status=='approved':raise HTTPException(409,'Already approved. Revise the contract before re-review.')
    if not a.markdown.strip().startswith('# ') or '## ' not in a.markdown:raise HTTPException(422,'Contract must contain a title and structured sections before review')
    a.status=req.decision;a.approved_by=user.name if req.decision=='approved' else None;a.approved_at=now() if req.decision=='approved' else None
    db.add(Approval(artifact_id=a.id,version=a.version,reviewer_id=user.id,decision=req.decision,comment=req.comment,content_hash=a.hash))
    log(db,user,'contract.'+req.decision,f'ART-{a.id}',{'version':a.version,'sha256':a.hash,'comment':req.comment[:500]})
    advanced=advance_if_ready(db,i,user) if req.decision=='approved' else False
    db.commit();return {'artifact':artifact_obj(a),'advanced':advanced,'next_stage':i.current_stage}
def current_input_digest(db,i,stage):
    items=db.execute(select(Artifact).where(Artifact.initiative_id==i.id,Artifact.stage==stage).order_by(Artifact.kind)).scalars().all()
    return sha(json.dumps([(a.kind,a.version,a.hash) for a in items],sort_keys=True))

def latest_control(db,initiative_id,stage,code):
    return db.execute(select(ControlReview).where(ControlReview.initiative_id==initiative_id,ControlReview.stage==stage,ControlReview.control_code==code).order_by(ControlReview.id.desc()).limit(1)).scalar_one_or_none()

def review_state(db,i,v,stage):
    current_digest=current_input_digest(db,i,stage)
    output=[]
    for ctrl in controls_for(stage,i,v):
        last=latest_control(db,i.id,stage,ctrl['control_code'])
        decision=last.decision if last and last.input_digest==current_digest else 'pending'
        output.append({**ctrl,'decision':decision,'comment':last.comment if last else '', 'evidence_ref':last.evidence_ref if last else '', 'reviewed_by':last.actor_name if last else '', 'reviewed_at':utcstr(last.created_at) if last else None,'evidence_current':bool(last and last.input_digest==current_digest),'input_digest':current_digest})
    return output

def advance_if_ready(db,i,user):
    if i.current_stage=='closed':return False
    all_a=db.execute(select(Artifact).where(Artifact.initiative_id==i.id,Artifact.stage==i.current_stage)).scalars().all()
    required=[a[0] for a in needed(i)]
    if not all(any(a.kind==kind and a.status=='approved' for a in all_a) for kind in required):return False
    v=db.get(ValueStream,i.value_stream_id)
    if not all(r['decision']=='approved' for r in review_state(db,i,v,i.current_stage) if r['mandatory']):return False
    old=i.current_stage;i.current_stage=STAGE_IDS[STAGE_IDS.index(old)+1]
    if i.current_stage=='closed':i.status='closed'
    log(db,user,'initiative.stage_advanced',f'INIT-{i.id}',{'from':old,'to':i.current_stage,'approved_contracts':required,'required_controls':[r['control_code'] for r in review_state(db,i,v,old) if r['mandatory']]})
    return True

class ControlDecisionReq(BaseModel):
    decision:str
    comment:str=Field(default='',max_length=2000)
    evidence_ref:str=Field(default='',max_length=350)
    expected_stage:str
    input_digest:str=Field(min_length=64,max_length=64)

@app.get('/api/initiatives/{iid}/control-reviews')
def initiative_control_reviews(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    v=db.get(ValueStream,i.value_stream_id)
    if i.current_stage=='closed':return {'initiative_id':iid,'stage':'closed','controls':[],'outstanding':0}
    controls=review_state(db,i,v,i.current_stage)
    if user.role=='admin':controls=[c for c in controls if c['role']=='admin']
    else:controls=[c for c in controls if c['role']==user.role or user.role in APPROVAL_OVERSIGHT and (can_view_financials(user) or i.current_stage not in ('portfolio','benefits') or c['role'] not in ('finance','lpm','executive','analytics'))]
    for c in controls:c['assigned_to_me']=c['role']==user.role
    return {'initiative_id':iid,'stage':i.current_stage,'controls':controls,'outstanding':sum(c['mandatory'] and c['decision']!='approved' for c in controls),'portfolio_data_hidden':not can_view_financials(user)}

@app.get('/api/control-reviews')
def control_review_inbox(user:User=Depends(get_user),db:Session=Depends(db_session)):
    result=[]
    for i in db.execute(select(Initiative).where(Initiative.current_stage!='closed').order_by(Initiative.id.desc())).scalars().all():
        v=db.get(ValueStream,i.value_stream_id)
        for c in review_state(db,i,v,i.current_stage):
            if c['role']!=user.role:continue
            display='Technical integration provisioning for INIT-'+str(i.id) if user.role=='admin' else i.title
            result.append({'initiative_id':i.id,'initiative_title':display,'value_stream':None if user.role=='admin' else v.name,'stage':i.current_stage,'control':c})
    return result

@app.post('/api/initiatives/{iid}/control-reviews/{code}')
def submit_control_review(iid:int,code:str,req:ControlDecisionReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    if i.current_stage=='closed' or i.current_stage!=req.expected_stage:raise HTTPException(409,'The workflow stage has changed. Refresh and review current work.')
    v=db.get(ValueStream,i.value_stream_id)
    ctrl=next((c for c in controls_for(i.current_stage,i,v) if c['control_code']==code),None)
    if not ctrl:raise HTTPException(404,'Role control is not applicable to this stage or initiative')
    role_required(user,ctrl['role'])
    if req.decision not in ('approved','changes_requested'):raise HTTPException(422,'Decision must be approved or changes_requested')
    digest=current_input_digest(db,i,i.current_stage)
    if req.input_digest!=digest:raise HTTPException(409,'The evidence has changed. Refresh before deciding.')
    available=db.execute(select(Artifact).where(Artifact.initiative_id==iid,Artifact.stage==i.current_stage)).scalars().all()
    if req.decision=='approved' and not all(any(a.kind==kind for a in available) for kind,*_ in needed(i)):
        raise HTTPException(409,'Generate the required stage contracts before confirming readiness.')
    if req.decision=='changes_requested' and len(req.comment.strip())<8:raise HTTPException(422,'Explain what needs correction')
    db.add(ControlReview(initiative_id=i.id,stage=i.current_stage,control_code=code,role=user.role,actor_id=user.id,actor_name=user.name,decision=req.decision,comment=req.comment,evidence_ref=req.evidence_ref,input_digest=digest))
    log(db,user,'control.'+req.decision,f'INIT-{i.id}',{'role':user.role,'control':code,'stage':i.current_stage,'digest':digest,'evidence_ref':req.evidence_ref})
    db.flush();advanced=advance_if_ready(db,i,user);db.commit()
    return {'decision':req.decision,'initiative_id':iid,'stage':req.expected_stage,'advanced':advanced,'next_stage':i.current_stage}

def create_reference_snapshot(db,i,source,user):
    for name in scenario_schemas():
        if name.startswith('_') or name in ('value_streams','initiatives','role_approval_controls'):continue
        rows=[x for x in scenario_table(name) if x.get('initiative_key')==source]
        for row in rows:
            data={k:(v.replace(source,i.key) if isinstance(v,str) else v) for k,v in row.items()}
            # Distinguish the new initiative's data from the source example's identifiers.
            data['initiative_key']=i.key
            if name=='metrics':
                data['baseline_value']=str(i.baseline);data['target_value']=str(i.target);data['metric_unit']=i.unit
            if name=='cost_estimates':
                from .catalog import INIT_MAP as _INIT_MAP
                original=_INIT_MAP[source]['budget'];share=float(data['planned_cost_usd'])/original if original else 0
                data['planned_cost_usd']=str(round(share*i.budget))
            primary=scenario_schemas()[name]['key']
            content=json.dumps(data,sort_keys=True,ensure_ascii=False)
            record=ScenarioRecord(initiative_id=i.id,table_name=name,source_record_id=data[primary],payload=content,author_id=user.id,version=1)
            db.add(record);db.flush()
            db.add(ScenarioRecordRevision(record_id=record.id,version=1,payload=content,digest=sha(content),author_id=user.id))
    costs=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id,ScenarioRecord.table_name=='cost_estimates').order_by(ScenarioRecord.id)).scalars().all()
    if costs:
        adjustment=int(i.budget)-sum(int(json.loads(r.payload)['planned_cost_usd']) for r in costs)
        if adjustment:
            last=costs[-1];data=json.loads(last.payload);data['planned_cost_usd']=str(int(data['planned_cost_usd'])+adjustment)
            last.payload=json.dumps(data,sort_keys=True,ensure_ascii=False)
            rev=db.execute(select(ScenarioRecordRevision).where(ScenarioRecordRevision.record_id==last.id,ScenarioRecordRevision.version==1)).scalar_one_or_none()
            if rev:rev.payload=last.payload;rev.digest=sha(last.payload)

def sync_reference_summary(db,i,user,oldinit):
    records=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id)).scalars().all()
    for rec in records:
        row=json.loads(rec.payload);new=dict(row)
        if rec.table_name=='metrics':
            new['baseline_value']=str(i.baseline);new['target_value']=str(i.target);new['metric_unit']=i.unit
        if rec.table_name=='cost_estimates' and i.budget!=oldinit['budget']:
            old_budget=oldinit['budget'] or 0
            new['planned_cost_usd']=str(int(round(int(row['planned_cost_usd'])*i.budget/old_budget))) if old_budget else row['planned_cost_usd']
        if new!=row:
            content=json.dumps(new,sort_keys=True,ensure_ascii=False);rec.payload=content;rec.version+=1;rec.updated_at=now()
            db.add(ScenarioRecordRevision(record_id=rec.id,version=rec.version,payload=content,digest=sha(content),author_id=user.id))
            log(db,user,'reference.synced_from_initiative',f'REF-{rec.id}',{'version':rec.version})
    costs=[r for r in records if r.table_name=='cost_estimates']
    if costs and i.budget!=oldinit['budget']:
        last=costs[-1];data=json.loads(last.payload);diff=int(i.budget)-sum(int(json.loads(r.payload)['planned_cost_usd']) for r in costs)
        if diff:
            data['planned_cost_usd']=str(int(data['planned_cost_usd'])+diff);last.payload=json.dumps(data,sort_keys=True,ensure_ascii=False);last.version+=1;last.updated_at=now()
            db.add(ScenarioRecordRevision(record_id=last.id,version=last.version,payload=last.payload,digest=sha(last.payload),author_id=user.id))
            log(db,user,'reference.budget_reconciled',f'REF-{last.id}',{'adjustment_usd':diff})

class ScenarioEditRequest(BaseModel):
    expected_version:int=Field(ge=1)
    fields:dict[str,str]

@app.put('/api/scenario-records/{rid}')
def edit_reference_record(rid:int,req:ScenarioEditRequest,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    rec=db.get(ScenarioRecord,rid)
    if not rec:raise HTTPException(404,'Reference record not found')
    i=db.get(Initiative,rec.initiative_id)
    if rec.author_id!=user.id:raise HTTPException(403,'Only the original author can edit this reference record')
    if i.current_stage!='portfolio':raise HTTPException(409,'Approved initiative reference data is locked; use contract revision or formal change control')
    if req.expected_version!=rec.version:raise HTTPException(409,'This row has changed. Reload to avoid overwriting it')
    schema=scenario_schemas()[rec.table_name]
    old=json.loads(rec.payload)
    if set(req.fields)!=set(schema['fields']):raise HTTPException(422,'Values must follow the complete published CSV schema')
    pk=schema['key']
    if req.fields[pk]!=old[pk] or req.fields.get('initiative_key')!=i.key:
        raise HTTPException(422,'Primary and initiative identifiers are stable and cannot be changed')
    for field,typ in schema['fields'].items():
        val=req.fields[field]
        if not isinstance(val,str):raise HTTPException(422,'Fields must be plain text')
        if len(val)>1500:raise HTTPException(422,'Value exceeds the schema length limit')
        if field!='test_evidence_ref' and not val.strip():raise HTTPException(422,f'{field} cannot be blank')
        if typ=='role' and val not in ROLE_LOOKUP:raise HTTPException(422,f'{field} must be a known stakeholder role')
        if typ.startswith('enum:') and val not in typ.split(':',1)[1].split('|'):raise HTTPException(422,f'{field} must use a permitted value')
        if typ=='boolean' and val not in ('true','false'):raise HTTPException(422,f'{field} must be true or false')
        if typ in ('integer','decimal'):
            try:n=float(val)
            except ValueError:raise HTTPException(422,f'{field} must be numeric')
            if n<0 or typ=='integer' and not n.is_integer():raise HTTPException(422,f'{field} must be nonnegative and correctly typed')
        if typ.startswith('ref:') and field not in ('initiative_key',):
            # The reference must resolve within the same initiative snapshot.
            target=typ[4:]
            valid=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id,ScenarioRecord.table_name==target)).scalars().all()
            valid_ids={json.loads(x.payload).get(scenario_schemas()[target]['key']) for x in valid}
            if val not in valid_ids:raise HTTPException(422,f'{field} must reference an existing row in {target}')
        if rec.table_name=='test_cases' and field=='execution_status' and val!='not_run':
            raise HTTPException(422,'Do not mark a sample test as executed. Use real test evidence in the QA contract.')
        if rec.table_name=='metrics' and field=='actual_status' and val!='unmeasured':
            raise HTTPException(422,'Do not claim a measured benefit without authoritative operational evidence.')
    payload=json.dumps(req.fields,sort_keys=True,ensure_ascii=False)
    if payload==rec.payload:return {'id':rec.id,'version':rec.version,'saved':False}
    oldinit=init_obj(i)
    if rec.table_name=='metrics':
        i.baseline=float(req.fields['baseline_value']);i.target=float(req.fields['target_value']);i.unit=req.fields['metric_unit']
        if req.fields['direction']=='decrease' and i.target>=i.baseline:
            raise HTTPException(422,'The target must improve on the baseline for a decrease metric')
    rec.payload=payload;rec.version+=1;rec.updated_at=now()
    db.add(ScenarioRecordRevision(record_id=rec.id,version=rec.version,payload=payload,digest=sha(payload),author_id=user.id))
    if rec.table_name=='cost_estimates':
        costs=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id,ScenarioRecord.table_name=='cost_estimates')).scalars().all()
        i.budget=float(sum(int(json.loads(r.payload)['planned_cost_usd']) for r in costs))
    if rec.table_name in ('metrics','cost_estimates') and oldinit!=init_obj(i):
        m=db.execute(select(ManagedRecord).where(ManagedRecord.resource_type=='initiative',ManagedRecord.resource_id==i.id)).scalar_one_or_none()
        if m:revise_managed(db,user,m,oldinit,init_obj(i))
    log(db,user,'reference.revised',f'REF-{rec.id}',{'initiative':i.id,'table':rec.table_name,'version':rec.version,'digest':sha(payload)})
    db.commit();return {'id':rec.id,'version':rec.version,'saved':True}

@app.get('/api/initiatives/{iid}/reference-export')
def export_reference_csv(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    require_business_data_access(user)
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    link=db.execute(select(ScenarioLink).where(ScenarioLink.initiative_id==iid)).scalar_one_or_none()
    template=link.template_key if link else (i.key if i.key in INIT_MAP else None)
    if not template:raise HTTPException(404,'No example pack attached')
    data=reference_rows(db,i,template,can_view_financials(user),user)
    bio=io.BytesIO()
    import csv
    with zipfile.ZipFile(bio,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('README.md','# Initiative reference rows\n\nModelled examples and author-edited planning data; not verified production activity.\n')
        for name,arr in data.items():
            if not arr:continue
            out=io.StringIO();writer=csv.DictWriter(out,fieldnames=list(scenario_schemas()[name]['fields']))
            writer.writeheader();writer.writerows([{k:r[k] for k in writer.fieldnames} for r in arr])
            z.writestr(name+'.csv',out.getvalue())
        safe={k:v for k,v in scenario_schemas().items() if k in data}
        z.writestr('schema.json',json.dumps(safe,indent=2))
    return Response(content=bio.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="{i.key}-reference.zip"'})

def reference_rows(db,i,template,financial_access,user):
    copies=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id).order_by(ScenarioRecord.id)).scalars().all()
    if copies:
        out={}
        for r in copies:
            if r.table_name=='cost_estimates' and not financial_access:continue
            val=json.loads(r.payload)
            val['__record_id']=r.id;val['__version']=r.version
            val['__can_edit']=bool(r.author_id==user.id and i.current_stage=='portfolio')
            out.setdefault(r.table_name,[]).append(val)
        return out
    return scenario_preview(template,financial_access)['tables']

@app.get('/api/reference-catalog')
def reference_catalog(user:User=Depends(get_user)):
    require_business_data_access(user)
    return {'tables':[{'table':t,'columns':list(scenario_schemas()[t]['fields']),'description':scenario_table(t)[0].get('initiative_key','') if scenario_table(t) else ''} for t in scenario_schemas() if not t.startswith('_') and (can_view_financials(user) or t!='cost_estimates')], 'examples':[{'key':x['key'],'title':x['title'],'stream':x['stream']} for x in INITIATIVE_TEMPLATES]}

@app.get('/api/initiatives/{iid}/reference')
def initiative_reference(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    require_business_data_access(user)
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    link=db.execute(select(ScenarioLink).where(ScenarioLink.initiative_id==iid)).scalar_one_or_none()
    if not link and i.key in INIT_MAP:link=ScenarioLink(initiative_id=iid,template_key=i.key)
    if not link:return {'template_key':None,'tables':{},'counts':{},'example_available':True,'message':'Choose a matching sample scenario when creating a new initiative. Its records become readable reference context for all downstream contracts.'}
    data=scenario_preview(link.template_key,can_view_financials(user))
    data['tables']=reference_rows(db,i,link.template_key,can_view_financials(user),user)
    data['counts']={k:len(v) for k,v in data['tables'].items()}
    data['example_available']=True;data['message']='Illustrative source examples. User-owned row edits are versioned and audited; tests and benefits remain unmeasured until real evidence exists.'
    return data

@app.get('/api/approvals')
def approvals(user:User=Depends(get_user),db:Session=Depends(db_session)):
    rows=db.execute(select(Artifact,Initiative).join(Initiative,Artifact.initiative_id==Initiative.id).where(Artifact.stage==Initiative.current_stage,Artifact.status.in_(['draft','rejected'])).order_by(Artifact.updated_at.desc())).all()
    return [{'artifact':artifact_obj(a),'initiative':visible_initiative(i,None,user),'assigned_to_me':a.reviewer==user.role} for a,i in rows if can_read_artifact(a,user) and (a.reviewer==user.role or user.role in APPROVAL_OVERSIGHT)]
@app.get('/api/artifacts')
def artifacts(user:User=Depends(get_user),db:Session=Depends(db_session)):
    rows=db.execute(select(Artifact,Initiative).join(Initiative,Artifact.initiative_id==Initiative.id).order_by(Artifact.updated_at.desc())).all()
    return [{'artifact':artifact_obj(a),'initiative':{'id':i.id,'title':i.title,'key':i.key}} for a,i in rows if can_read_artifact(a,user)]
@app.get('/api/artifacts/{aid}/download')
def download_artifact(aid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    a=db.get(Artifact,aid)
    if not a:raise HTTPException(404,'Not found')
    assert_can_read_artifact(a,user)
    meta=f"---\nschema: {a.kind}/v1\nartifact_id: ART-{a.id}\ninitiative_id: INIT-{a.initiative_id}\nstage: {a.stage}\nversion: {a.version}\nstatus: {a.status}\nsha256: {a.hash}\nreviewer_role: {a.reviewer}\napproved_by: {json.dumps(a.approved_by)}\n---\n\n"
    return Response(content=meta+a.markdown,media_type='text/markdown; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="ART-{a.id}-{a.kind}-v{a.version}.md"'})
@app.get('/api/initiatives/{iid}/export')
def export_initiative(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    require_business_data_access(user)
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Not found')
    arts=[a for a in db.execute(select(Artifact).where(Artifact.initiative_id==iid)).scalars().all() if can_read_artifact(a,user)]
    bio=io.BytesIO()
    with zipfile.ZipFile(bio,'w',zipfile.ZIP_DEFLATED) as z:
        manifest={'initiative':visible_initiative(i,None,user),'exported_at':now().isoformat(),'artifacts':[{'id':a.id,'kind':a.kind,'version':a.version,'status':a.status,'sha256':a.hash} for a in arts]}
        z.writestr('manifest.json',json.dumps(manifest,indent=2))
        for r in db.execute(select(RegisterItem).where((RegisterItem.initiative_id==iid) | (RegisterItem.value_stream_id==i.value_stream_id))).scalars().all():
            if user.role in REGISTER_READERS:
                z.writestr(f'management/{r.kind}-{r.id}-v{r.version}.md',register_markdown(r))
                for old in db.execute(select(RegisterRevision).where(RegisterRevision.item_id==r.id).order_by(RegisterRevision.version)).scalars().all():
                    z.writestr(f'history/{r.kind.upper()}-{r.id}/v{old.version}.md',old.payload)
        if user.role!='admin':
            for st in STAGES:
                for ctrl in review_state(db,i,db.get(ValueStream,i.value_stream_id),st['id']):
                    if ctrl['role'] in ('finance','lpm','executive','analytics') and not can_view_financials(user):continue
                    if ctrl['reviewed_by']:
                        z.writestr(f'governance/{st["id"]}/{ctrl["control_code"]}.md',
                            '# Role control review\n\n- **Stage**: '+st['title']+'\n- **Control**: '+ctrl['decision_title']+'\n- **Role**: '+ctrl['role']+'\n- **Decision**: '+ctrl['decision']+'\n- **Reviewer**: '+ctrl['reviewed_by']+'\n- **Evidence**: '+ctrl['evidence_ref']+'\n- **Note**: '+ctrl['comment']+'\n- **Source digest**: '+ctrl['input_digest']+'\n')
        for a in arts:
            fm=f'---\nschema: {a.kind}/v1\nartifact_id: ART-{a.id}\ninitiative_id: INIT-{i.id}\nversion: {a.version}\nstatus: {a.status}\nsha256: {a.hash}\n---\n\n'
            z.writestr(f'{a.stage}/{a.kind}.md',fm+a.markdown)
            revisions=db.execute(select(ArtifactRevision).where(ArtifactRevision.artifact_id==a.id).order_by(ArtifactRevision.version)).scalars().all()
            for rev in revisions:
                z.writestr(f'history/ART-{a.id}/v{rev.version}.md',f'---\nartifact_id: ART-{a.id}\nversion: {rev.version}\nsha256: {rev.hash}\n---\n\n'+rev.markdown)
    return Response(content=bio.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="{i.key}-evidence.zip"'})
@app.get('/api/artifacts/{aid}/revisions')
def artifact_revisions(aid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    a=db.get(Artifact,aid)
    if not a:raise HTTPException(404,'Not found')
    assert_can_read_artifact(a,user)
    revisions=db.execute(select(ArtifactRevision).where(ArtifactRevision.artifact_id==aid).order_by(ArtifactRevision.version)).scalars().all()
    return [{'version':r.version,'hash':r.hash,'author':r.author,'markdown':r.markdown,'created_at':utcstr(r.created_at)} for r in revisions]
@app.get('/api/audit/verify')
def verify_audit(user:User=Depends(get_user),db:Session=Depends(db_session)):
    events=db.execute(select(AuditEvent).order_by(AuditEvent.id)).scalars().all()
    prev='GENESIS'
    for e in events:
        obj={'actor':e.actor,'action':e.action,'target':e.target,'details':json.loads(e.details or '{}'),'previous':prev,'time':e.created_at.isoformat()}
        digest=sha(json.dumps(obj,sort_keys=True,default=str))
        if e.prev_hash!=prev or digest!=e.hash:
            return {'valid':False,'failed_id':e.id,'events_checked':e.id-1}
        prev=e.hash
    return {'valid':True,'events_checked':len(events),'chain_head':prev}
@app.get('/api/live')
async def live_events(request:Request,user:User=Depends(get_user)):
    async def events():
        with SessionLocal() as session:
            seen=session.scalar(select(func.max(AuditEvent.id))) or 0
        yield f'data: {json.dumps({"type":"ready","last_event_id":seen})}\n\n'
        while not await request.is_disconnected():
            with SessionLocal() as session:
                newest=session.scalar(select(func.max(AuditEvent.id))) or 0
            if newest>seen:
                seen=newest
                yield f'data: {json.dumps({"type":"update","last_event_id":seen})}\n\n'
            else:yield ': keepalive\n\n'
            await asyncio.sleep(2)
    return StreamingResponse(events(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})

@app.get('/api/audit')
def audit(limit:int=100,user:User=Depends(get_user),db:Session=Depends(db_session)):
    role_required(user,*AUDIT_VIEW)
    results=db.execute(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(min(max(limit,1),500))).scalars().all()
    def allowed(e):
        if user.role in AUDIT_FULL:return True
        if user.role=='admin':return e.action.startswith(('user.','integration.'))
        if e.target.startswith('ART-'):
            try:
                artifact=db.get(Artifact,int(e.target[4:]))
                return artifact is not None and can_read_artifact(artifact,user)
            except ValueError:return False
        return e.action.startswith(('initiative.stage_advanced','initiative.seeded'))
    return [{'id':e.id,'actor':e.actor,'action':e.action,'target':e.target,'details':json.loads(e.details or '{}') if can_view_financials(user) else {},'hash':e.hash,'prev_hash':e.prev_hash,'created_at':utcstr(e.created_at)} for e in results if allowed(e)]
@app.get('/api/insights')
def insights(user:User=Depends(get_user),db:Session=Depends(db_session)):
    if not can_view_financials(user):raise HTTPException(403,'Portfolio investment analytics require financial access')
    streams=db.execute(select(ValueStream)).scalars().all();inits=db.execute(select(Initiative)).scalars().all()
    return {'streams':[{'name':v.name,'id':v.id,'metric':v.metric,'baseline':v.baseline,'target':v.target,'budget':v.budget,'initiative_count':sum(i.value_stream_id==v.id for i in inits),'initiative_budget':sum(i.budget for i in inits if i.value_stream_id==v.id),'illustrative':True} for v in streams], 'by_lob':[{'lob':lob,'count':sum(i.lob==lob for i in inits)} for lob in sorted({i.lob for i in inits})]}

# Org integration connections: secret config stored encrypted only with ENCRYPTION_KEY.
PROVIDERS=['github','jira','confluence','sharepoint','openai']
# Read-only, role-aware help. It never calls the workflow mutation endpoints.
from .help_catalog import help_payload, page_catalog, get_field
from .help_service import answer as help_answer, permitted_page

@app.get('/api/help/catalog')
def help_catalog_endpoint(user:User=Depends(get_user),db:Session=Depends(db_session)):
    payload=help_payload(user.role)
    openai_connector=db.execute(select(Connector).where(Connector.provider=='openai')).scalar_one_or_none()
    payload['ai_available']=bool(openai_connector and openai_connector.mode=='live' and openai_connector.config_encrypted and FERNET)
    return payload

class ContextHelpRequest(BaseModel):
    question:str=Field(min_length=1,max_length=600)
    page:str=Field(default='dashboard',max_length=40)
    field_key:str=Field(default='',max_length=100)
    initiative_id:Optional[int]=None
    stream_id:Optional[int]=None
    use_ai:bool=False

@app.post('/api/help/chat')
def help_chat(req:ContextHelpRequest,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    from .help_service import permitted_page
    pages=page_catalog()
    page=req.page if req.page in pages or req.page in ('initiative','contract') else 'dashboard'
    finance=can_view_financials(user)
    perms={'can_view_financials':finance,'view_connectors':user.role in VIEW_CONNECTORS,'view_audit':user.role in AUDIT_VIEW}
    denied_page=not permitted_page(user.role,page,perms)
    if denied_page:
        log(db,user,'help.access_denied','HELP-'+page,{'role':user.role})
        db.commit()
        return {'answer':'Your role is not authorized to access this workspace or its business records. Open your assigned work instead.', 'mode':'guided','page':'dashboard','role':user.role,'action_page':'dashboard','followups':['What should I do next?'], 'initiative_stage':None,'read_only':True,'note':'No business data was retrieved.'}
    initiative=None
    artifacts=[]
    controls=[]
    if req.initiative_id and user.role!='admin':
        initiative=db.get(Initiative,req.initiative_id)
        if not initiative:raise HTTPException(404,'Initiative not found')
        if initiative.current_stage!='closed':
            v=db.get(ValueStream,initiative.value_stream_id)
            controls=[c for c in review_state(db,initiative,v,initiative.current_stage)
                      if c['role']==user.role or user.role in APPROVAL_OVERSIGHT and (finance or initiative.current_stage not in ('portfolio','benefits') or c['role'] not in ('finance','lpm','executive','analytics'))]
        artifacts=[a for a in db.execute(select(Artifact).where(Artifact.initiative_id==initiative.id,Artifact.stage==initiative.current_stage)).scalars().all() if a.kind in ROLE_DOCS.get(user.role,())]
    queue=[]
    if user.role!='admin' and initiative is None:
        # This queue is derived from the same current-state controls and artifacts used by the workflow.
        for current in db.execute(select(Initiative).where(Initiative.current_stage!='closed').order_by(Initiative.id.desc()).limit(50)).scalars().all():
            for a in db.execute(select(Artifact).where(Artifact.initiative_id==current.id,Artifact.stage==current.current_stage,Artifact.reviewer==user.role,Artifact.status!='approved')).scalars().all():
                if a.kind in ROLE_DOCS.get(user.role,()):queue.append('INIT-'+str(current.id)+': review '+a.kind.replace('-',' ')+'.')
            v=db.get(ValueStream,current.value_stream_id)
            for ctrl in review_state(db,current,v,current.current_stage):
                if ctrl['role']==user.role and ctrl['decision']!='approved':
                    queue.append('INIT-'+str(current.id)+': '+ctrl['decision_title']+'.')
            if len(queue)>=4:break
    if user.role!='admin':
        # Make already-recorded RAID ownership visible as timely work guidance, without inventing deadlines.
        owned=[]
        for entry in db.execute(select(RegisterItem).where(RegisterItem.kind=='raid')).scalars().all():
            try: f=json.loads(entry.fields or '{}')
            except (TypeError,ValueError): continue
            if f.get('owner_role')!=user.role or f.get('status') in ('resolved','closed'):continue
            if initiative is not None and entry.initiative_id not in (None,initiative.id):continue
            due=str(f.get('due_date') or '').strip()[:10]
            if due and not re.fullmatch(r'\d{4}-\d{2}-\d{2}',due):due=''
            urgency='overdue' if due and due<now().date().isoformat() else 'due '+due if due else 'date not set'
            owned.append((due or '9999-12-31','RAID-'+str(entry.id)+': '+entry.title[:90]+' ('+urgency+').'))
        owned.sort(key=lambda item:item[0])
        queue=[x[1] for x in owned[:3]]+queue
    field=req.field_key if get_field(req.field_key) else ''
    if field and get_field(field).get('scope')=='finance' and not finance:field=''
    message,next_page,followups=help_answer(req.question,user.role,page,field,initiative,artifacts,controls,perms,user.role in STAGE_GENERATORS,queue)
    if page=='value_map' and req.stream_id and user.role!='admin':
        stream=db.get(ValueStream,req.stream_id)
        if stream:
            message='For '+stream.name+': '+message

    mode='guided'
    if req.use_ai:
        connector=db.execute(select(Connector).where(Connector.provider=='openai')).scalar_one_or_none()
        if not connector or connector.mode!='live':raise HTTPException(409,'AI chat is not enabled. The guided assistant remains available.')
        cfg=get_config(connector)  # explicit company-approved connector only; no ambient key fallback
        # Minimal, authorized context only. Do not send full documents, credentials, sensitive records, or unrestricted finance data.
        hints=[f'Role: {ROLE_LOOKUP[user.role]["name"]}', f'Current page: {page}', f'Guided answer: {message}']
        if initiative is not None:
            hints.append('Initiative stage: '+initiative.current_stage)
            hints.append('Initiative title: '+initiative.title[:120])
            hints.append('My assigned controls: '+', '.join(c['decision_title']+' ('+c['decision']+')' for c in controls if c['role']==user.role)[:500])
        if field:
            h=get_field(field)
            hints.append('Focused field: '+field+' — '+h['explanation']+' Example: '+h['example'])
        system=('You are a concise embedded work assistant for a commercial specialty insurance SAFe-inspired demo. '
                'Use only the supplied context and give actionable role-scoped guidance. '
                'Do not invent values, approvals, test runs, costs, capabilities or platform actions. '
                'Do not reveal data outside the user role or present guidance as authorization. '
                'Do not execute tools or ask for credentials. '
                'If context is missing, say so and point to the appropriate page. Keep response under 180 words.')
        try:
            with httpx.Client(timeout=25,follow_redirects=False) as client:
                resp=client.post('https://api.openai.com/v1/chat/completions',headers={'Authorization':'Bearer '+cfg['api_key']},json={
                    'model':cfg.get('model','gpt-4.1-mini'),
                    'messages':[{'role':'system','content':system},{'role':'user','content':'\n'.join(hints)+'\n\nQuestion: '+req.question}],
                    'temperature':0.1,'max_tokens':400})
                resp.raise_for_status()
                message=resp.json()['choices'][0]['message']['content'].strip()[:2500]
                mode='connected-ai'
        except Exception as exc:
            raise HTTPException(502,'Connected AI is unavailable ('+type(exc).__name__+'). Try guided help.')
    log(db,user,'help.guidance_viewed','HELP-'+page,{'mode':mode,'field':field[:80],'initiative_id':initiative.id if initiative is not None else None})
    db.commit()
    return {'answer':message,'mode':mode,'page':page,'role':user.role,'action_page':next_page if permitted_page(user.role,next_page,perms) else 'dashboard',
            'followups':followups,'initiative_stage':initiative.current_stage if initiative else None,
            'read_only':True,'note':'Chat provides guidance. Record edits and approvals only in controlled workflow forms.'}

@app.get('/api/connectors')
def connectors(user:User=Depends(get_user),db:Session=Depends(db_session)):
    role_required(user,*VIEW_CONNECTORS)
    return [{'id':c.id,'provider':c.provider,'mode':c.mode,'label':c.label,'status':c.status,'last_check':utcstr(c.last_check),'configured':bool(c.config_encrypted)} for c in db.execute(select(Connector)).scalars().all()]
class ConnectorReq(BaseModel):
    provider:str;mode:str='simulated';config:dict[str,str]=Field(default_factory=dict)
def check_config(provider,c):
    if provider not in PROVIDERS:raise HTTPException(422,'Unknown provider')
    if provider=='github':return all(c.get(x) for x in ['token','repo'])
    if provider in ('jira','confluence'):
        u=urlparse(c.get('base_url',''))
        return u.scheme=='https' and u.hostname and u.hostname.endswith('.atlassian.net') and all(c.get(x) for x in ['email','token'])
    if provider=='sharepoint':return all(c.get(x) for x in ['tenant_id','client_id','client_secret','site_id','drive_id'])
    if provider=='openai':return bool(c.get('api_key'))
    return False
@app.post('/api/connectors')
def configure_connector(req:ConnectorReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,*MANAGE_CONNECTORS)
    if req.provider not in PROVIDERS:raise HTTPException(422,'Unknown provider')
    if req.mode not in ('simulated','live'):raise HTTPException(422,'Unknown mode')
    if req.mode=='live' and (not FERNET or not check_config(req.provider,req.config)):
        raise HTTPException(422,'Live connection requires ENCRYPTION_KEY and valid scoped credentials (provider-specific).')
    c=db.execute(select(Connector).where(Connector.provider==req.provider)).scalar_one_or_none()
    if not c:c=Connector(provider=req.provider);db.add(c)
    c.mode=req.mode;c.config_encrypted=FERNET.encrypt(json.dumps(req.config).encode()).decode() if req.mode=='live' else None;c.status='configured' if req.mode=='live' else 'simulated';c.label=req.provider.title();c.last_check=None
    log(db,user,'integration.configured',req.provider,{'mode':req.mode,'secrets_logged':False});db.commit();return {'provider':req.provider,'mode':c.mode,'status':c.status}

def get_config(c):
    if not FERNET or not c.config_encrypted:raise HTTPException(409,'No live credentials configured')
    try:return json.loads(FERNET.decrypt(c.config_encrypted.encode()))
    except Exception:raise HTTPException(409,'Cannot decrypt credential. Verify ENCRYPTION_KEY')

def graph_token(c):
    with httpx.Client(timeout=15,follow_redirects=False) as client:
        r=client.post(f"https://login.microsoftonline.com/{c['tenant_id']}/oauth2/v2.0/token",data={'grant_type':'client_credentials','client_id':c['client_id'],'client_secret':c['client_secret'],'scope':'https://graph.microsoft.com/.default'})
        r.raise_for_status();return r.json()['access_token']

def connector_ping(provider,c):
    with httpx.Client(timeout=15,follow_redirects=False) as client:
        if provider=='github':
            r=client.get('https://api.github.com/user',headers={'Authorization':'Bearer '+c['token'],'Accept':'application/vnd.github+json'})
        elif provider=='jira':r=client.get(c['base_url'].rstrip('/')+'/rest/api/3/myself',auth=(c['email'],c['token']))
        elif provider=='confluence':r=client.get(c['base_url'].rstrip('/')+'/wiki/api/v2/spaces?limit=1',auth=(c['email'],c['token']))
        elif provider=='sharepoint':r=client.get('https://graph.microsoft.com/v1.0/sites/'+c['site_id'],headers={'Authorization':'Bearer '+graph_token(c)})
        elif provider=='openai':r=client.get('https://api.openai.com/v1/models',headers={'Authorization':'Bearer '+c['api_key']})
        else:raise HTTPException(422,'Unsupported')
        r.raise_for_status();return {'http_status':r.status_code,'verified':True}
@app.post('/api/connectors/{provider}/check')
def check_connector(provider:str,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,*MANAGE_CONNECTORS)
    c=db.execute(select(Connector).where(Connector.provider==provider)).scalar_one_or_none()
    if not c:raise HTTPException(404,'Unknown connector')
    if c.mode=='simulated':
        log(db,user,'integration.simulated_check',provider,{'result':'simulated; no remote call'});db.commit();return {'mode':'simulated','message':'Simulation healthy. No external service was contacted.'}
    try:r=connector_ping(provider,get_config(c));c.status='connected';c.last_check=now();log(db,user,'integration.live_check',provider,{'result':'connected'});db.commit();return {'mode':'live',**r}
    except Exception as exc:
        c.status='error';c.last_check=now();log(db,user,'integration.live_check',provider,{'result':'error','error_type':type(exc).__name__});db.commit();raise HTTPException(502,f'Connection failed ({type(exc).__name__}). Check credentials, host, access scope and network.')
class AgentReq(BaseModel):
    initiative_id:int;instruction:str=Field(default='Refine the technical approach and identify missing requirements, controls and acceptance evidence.',max_length=1500)
@app.post('/api/agents/draft')
def agent_draft(req:AgentReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,*AGENT_DRAFT)
    i=db.get(Initiative,req.initiative_id)
    if not i:raise HTTPException(404,'Initiative not found')
    c=db.execute(select(Connector).where(Connector.provider=='openai')).scalar_one_or_none()
    if c and c.mode=='live':key=get_config(c)['api_key'];model=get_config(c).get('model','gpt-4.1-mini')
    else:key=os.getenv('OPENAI_API_KEY');model=os.getenv('OPENAI_MODEL','gpt-4.1-mini')
    if not key:
        result=(f"# Simulated AI implementation review: {i.title}\n\n"
            f"## Work plan\n1. Inspect relevant repositories and system contracts: {i.dependencies}.\n2. Confirm business rules: {i.rules}.\n3. Design audited workflow: {i.workflow}.\n4. Build requirement-traced changes and automated tests.\n5. Gather independent QA, security and owner approval.\n\n"
            f"## Risks\n{i.risk}\n\n## Evidence required\nPRD refs; architecture signoff; commit/build hash; test execution; approvals; release ID; business KPI.\n\n"
            f"_SIMULATION: No LLM was contacted and no code was executed._")
        mode='simulated'
    else:
        prompt=f"You are a senior commercial insurance implementation engineer. Produce a concise markdown technical analysis only, do not claim code/test execution. Synthetic initiative: {i.title}; workflow: {i.workflow}; rules: {i.rules}; dependencies: {i.dependencies}; risk: {i.risk}. User instruction: {req.instruction}"
        try:
            with httpx.Client(timeout=45,follow_redirects=False) as client:
                r=client.post('https://api.openai.com/v1/chat/completions',headers={'Authorization':'Bearer '+key},json={'model':model,'messages':[{'role':'system','content':'Provide technically grounded, risk-aware documentation. Do not invent evidence or pretend tools ran.'},{'role':'user','content':prompt}],'temperature':0.2,'max_tokens':1200})
                r.raise_for_status();result=r.json()['choices'][0]['message']['content'];mode='live'
        except Exception as exc:raise HTTPException(502,f'LLM request failed: {type(exc).__name__}')
    log(db,user,'agent.draft_created',f'INIT-{i.id}',{'mode':mode,'instruction':req.instruction[:120]});db.commit()
    return {'mode':mode,'markdown':result,'saved':False,'note':'Review and paste into a controlled contract; AI drafts never self-approve.'}
class PublishReq(BaseModel):
    artifact_id:int;provider:str
@app.post('/api/connectors/publish')
def publish_contract(req:PublishReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,*PUBLISH_CONTRACT)
    a=db.get(Artifact,req.artifact_id)
    if not a:raise HTTPException(404,'Artifact not found')
    assert_can_read_artifact(a,user)
    if a.status!='approved':raise HTTPException(409,'Only approved artifacts can be published')
    c=db.execute(select(Connector).where(Connector.provider==req.provider)).scalar_one_or_none()
    if not c:raise HTTPException(404,'Connector not found')
    if c.mode=='simulated':
        log(db,user,'integration.publish_simulated',req.provider,{'artifact':a.id,'version':a.version});db.commit();return {'mode':'simulated','message':'Publish operation simulated and audited; no external write occurred.'}
    cfg=get_config(c);title=f'ART-{a.id}: {a.kind} v{a.version}';body=f'{title}\n\n{a.markdown}'
    try:
        with httpx.Client(timeout=20,follow_redirects=False) as client:
            if req.provider=='github':
                repo=cfg['repo'].strip('/');
                if not re.fullmatch(r'[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+',repo):raise HTTPException(422,'Invalid GitHub owner/repository')
                r=client.post('https://api.github.com/repos/'+repo+'/issues',headers={'Authorization':'Bearer '+cfg['token'],'Accept':'application/vnd.github+json'},json={'title':title,'body':body})
            elif req.provider=='jira':
                if not cfg.get('project_key'):raise HTTPException(422,'Jira project_key is required to publish')
                r=client.post(cfg['base_url'].rstrip('/')+'/rest/api/3/issue',auth=(cfg['email'],cfg['token']),json={'fields':{'project':{'key':cfg['project_key']},'summary':title,'issuetype':{'name':'Task'},'description':{'type':'doc','version':1,'content':[{'type':'paragraph','content':[{'type':'text','text':body[:30000]}]}]}}})
            elif req.provider=='confluence':
                if not cfg.get('space_id'):raise HTTPException(422,'Confluence space_id required to publish')
                r=client.post(cfg['base_url'].rstrip('/')+'/wiki/api/v2/pages',auth=(cfg['email'],cfg['token']),json={'spaceId':cfg['space_id'],'status':'current','title':title,'body':{'representation':'storage','value':'<pre>'+html.escape(body)+'</pre>'}})
            elif req.provider=='sharepoint':
                fname=f'ART-{a.id}-{a.kind}-v{a.version}.md'
                r=client.put('https://graph.microsoft.com/v1.0/drives/'+cfg['drive_id']+'/root:/'+fname+':/content',headers={'Authorization':'Bearer '+graph_token(cfg),'Content-Type':'text/markdown'},content=body.encode())
            else:raise HTTPException(422,'This connector does not support document publishing')
            r.raise_for_status();item=r.json();remote_ref=item.get('html_url') or item.get('webUrl') or item.get('key') or str(item.get('id','created'))
    except HTTPException:raise
    except Exception as exc:raise HTTPException(502,f'External publication failed ({type(exc).__name__})')
    log(db,user,'integration.publish_live',req.provider,{'artifact':a.id,'version':a.version,'remote_ref':remote_ref});db.commit()
    return {'mode':'live','remote_ref':remote_ref,'message':'Approved artifact published to external provider'}

# Value stream mapping is a separate, version-controlled application module.
# Register its models and routes before FastAPI runs its startup handlers.
from .map_routes import install as install_value_stream_mapping
import sys as _sys
install_value_stream_mapping(app, _sys.modules[__name__])
