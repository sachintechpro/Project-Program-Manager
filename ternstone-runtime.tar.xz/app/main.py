"""Ternstone ValueOps — role-governed, evidence-linked value stream delivery demo.
Single organization app. No real company data is included.
"""
import os, json, re, hmac, hashlib, secrets, io, zipfile, html, datetime, base64, asyncio
from pathlib import Path
from typing import Optional, Any
from urllib.parse import urlparse
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, Text, Float, ForeignKey, Boolean, DateTime, select, func
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from cryptography.fernet import Fernet
import httpx
from .catalog import ROLES, ROLE_LOOKUP, STAGES, STAGE_IDS, STREAM_TEMPLATES, INITIATIVE_TEMPLATES, INIT_MAP, DEMO_USERS, contract_text

BASE=Path(__file__).resolve().parent.parent
DEMO=os.getenv('DEMO_MODE','true').lower()=='true'
SECRET=os.getenv('SECRET_KEY') or ('unsafe-local-demo-only-key' if DEMO else None)
if not SECRET: raise RuntimeError('SECRET_KEY required outside demo')
ENCRYPTION_KEY=os.getenv('ENCRYPTION_KEY')
FERNET=Fernet(ENCRYPTION_KEY.encode()) if ENCRYPTION_KEY else None
DB_URL=os.getenv('DATABASE_URL','sqlite:///./valueops.db')
if DB_URL.startswith('postgres://'): DB_URL='postgresql+psycopg://'+DB_URL[len('postgres://'):]
if DB_URL.startswith('postgresql://'): DB_URL='postgresql+psycopg://'+DB_URL[len('postgresql://'):]
engine=create_engine(DB_URL, connect_args={'check_same_thread':False} if DB_URL.startswith('sqlite') else {},pool_pre_ping=True)
SessionLocal=sessionmaker(bind=engine,autoflush=False,expire_on_commit=False)
BaseModelDB=declarative_base()
def now():return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
def utcstr(dt):return dt.replace(tzinfo=datetime.timezone.utc).isoformat() if dt else None

class User(BaseModelDB):
    __tablename__='users'
    id=Column(Integer,primary_key=True); name=Column(String(120),nullable=False); email=Column(String(200),unique=True,nullable=False); role=Column(String(80),nullable=False); password_hash=Column(String(250),nullable=False); active=Column(Boolean,default=True)
class ValueStream(BaseModelDB):
    __tablename__='value_streams'
    id=Column(Integer,primary_key=True); key=Column(String(120),unique=True,nullable=False); name=Column(String(200),nullable=False); lob=Column(String(300)); owner=Column(String(200)); description=Column(Text); theme=Column(Text); metric=Column(String(200)); baseline=Column(Float,default=0); target=Column(Float,default=0); budget=Column(Float,default=0); created_at=Column(DateTime,default=now)
class Initiative(BaseModelDB):
    __tablename__='initiatives'
    id=Column(Integer,primary_key=True); key=Column(String(120),unique=True,nullable=False); value_stream_id=Column(Integer,ForeignKey('value_streams.id'),nullable=False); title=Column(String(220),nullable=False); lob=Column(String(160)); budget=Column(Float,default=0); annual_benefit=Column(Float,default=0); baseline=Column(Float,default=0); target=Column(Float,default=0); unit=Column(String(30),default='days'); volume=Column(String(180),default=''); workflow=Column(Text,default=''); rules=Column(Text,default=''); risk=Column(Text,default=''); dependencies=Column(Text,default=''); current_stage=Column(String(60),default='portfolio'); status=Column(String(40),default='active'); created_at=Column(DateTime,default=now)
class Artifact(BaseModelDB):
    __tablename__='artifacts'
    id=Column(Integer,primary_key=True); initiative_id=Column(Integer,ForeignKey('initiatives.id'),nullable=False); kind=Column(String(80),nullable=False); stage=Column(String(60),nullable=False); markdown=Column(Text,nullable=False); version=Column(Integer,default=1); status=Column(String(30),default='draft'); hash=Column(String(64)); author=Column(String(120)); reviewer=Column(String(80)); approved_by=Column(String(120)); approved_at=Column(DateTime); updated_at=Column(DateTime,default=now)
class ArtifactRevision(BaseModelDB):
    __tablename__='artifact_revisions'
    id=Column(Integer,primary_key=True); artifact_id=Column(Integer,ForeignKey('artifacts.id'),nullable=False); version=Column(Integer,nullable=False); markdown=Column(Text,nullable=False); hash=Column(String(64),nullable=False); author=Column(String(120)); created_at=Column(DateTime,default=now)
class Approval(BaseModelDB):
    __tablename__='approvals'
    id=Column(Integer,primary_key=True); artifact_id=Column(Integer,ForeignKey('artifacts.id'),nullable=False); version=Column(Integer,nullable=False); reviewer_id=Column(Integer,ForeignKey('users.id'),nullable=False); decision=Column(String(30)); comment=Column(Text); content_hash=Column(String(64)); created_at=Column(DateTime,default=now)
class AuditEvent(BaseModelDB):
    __tablename__='audit_events'
    id=Column(Integer,primary_key=True); user_id=Column(Integer); actor=Column(String(120)); action=Column(String(120)); target=Column(String(120)); details=Column(Text); prev_hash=Column(String(64)); hash=Column(String(64)); created_at=Column(DateTime,default=now)
class Connector(BaseModelDB):
    __tablename__='connectors'
    id=Column(Integer,primary_key=True); provider=Column(String(40),unique=True); mode=Column(String(20),default='simulated'); config_encrypted=Column(Text); label=Column(String(100)); status=Column(String(40),default='configured'); last_check=Column(DateTime)

app=FastAPI(title='Ternstone ValueOps',version='0.4.0',docs_url='/api/docs' if DEMO else None,redoc_url=None)
app.mount('/assets',StaticFiles(directory=str(BASE/'app'/'static')),name='static')
serializer=URLSafeTimedSerializer(SECRET,salt='valueops-session')

def db_session():
    with SessionLocal() as db: yield db

def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def password_hash(p):
    salt=secrets.token_hex(16);digest=hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(salt),220_000).hex();return salt+':'+digest
def password_check(p,stored):
    try:
        salt,digest=stored.split(':');actual=hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(salt),220_000).hex();return hmac.compare_digest(actual,digest)
    except Exception:return False

def log(db,user,action,target,details=None):
    # Hash-chained audit events; PostgreSQL production deployments should serialize writers per org.
    last=db.execute(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(1)).scalar_one_or_none()
    prev=last.hash if last else 'GENESIS'; actor=user.name if user else 'system'
    timestamp=now()
    obj={'actor':actor,'action':action,'target':target,'details':details or {},'previous':prev,'time':timestamp.isoformat()}
    payload=json.dumps(obj,sort_keys=True,default=str)
    e=AuditEvent(user_id=getattr(user,'id',None),actor=actor,action=action,target=target,details=json.dumps(details or {},default=str),prev_hash=prev,hash=sha(payload),created_at=timestamp)
    db.add(e);db.flush();return e

def get_user(request:Request,db:Session=Depends(db_session)):
    cookie=request.cookies.get('ternstone_session')
    if not cookie:raise HTTPException(401,'Sign in to continue')
    try:p=serializer.loads(cookie,max_age=60*60*10)
    except (BadSignature,SignatureExpired):raise HTTPException(401,'Session expired; sign in again')
    user=db.get(User,p.get('uid'))
    if not user or not user.active:raise HTTPException(401,'Account unavailable')
    request.state.csrf=p.get('csrf');return user

def guard(request:Request,user:User=Depends(get_user)):
    if request.method in ('POST','PUT','PATCH','DELETE'):
        if not hmac.compare_digest(request.headers.get('x-csrf-token',''),request.state.csrf or ''):
            raise HTTPException(403,'Missing or invalid CSRF token')
    return user

def role_required(user,*roles):
    if user.role not in roles:raise HTTPException(403,'This action requires '+', '.join(roles))

def stream_obj(v):return {'id':v.id,'key':v.key,'name':v.name,'lob':v.lob,'owner':v.owner,'description':v.description,'theme':v.theme,'metric':v.metric,'baseline':v.baseline,'target':v.target,'budget':v.budget,'created_at':utcstr(v.created_at)}
def init_obj(i,stream=None):return {'id':i.id,'key':i.key,'value_stream_id':i.value_stream_id,'stream_name':stream.name if stream else None,'title':i.title,'lob':i.lob,'budget':i.budget,'annual_benefit':i.annual_benefit,'baseline':i.baseline,'target':i.target,'unit':i.unit,'volume':i.volume,'workflow':i.workflow,'rules':i.rules,'risk':i.risk,'dependencies':i.dependencies,'current_stage':i.current_stage,'status':i.status,'created_at':utcstr(i.created_at)}
def artifact_obj(a):return {'id':a.id,'initiative_id':a.initiative_id,'kind':a.kind,'stage':a.stage,'markdown':a.markdown,'version':a.version,'status':a.status,'hash':a.hash,'author':a.author,'reviewer':a.reviewer,'approved_by':a.approved_by,'approved_at':utcstr(a.approved_at),'updated_at':utcstr(a.updated_at)}
def needed(i):return STAGES[STAGE_IDS.index(i.current_stage)]['artifacts'] if i.current_stage!='closed' else []

def seed_demo(db):
    if db.execute(select(User.id).limit(1)).first():return
    for n,r,_ in DEMO_USERS:
        slug=re.sub(r'[^a-z0-9]+','.',n.lower())
        db.add(User(name=n,email=slug+'@ternstone.demo',role=r,password_hash=password_hash('DemoPass!2026')))
    db.flush()
    user_by_role={u.role:u for u in db.execute(select(User)).scalars().all()}
    streams={}
    for t in STREAM_TEMPLATES:
        v=ValueStream(**t);db.add(v);db.flush();streams[t['key']]=v
    for temp in INITIATIVE_TEMPLATES:
        data={k:v for k,v in temp.items() if k not in ('stream','status')};i=Initiative(**data,value_stream_id=streams[temp['stream']].id,current_stage=temp['status']);db.add(i);db.flush()
        # Previous stages are seeded as reviewed illustrative stage history; current stage remains actionable.
        end=STAGE_IDS.index(temp['status'])
        for si in range(end+1):
            st=STAGES[si]
            for kind,title,writer,reviewer in st['artifacts']:
                content=contract_text(kind, data, {**stream_obj(streams[temp['stream']]),'theme':streams[temp['stream']].theme})
                a=Artifact(initiative_id=i.id,kind=kind,stage=st['id'],markdown=content,hash=sha(content),version=1,status='approved' if si<end else 'draft',author='Synthetic sample',reviewer=reviewer,updated_at=now(),approved_by='Synthetic example' if si<end else None,approved_at=now() if si<end else None)
                db.add(a);db.flush()
                db.add(ArtifactRevision(artifact_id=a.id,version=1,markdown=content,hash=a.hash,author=a.author))
                if si<end:
                    rv=user_by_role.get(reviewer)
                    if rv:db.add(Approval(artifact_id=a.id,version=1,reviewer_id=rv.id,decision='approved',comment='Illustrative prior stage approval (seed data only)',content_hash=a.hash))
        log(db,None,'initiative.seeded',f'INIT-{i.id}',{'scenario':i.key,'stage':i.current_stage,'synthetic':True})
    for p in ['jira','confluence','sharepoint','github','openai']:
        db.add(Connector(provider=p,mode='simulated',label=p.title(),status='simulated'))
    db.commit()

def setup():
    BaseModelDB.metadata.create_all(engine)
    with SessionLocal() as db:
        if DEMO:seed_demo(db)
        else:
            email=os.getenv('ADMIN_EMAIL');pw=os.getenv('ADMIN_PASSWORD')
            if not (email and pw and len(pw)>=14): raise RuntimeError('Set ADMIN_EMAIL and strong ADMIN_PASSWORD for production')
            if not db.execute(select(User).limit(1)).first():
                db.add(User(name='Platform Administrator',email=email,role='admin',password_hash=password_hash(pw)));db.commit()
            for p in ['jira','confluence','sharepoint','github','openai']:
                if not db.execute(select(Connector).where(Connector.provider==p)).scalar_one_or_none():db.add(Connector(provider=p,mode='simulated',label=p.title(),status='simulated'))
            db.commit()

@app.on_event('startup')
def startup():setup()

@app.get('/')
def root():return FileResponse(BASE/'app'/'static'/'index.html')
@app.get('/health')
def health():return {'status':'ok','service':'ternstone-valueops','mode':'demo' if DEMO else 'production'}
@app.get('/api/public')
def public():return {'demo':DEMO,'roles':list(ROLE_LOOKUP.values()),'personas':[{'name':n,'role':r,'email':re.sub(r'[^a-z0-9]+','.',n.lower())+'@ternstone.demo'} for n,r,_ in DEMO_USERS] if DEMO else [],'company':'Ternstone Specialty Insurance (fictional)'}
class LoginReq(BaseModel):
    email:str='';password:str='';role:str=''
@app.post('/api/login')
def login(req:LoginReq,db:Session=Depends(db_session)):
    if DEMO and req.role:
        user=db.execute(select(User).where(User.role==req.role)).scalar_one_or_none()
    else:
        user=db.execute(select(User).where(User.email==req.email.strip().lower())).scalar_one_or_none()
        if not user or not password_check(req.password,user.password_hash):raise HTTPException(401,'Invalid credentials')
    if not user:raise HTTPException(401,'Unknown demo role')
    csrf=secrets.token_urlsafe(24);token=serializer.dumps({'uid':user.id,'csrf':csrf})
    resp=Response(content=json.dumps({'user':{'name':user.name,'role':user.role,'email':user.email},'csrf':csrf}),media_type='application/json')
    resp.set_cookie('ternstone_session',token,max_age=36000,httponly=True,secure=os.getenv('SECURE_COOKIES','false').lower()=='true',samesite='lax')
    return resp
@app.post('/api/logout')
def logout(request:Request,user:User=Depends(guard)):
    resp=Response(content='{}',media_type='application/json');resp.delete_cookie('ternstone_session');return resp
@app.get('/api/me')
def me(request:Request,user:User=Depends(get_user)):
    return {'name':user.name,'email':user.email,'role':user.role,'csrf':request.state.csrf,'demo':DEMO,'role_name':ROLE_LOOKUP[user.role]['name']}
class NewUser(BaseModel):
    name:str=Field(min_length=3,max_length=120)
    email:str=Field(min_length=6,max_length=200)
    role:str
    password:str=Field(min_length=14,max_length=128)
@app.get('/api/users')
def list_users(user:User=Depends(get_user),db:Session=Depends(db_session)):
    role_required(user,'admin')
    rows=db.execute(select(User).order_by(User.name)).scalars().all()
    return [{'id':u.id,'name':u.name,'email':u.email,'role':u.role,'active':u.active} for u in rows]
@app.post('/api/users')
def create_user(req:NewUser,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'admin')
    if req.role not in ROLE_LOOKUP:raise HTTPException(422,'Unknown organizational role')
    email=req.email.strip().lower()
    if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email):raise HTTPException(422,'Invalid email')
    if db.execute(select(User).where(User.email==email)).scalar_one_or_none():raise HTTPException(409,'Email is already registered')
    u=User(name=req.name.strip(),email=email,role=req.role,password_hash=password_hash(req.password))
    db.add(u);db.flush();log(db,user,'user.created',f'USER-{u.id}',{'role':u.role,'email':u.email});db.commit()
    return {'id':u.id,'name':u.name,'email':u.email,'role':u.role}
@app.post('/api/users/{uid}/disable')
def disable_user(uid:int,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'admin')
    if user.id==uid:raise HTTPException(409,'Cannot disable your own account')
    u=db.get(User,uid)
    if not u:raise HTTPException(404,'User not found')
    u.active=False;log(db,user,'user.disabled',f'USER-{uid}',{'role':u.role});db.commit()
    return {'id':uid,'active':False}

@app.get('/api/catalog')
def catalog(user:User=Depends(get_user)):
    return {'roles':list(ROLE_LOOKUP.values()),'stages':STAGES,'streams':STREAM_TEMPLATES,'initiatives':INITIATIVE_TEMPLATES,'insurance_products':['Workers Compensation','Commercial Property','General Liability','Cyber Insurance','Marine Cargo','Commercial Auto','Professional Liability','Construction','Aviation','Risk Engineering']}
@app.get('/api/summary')
def summary(user:User=Depends(get_user),db:Session=Depends(db_session)):
    streams=db.execute(select(ValueStream)).scalars().all();initiatives=db.execute(select(Initiative)).scalars().all();arts=db.execute(select(Artifact)).scalars().all()
    needs_review=[a for a in arts if a.status=='draft' and a.reviewer==user.role and any(x.id==a.initiative_id and x.current_stage==a.stage for x in initiatives)]
    return {'streams':len(streams),'initiatives':len(initiatives),'active':sum(i.current_stage!='closed' for i in initiatives),'total_budget':sum(i.budget for i in initiatives),'expected_annual_benefit':sum(i.annual_benefit for i in initiatives),'approved_artifacts':sum(a.status=='approved' for a in arts),'pending_review':len(needs_review),'by_stage':[{'stage':s,'count':sum(i.current_stage==s for i in initiatives)} for s in STAGE_IDS]}
@app.get('/api/streams')
def streams(user:User=Depends(get_user),db:Session=Depends(db_session)):
    vals=db.execute(select(ValueStream).order_by(ValueStream.name)).scalars().all()
    return [dict(stream_obj(v),initiative_count=db.scalar(select(func.count(Initiative.id)).where(Initiative.value_stream_id==v.id)) or 0) for v in vals]
class NewStream(BaseModel):
    template:str='';name:str=Field(min_length=5,max_length=200);lob:str=Field(default='',max_length=300);owner:str=Field(default='',max_length=200);description:str=Field(default='',max_length=2500);theme:str=Field(default='',max_length=1000);metric:str=Field(default='Median end-to-end days',max_length=200);baseline:float=Field(default=10,ge=0);target:float=Field(default=5,ge=0);budget:float=Field(default=100000,ge=0,le=1e10)
@app.post('/api/streams')
def create_stream(req:NewStream,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'lpm','vmo','value_owner','executive')
    key=re.sub('[^a-z0-9]+','-',req.name.lower()).strip('-')[:85]+'-'+secrets.token_hex(3)
    v=ValueStream(key=key,**req.model_dump(exclude={'template'}));db.add(v);db.flush();log(db,user,'stream.created',f'VS-{v.id}',{'name':v.name,'from_template':req.template});db.commit();return stream_obj(v)
@app.get('/api/initiatives')
def initiatives(stream_id:int=0,user:User=Depends(get_user),db:Session=Depends(db_session)):
    q=select(Initiative).order_by(Initiative.id.desc())
    if stream_id:q=q.where(Initiative.value_stream_id==stream_id)
    vals=db.execute(q).scalars().all();vmap={v.id:v for v in db.execute(select(ValueStream)).scalars()}
    return [init_obj(i,vmap.get(i.value_stream_id)) for i in vals]
class NewInitiative(BaseModel):
    stream_id:int;template:str='';title:str=Field(min_length=7,max_length=220);lob:str=Field(default='Commercial & Specialty Insurance',max_length=160);budget:float=Field(default=150000,ge=0);annual_benefit:float=Field(default=225000,ge=0);baseline:float=Field(default=12,ge=0);target:float=Field(default=7,ge=0);unit:str=Field(default='days',max_length=30);volume:str=Field(default='Illustrative operating volume',max_length=180);workflow:str=Field(default='Intake → validate → review → fulfill → measure',max_length=3000);rules:str=Field(default='Human authority required for material insurance decisions.',max_length=3000);risk:str=Field(default='Access and data quality controls are required.',max_length=2000);dependencies:str=Field(default='Policy, claims or billing administration',max_length=1000)
@app.post('/api/initiatives')
def create_init(req:NewInitiative,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'lpm','epic_owner','vmo','product_manager','program_manager')
    v=db.get(ValueStream,req.stream_id)
    if not v:raise HTTPException(404,'Unknown value stream')
    key=re.sub('[^a-z0-9]+','-',req.title.lower()).strip('-')[:82]+'-'+secrets.token_hex(3)
    i=Initiative(key=key,value_stream_id=v.id,**req.model_dump(exclude={'stream_id','template'}));db.add(i);db.flush();log(db,user,'initiative.created',f'INIT-{i.id}',{'title':i.title,'value_stream':v.name});db.commit();return init_obj(i,v)
@app.get('/api/initiatives/{iid}')
def initiative_detail(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    v=db.get(ValueStream,i.value_stream_id)
    arts=db.execute(select(Artifact).where(Artifact.initiative_id==iid).order_by(Artifact.id)).scalars().all()
    return {'initiative':init_obj(i,v),'value_stream':stream_obj(v),'artifacts':[artifact_obj(a) for a in arts], 'stages':STAGES,'needed':[{'kind':a[0],'title':a[1],'author_role':a[2],'reviewer_role':a[3]} for a in needed(i)]}
@app.post('/api/initiatives/{iid}/generate')
def generate_contracts(iid:int,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Unknown initiative')
    if i.current_stage=='closed':raise HTTPException(409,'This initiative has been closed')
    stage=STAGES[STAGE_IDS.index(i.current_stage)]
    allowed={stage['owner'],'lpm','epic_owner','program_manager','rte','fde','product_owner','analytics'}
    role_required(user,*allowed)
    v=db.get(ValueStream,i.value_stream_id)
    made=[]
    for kind,title,writer,reviewer in stage['artifacts']:
        if db.execute(select(Artifact).where(Artifact.initiative_id==i.id,Artifact.kind==kind)).scalar_one_or_none():continue
        content=contract_text(kind,init_obj(i),stream_obj(v))
        a=Artifact(initiative_id=i.id,kind=kind,stage=i.current_stage,markdown=content,hash=sha(content),author=user.name,reviewer=reviewer,status='draft')
        db.add(a);db.flush();db.add(ArtifactRevision(artifact_id=a.id,version=1,markdown=content,hash=a.hash,author=user.name));made.append(kind);log(db,user,'contract.generated',f'ART-{a.id}',{'type':kind,'initiative':i.key,'sha256':a.hash})
    db.commit();return {'generated':made,'message':'Contracts created. Approval is never automatic.'}
class ArtifactEdit(BaseModel):
    markdown:str=Field(min_length=80,max_length=80000);expected_version:int=Field(ge=1)
@app.put('/api/artifacts/{aid}')
def update_artifact(aid:int,req:ArtifactEdit,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    a=db.get(Artifact,aid)
    if not a:raise HTTPException(404,'Artifact not found')
    i=db.get(Initiative,a.initiative_id)
    if i.current_stage!=a.stage:raise HTTPException(409,'This stage is not active; historical contracts are read only')
    writer=next(x[2] for x in STAGES[STAGE_IDS.index(a.stage)]['artifacts'] if x[0]==a.kind)
    role_required(user,writer)
    if req.expected_version!=a.version:raise HTTPException(409,'Artifact changed since you opened it. Refresh to prevent overwriting work.')
    if a.markdown==req.markdown:return artifact_obj(a)
    a.markdown=req.markdown;a.version+=1;a.hash=sha(req.markdown);a.author=user.name;a.status='draft';a.approved_at=None;a.approved_by=None;a.updated_at=now()
    db.add(ArtifactRevision(artifact_id=a.id,version=a.version,markdown=req.markdown,hash=a.hash,author=user.name))
    log(db,user,'contract.revised',f'ART-{a.id}',{'version':a.version,'sha256':a.hash,'previous_approvals_invalidated':True});db.commit();return artifact_obj(a)
class ReviewReq(BaseModel):
    decision:str;comment:str=Field(default='',max_length=3000);expected_version:int=Field(ge=1)
@app.post('/api/artifacts/{aid}/review')
def review_artifact(aid:int,req:ReviewReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    a=db.get(Artifact,aid)
    if not a:raise HTTPException(404,'Artifact not found')
    i=db.get(Initiative,a.initiative_id)
    if i.current_stage!=a.stage:raise HTTPException(409,'Only current-stage contracts are reviewable')
    if req.decision not in ('approved','rejected'):raise HTTPException(422,'Decision must be approved or rejected')
    if req.expected_version!=a.version:raise HTTPException(409,'Artifact version has changed; review current evidence')
    role_required(user,a.reviewer)
    if a.status=='approved':raise HTTPException(409,'Already approved. Revise the contract before re-review.')
    if not a.markdown.strip().startswith('# ') or '## ' not in a.markdown:raise HTTPException(422,'Contract must contain a title and structured sections before review')
    a.status=req.decision;a.approved_by=user.name if req.decision=='approved' else None;a.approved_at=now() if req.decision=='approved' else None
    db.add(Approval(artifact_id=a.id,version=a.version,reviewer_id=user.id,decision=req.decision,comment=req.comment,content_hash=a.hash))
    log(db,user,'contract.'+req.decision,f'ART-{a.id}',{'version':a.version,'sha256':a.hash,'comment':req.comment[:500]})
    advanced=False
    if req.decision=='approved':
        required=[a[0] for a in needed(i)]
        all_a=db.execute(select(Artifact).where(Artifact.initiative_id==i.id,Artifact.stage==i.current_stage)).scalars().all()
        if all(any(a.kind==kind and a.status=='approved' for a in all_a) for kind in required):
            old=i.current_stage;i.current_stage=STAGE_IDS[STAGE_IDS.index(old)+1]
            if i.current_stage=='closed':i.status='closed'
            advanced=True
            log(db,user,'initiative.stage_advanced',f'INIT-{i.id}',{'from':old,'to':i.current_stage,'approved_contracts':required})
    db.commit();return {'artifact':artifact_obj(a),'advanced':advanced,'next_stage':i.current_stage}
@app.get('/api/approvals')
def approvals(user:User=Depends(get_user),db:Session=Depends(db_session)):
    rows=db.execute(select(Artifact,Initiative).join(Initiative,Artifact.initiative_id==Initiative.id).where(Artifact.stage==Initiative.current_stage,Artifact.status.in_(['draft','rejected'])).order_by(Artifact.updated_at.desc())).all()
    return [{'artifact':artifact_obj(a),'initiative':init_obj(i),'assigned_to_me':a.reviewer==user.role or user.role=='admin'} for a,i in rows]
@app.get('/api/artifacts')
def artifacts(user:User=Depends(get_user),db:Session=Depends(db_session)):
    rows=db.execute(select(Artifact,Initiative).join(Initiative,Artifact.initiative_id==Initiative.id).order_by(Artifact.updated_at.desc())).all()
    return [{'artifact':artifact_obj(a),'initiative':{'id':i.id,'title':i.title,'key':i.key}} for a,i in rows]
@app.get('/api/artifacts/{aid}/download')
def download_artifact(aid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    a=db.get(Artifact,aid)
    if not a:raise HTTPException(404,'Not found')
    meta=f"---\nschema: {a.kind}/v1\nartifact_id: ART-{a.id}\ninitiative_id: INIT-{a.initiative_id}\nstage: {a.stage}\nversion: {a.version}\nstatus: {a.status}\nsha256: {a.hash}\nreviewer_role: {a.reviewer}\napproved_by: {json.dumps(a.approved_by)}\n---\n\n"
    return Response(content=meta+a.markdown,media_type='text/markdown; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="ART-{a.id}-{a.kind}-v{a.version}.md"'})
@app.get('/api/initiatives/{iid}/export')
def export_initiative(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Not found')
    arts=db.execute(select(Artifact).where(Artifact.initiative_id==iid)).scalars().all()
    bio=io.BytesIO()
    with zipfile.ZipFile(bio,'w',zipfile.ZIP_DEFLATED) as z:
        manifest={'initiative':init_obj(i),'exported_at':now().isoformat(),'artifacts':[{'id':a.id,'kind':a.kind,'version':a.version,'status':a.status,'sha256':a.hash} for a in arts]}
        z.writestr('manifest.json',json.dumps(manifest,indent=2))
        for a in arts:
            fm=f'---\nschema: {a.kind}/v1\nartifact_id: ART-{a.id}\ninitiative_id: INIT-{i.id}\nversion: {a.version}\nstatus: {a.status}\nsha256: {a.hash}\n---\n\n'
            z.writestr(f'{a.stage}/{a.kind}.md',fm+a.markdown)
            revisions=db.execute(select(ArtifactRevision).where(ArtifactRevision.artifact_id==a.id).order_by(ArtifactRevision.version)).scalars().all()
            for rev in revisions:
                z.writestr(f'history/ART-{a.id}/v{rev.version}.md',f'---\nartifact_id: ART-{a.id}\nversion: {rev.version}\nsha256: {rev.hash}\n---\n\n'+rev.markdown)
    return Response(content=bio.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="{i.key}-evidence.zip"'})
@app.get('/api/artifacts/{aid}/revisions')
def artifact_revisions(aid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    a=db.get(Artifact,aid)
    if not a:raise HTTPException(404,'Not found')
    revisions=db.execute(select(ArtifactRevision).where(ArtifactRevision.artifact_id==aid).order_by(ArtifactRevision.version)).scalars().all()
    return [{'version':r.version,'hash':r.hash,'author':r.author,'markdown':r.markdown,'created_at':utcstr(r.created_at)} for r in revisions]
@app.get('/api/audit/verify')
def verify_audit(user:User=Depends(get_user),db:Session=Depends(db_session)):
    events=db.execute(select(AuditEvent).order_by(AuditEvent.id)).scalars().all()
    prev='GENESIS'
    for e in events:
        obj={'actor':e.actor,'action':e.action,'target':e.target,'details':json.loads(e.details or '{}'),'previous':prev,'time':e.created_at.isoformat()}
        digest=sha(json.dumps(obj,sort_keys=True,default=str))
        if e.prev_hash!=prev or digest!=e.hash:
            return {'valid':False,'failed_id':e.id,'events_checked':e.id-1}
        prev=e.hash
    return {'valid':True,'events_checked':len(events),'chain_head':prev}
@app.get('/api/live')
async def live_events(request:Request,user:User=Depends(get_user)):
    async def events():
        with SessionLocal() as session:
            seen=session.scalar(select(func.max(AuditEvent.id))) or 0
        yield f'data: {json.dumps({"type":"ready","last_event_id":seen})}\n\n'
        while not await request.is_disconnected():
            with SessionLocal() as session:
                newest=session.scalar(select(func.max(AuditEvent.id))) or 0
            if newest>seen:
                seen=newest
                yield f'data: {json.dumps({"type":"update","last_event_id":seen})}\n\n'
            else:yield ': keepalive\n\n'
            await asyncio.sleep(2)
    return StreamingResponse(events(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})

@app.get('/api/audit')
def audit(limit:int=100,user:User=Depends(get_user),db:Session=Depends(db_session)):
    results=db.execute(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(min(max(limit,1),500))).scalars().all()
    return [{'id':e.id,'actor':e.actor,'action':e.action,'target':e.target,'details':json.loads(e.details or '{}'),'hash':e.hash,'prev_hash':e.prev_hash,'created_at':utcstr(e.created_at)} for e in results]
@app.get('/api/insights')
def insights(user:User=Depends(get_user),db:Session=Depends(db_session)):
    streams=db.execute(select(ValueStream)).scalars().all();inits=db.execute(select(Initiative)).scalars().all()
    return {'streams':[{'name':v.name,'id':v.id,'metric':v.metric,'baseline':v.baseline,'target':v.target,'budget':v.budget,'initiative_count':sum(i.value_stream_id==v.id for i in inits),'initiative_budget':sum(i.budget for i in inits if i.value_stream_id==v.id),'illustrative':True} for v in streams], 'by_lob':[{'lob':lob,'count':sum(i.lob==lob for i in inits)} for lob in sorted({i.lob for i in inits})]}

# Org integration connections: secret config stored encrypted only with ENCRYPTION_KEY.
PROVIDERS=['github','jira','confluence','sharepoint','openai']
@app.get('/api/connectors')
def connectors(user:User=Depends(get_user),db:Session=Depends(db_session)):
    return [{'id':c.id,'provider':c.provider,'mode':c.mode,'label':c.label,'status':c.status,'last_check':utcstr(c.last_check),'configured':bool(c.config_encrypted)} for c in db.execute(select(Connector)).scalars().all()]
class ConnectorReq(BaseModel):
    provider:str;mode:str='simulated';config:dict[str,str]=Field(default_factory=dict)
def check_config(provider,c):
    if provider not in PROVIDERS:raise HTTPException(422,'Unknown provider')
    if provider=='github':return all(c.get(x) for x in ['token','repo'])
    if provider in ('jira','confluence'):
        u=urlparse(c.get('base_url',''))
        return u.scheme=='https' and u.hostname and u.hostname.endswith('.atlassian.net') and all(c.get(x) for x in ['email','token'])
    if provider=='sharepoint':return all(c.get(x) for x in ['tenant_id','client_id','client_secret','site_id','drive_id'])
    if provider=='openai':return bool(c.get('api_key'))
    return False
@app.post('/api/connectors')
def configure_connector(req:ConnectorReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'admin','lpm')
    if req.provider not in PROVIDERS:raise HTTPException(422,'Unknown provider')
    if req.mode not in ('simulated','live'):raise HTTPException(422,'Unknown mode')
    if req.mode=='live' and (not FERNET or not check_config(req.provider,req.config)):
        raise HTTPException(422,'Live connection requires ENCRYPTION_KEY and valid scoped credentials (provider-specific).')
    c=db.execute(select(Connector).where(Connector.provider==req.provider)).scalar_one_or_none()
    if not c:c=Connector(provider=req.provider);db.add(c)
    c.mode=req.mode;c.config_encrypted=FERNET.encrypt(json.dumps(req.config).encode()).decode() if req.mode=='live' else None;c.status='configured' if req.mode=='live' else 'simulated';c.label=req.provider.title();c.last_check=None
    log(db,user,'integration.configured',req.provider,{'mode':req.mode,'secrets_logged':False});db.commit();return {'provider':req.provider,'mode':c.mode,'status':c.status}

def get_config(c):
    if not FERNET or not c.config_encrypted:raise HTTPException(409,'No live credentials configured')
    try:return json.loads(FERNET.decrypt(c.config_encrypted.encode()))
    except Exception:raise HTTPException(409,'Cannot decrypt credential. Verify ENCRYPTION_KEY')

def graph_token(c):
    with httpx.Client(timeout=15,follow_redirects=False) as client:
        r=client.post(f"https://login.microsoftonline.com/{c['tenant_id']}/oauth2/v2.0/token",data={'grant_type':'client_credentials','client_id':c['client_id'],'client_secret':c['client_secret'],'scope':'https://graph.microsoft.com/.default'})
        r.raise_for_status();return r.json()['access_token']

def connector_ping(provider,c):
    with httpx.Client(timeout=15,follow_redirects=False) as client:
        if provider=='github':
            r=client.get('https://api.github.com/user',headers={'Authorization':'Bearer '+c['token'],'Accept':'application/vnd.github+json'})
        elif provider=='jira':r=client.get(c['base_url'].rstrip('/')+'/rest/api/3/myself',auth=(c['email'],c['token']))
        elif provider=='confluence':r=client.get(c['base_url'].rstrip('/')+'/wiki/api/v2/spaces?limit=1',auth=(c['email'],c['token']))
        elif provider=='sharepoint':r=client.get('https://graph.microsoft.com/v1.0/sites/'+c['site_id'],headers={'Authorization':'Bearer '+graph_token(c)})
        elif provider=='openai':r=client.get('https://api.openai.com/v1/models',headers={'Authorization':'Bearer '+c['api_key']})
        else:raise HTTPException(422,'Unsupported')
        r.raise_for_status();return {'http_status':r.status_code,'verified':True}
@app.post('/api/connectors/{provider}/check')
def check_connector(provider:str,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'admin','lpm')
    c=db.execute(select(Connector).where(Connector.provider==provider)).scalar_one_or_none()
    if not c:raise HTTPException(404,'Unknown connector')
    if c.mode=='simulated':
        log(db,user,'integration.simulated_check',provider,{'result':'simulated; no remote call'});db.commit();return {'mode':'simulated','message':'Simulation healthy. No external service was contacted.'}
    try:r=connector_ping(provider,get_config(c));c.status='connected';c.last_check=now();log(db,user,'integration.live_check',provider,{'result':'connected'});db.commit();return {'mode':'live',**r}
    except Exception as exc:
        c.status='error';c.last_check=now();log(db,user,'integration.live_check',provider,{'result':'error','error_type':type(exc).__name__});db.commit();raise HTTPException(502,f'Connection failed ({type(exc).__name__}). Check credentials, host, access scope and network.')
class AgentReq(BaseModel):
    initiative_id:int;instruction:str=Field(default='Refine the technical approach and identify missing requirements, controls and acceptance evidence.',max_length=1500)
@app.post('/api/agents/draft')
def agent_draft(req:AgentReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'fde','architect','product_owner','program_manager','qa','epic_owner')
    i=db.get(Initiative,req.initiative_id)
    if not i:raise HTTPException(404,'Initiative not found')
    c=db.execute(select(Connector).where(Connector.provider=='openai')).scalar_one_or_none()
    if c and c.mode=='live':key=get_config(c)['api_key'];model=get_config(c).get('model','gpt-4.1-mini')
    else:key=os.getenv('OPENAI_API_KEY');model=os.getenv('OPENAI_MODEL','gpt-4.1-mini')
    if not key:
        result=(f"# Simulated AI implementation review: {i.title}\n\n"
            f"## Work plan\n1. Inspect relevant repositories and system contracts: {i.dependencies}.\n2. Confirm business rules: {i.rules}.\n3. Design audited workflow: {i.workflow}.\n4. Build requirement-traced changes and automated tests.\n5. Gather independent QA, security and owner approval.\n\n"
            f"## Risks\n{i.risk}\n\n## Evidence required\nPRD refs; architecture signoff; commit/build hash; test execution; approvals; release ID; business KPI.\n\n"
            f"_SIMULATION: No LLM was contacted and no code was executed._")
        mode='simulated'
    else:
        prompt=f"You are a senior commercial insurance implementation engineer. Produce a concise markdown technical analysis only, do not claim code/test execution. Synthetic initiative: {i.title}; workflow: {i.workflow}; rules: {i.rules}; dependencies: {i.dependencies}; risk: {i.risk}. User instruction: {req.instruction}"
        try:
            with httpx.Client(timeout=45,follow_redirects=False) as client:
                r=client.post('https://api.openai.com/v1/chat/completions',headers={'Authorization':'Bearer '+key},json={'model':model,'messages':[{'role':'system','content':'Provide technically grounded, risk-aware documentation. Do not invent evidence or pretend tools ran.'},{'role':'user','content':prompt}],'temperature':0.2,'max_tokens':1200})
                r.raise_for_status();result=r.json()['choices'][0]['message']['content'];mode='live'
        except Exception as exc:raise HTTPException(502,f'LLM request failed: {type(exc).__name__}')
    log(db,user,'agent.draft_created',f'INIT-{i.id}',{'mode':mode,'instruction':req.instruction[:120]});db.commit()
    return {'mode':mode,'markdown':result,'saved':False,'note':'Review and paste into a controlled contract; AI drafts never self-approve.'}
class PublishReq(BaseModel):
    artifact_id:int;provider:str
@app.post('/api/connectors/publish')
def publish_contract(req:PublishReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    role_required(user,'admin','lpm','vmo','program_manager')
    a=db.get(Artifact,req.artifact_id)
    if not a:raise HTTPException(404,'Artifact not found')
    if a.status!='approved':raise HTTPException(409,'Only approved artifacts can be published')
    c=db.execute(select(Connector).where(Connector.provider==req.provider)).scalar_one_or_none()
    if not c:raise HTTPException(404,'Connector not found')
    if c.mode=='simulated':
        log(db,user,'integration.publish_simulated',req.provider,{'artifact':a.id,'version':a.version});db.commit();return {'mode':'simulated','message':'Publish operation simulated and audited; no external write occurred.'}
    cfg=get_config(c);title=f'ART-{a.id}: {a.kind} v{a.version}';body=f'{title}\n\n{a.markdown}'
    try:
        with httpx.Client(timeout=20,follow_redirects=False) as client:
            if req.provider=='github':
                repo=cfg['repo'].strip('/');
                if not re.fullmatch(r'[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+',repo):raise HTTPException(422,'Invalid GitHub owner/repository')
                r=client.post('https://api.github.com/repos/'+repo+'/issues',headers={'Authorization':'Bearer '+cfg['token'],'Accept':'application/vnd.github+json'},json={'title':title,'body':body})
            elif req.provider=='jira':
                if not cfg.get('project_key'):raise HTTPException(422,'Jira project_key is required to publish')
                r=client.post(cfg['base_url'].rstrip('/')+'/rest/api/3/issue',auth=(cfg['email'],cfg['token']),json={'fields':{'project':{'key':cfg['project_key']},'summary':title,'issuetype':{'name':'Task'},'description':{'type':'doc','version':1,'content':[{'type':'paragraph','content':[{'type':'text','text':body[:30000]}]}]}}})
            elif req.provider=='confluence':
                if not cfg.get('space_id'):raise HTTPException(422,'Confluence space_id required to publish')
                r=client.post(cfg['base_url'].rstrip('/')+'/wiki/api/v2/pages',auth=(cfg['email'],cfg['token']),json={'spaceId':cfg['space_id'],'status':'current','title':title,'body':{'representation':'storage','value':'<pre>'+html.escape(body)+'</pre>'}})
            elif req.provider=='sharepoint':
                fname=f'ART-{a.id}-{a.kind}-v{a.version}.md'
                r=client.put('https://graph.microsoft.com/v1.0/drives/'+cfg['drive_id']+'/root:/'+fname+':/content',headers={'Authorization':'Bearer '+graph_token(cfg),'Content-Type':'text/markdown'},content=body.encode())
            else:raise HTTPException(422,'This connector does not support document publishing')
            r.raise_for_status();item=r.json();remote_ref=item.get('html_url') or item.get('webUrl') or item.get('key') or str(item.get('id','created'))
    except HTTPException:raise
    except Exception as exc:raise HTTPException(502,f'External publication failed ({type(exc).__name__})')
    log(db,user,'integration.publish_live',req.provider,{'artifact':a.id,'version':a.version,'remote_ref':remote_ref});db.commit()
    return {'mode':'live','remote_ref':remote_ref,'message':'Approved artifact published to external provider'}
