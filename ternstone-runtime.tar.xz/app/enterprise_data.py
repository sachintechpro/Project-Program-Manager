"""Human-readable, schema-validated commercial and specialty insurance reference packs.

All figures are illustrative; runtime approvals and measurements are NOT sourced here.
"""
import csv,json
from pathlib import Path
from functools import lru_cache
DATA=Path(__file__).resolve().parents[1]/'seed'/'data'
TABLE_LABELS={
'value_streams':'Value stream definitions','initiatives':'Initiative business cases','business_steps':'Operational workflow steps','requirements':'Business and product requirements','business_rules':'Insurance decision rules','data_fields':'Data contracts and validation rules','interfaces':'Integration contracts','test_cases':'Planned test cases','risks':'Risk register examples','dependencies':'External dependencies','stakeholder_assignments':'Stakeholder responsibility examples','metrics':'Benefits and KPI baselines','cost_estimates':'Investment cost breakdown','release_controls':'Release assurance','handover_tasks':'Operations handover','role_approval_controls':'Role decision responsibilities'}
FINANCIAL_TABLES={'cost_estimates'}
@lru_cache(maxsize=1)
def schemas():return json.loads((DATA/'schema.json').read_text(encoding='utf-8'))
@lru_cache(maxsize=50)
def table(name):
    if name not in TABLE_LABELS:raise ValueError('Unknown data table')
    with (DATA/(name+'.csv')).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))

def data_for(template_key,financial_access=False):
    result={}
    for name in TABLE_LABELS:
        if name in ('initiatives','value_streams','role_approval_controls') or (name in FINANCIAL_TABLES and not financial_access):continue
        rows=[dict(row) for row in table(name) if row.get('initiative_key')==template_key]
        if rows:result[name]=rows
    return result

def preview(template_key,financial_access=False):
    result={'template_key':template_key,'tables':data_for(template_key,financial_access),'schemas':{k:schemas()[k] for k in data_for(template_key,financial_access)}}
    result['counts']={k:len(v) for k,v in result['tables'].items()}
    return result

def doc_appendix(kind,template_key,record_overrides=None):
    """Bring relevant concrete reference rows into the generated Markdown contract."""
    mapping={
     'portfolio-epic':['metrics','business_steps','risks'],
     'lean-business-case':['metrics','risks','dependencies'],
     'brd':['business_steps','business_rules','stakeholder_assignments'],
     'prd':['requirements','business_rules','data_fields'],
     'technical-plan':['interfaces','dependencies','data_fields'],
     'integration-contract':['interfaces','data_fields'],
     'implementation-report':['requirements','interfaces','test_cases'],
     'qa-report':['requirements','test_cases','release_controls'],
     'security-review':['business_rules','data_fields','risks'],
     'release-plan':['release_controls','dependencies'],
     'ops-handover':['handover_tasks','interfaces'],
     'benefits-report':['metrics','handover_tasks']}
    if template_key not in {x['initiative_key'] for x in table('initiatives')}:return ''
    sections=[]
    for name in mapping.get(kind,[]):
        data=(record_overrides.get(name,[]) if record_overrides else [x for x in table(name) if x.get('initiative_key')==template_key])
        if not data:continue
        # Explicit values and IDs remain accessible to humans without wide unreadable raw tables.
        lines=[f'### {TABLE_LABELS[name]}']
        for row in data:
            key=next(iter(row.values()))
            fields=[f'**{k.replace("_"," ").capitalize()}**: {str(v).strip()}' for k,v in row.items() if k not in ('initiative_key',) and str(v).strip()]
            lines.append(f'- **{key}** — '+'; '.join(fields[1:]))
        sections.append('\n'.join(lines))
    return '\n\n## Initiative-specific reference data (examples)\n\n'+'\n\n'.join(sections)+'\n\n> Source: versioned seed/data CSVs. These are example requirements and planned checks, not evidence of completed execution or realized benefits.\n'
