"""Explicit, conservative role/contract policy for Ternstone ValueOps.

This demo provides role-level authorization only. Production use also requires
organization, value stream, assignment, data classification and object-level grants.
"""
ALL_DOCS = frozenset({
 'portfolio-epic','lean-business-case','brd','prd','technical-plan','integration-contract',
 'implementation-report','qa-report','security-review','release-plan','ops-handover','benefits-report'
})
FIN_DOCS = frozenset({'portfolio-epic','lean-business-case','benefits-report'})
ROLE_DOCS = {
 'executive': {'portfolio-epic','lean-business-case','brd','prd','release-plan','benefits-report'},
 'lpm': {'portfolio-epic','lean-business-case','brd','prd','release-plan','benefits-report'},
 'vmo': {'portfolio-epic','lean-business-case','brd','prd','qa-report','release-plan','ops-handover','benefits-report'},
 'finance': {'portfolio-epic','lean-business-case','benefits-report'},
 'epic_owner': {'portfolio-epic','lean-business-case','brd','prd','release-plan','benefits-report'},
 'enterprise_architect': {'prd','technical-plan','integration-contract','implementation-report','security-review'},
 'business_owner': {'portfolio-epic','lean-business-case','brd','prd','qa-report','release-plan','ops-handover','benefits-report'},
 'value_owner': {'portfolio-epic','lean-business-case','brd','prd','qa-report','release-plan','ops-handover','benefits-report'},
 'product_manager': {'portfolio-epic','lean-business-case','brd','prd','technical-plan','qa-report','release-plan','benefits-report'},
 'product_owner': {'brd','prd','technical-plan','integration-contract','implementation-report','qa-report','release-plan','ops-handover'},
 'rte': {'brd','prd','technical-plan','integration-contract','implementation-report','qa-report','security-review','release-plan','ops-handover'},
 'program_manager': set(ALL_DOCS),
 'team_coach': {'prd','technical-plan','implementation-report','qa-report','release-plan'},
 'fde': {'brd','prd','technical-plan','integration-contract','implementation-report','qa-report','security-review','release-plan','ops-handover'},
 'engineer': {'prd','technical-plan','integration-contract','implementation-report','qa-report','security-review','release-plan'},
 'architect': {'brd','prd','technical-plan','integration-contract','implementation-report','qa-report','security-review','release-plan'},
 'integration': {'prd','technical-plan','integration-contract','implementation-report','qa-report','release-plan'},
 'qa': {'brd','prd','technical-plan','integration-contract','implementation-report','qa-report','security-review','release-plan','ops-handover'},
 'security': {'brd','prd','technical-plan','integration-contract','implementation-report','qa-report','security-review','release-plan','ops-handover'},
 'risk': {'brd','prd','security-review','release-plan','ops-handover'},
 'audit': set(ALL_DOCS - FIN_DOCS),
 'release': {'prd','technical-plan','implementation-report','qa-report','security-review','release-plan','ops-handover'},
 'ops': {'prd','technical-plan','integration-contract','implementation-report','qa-report','security-review','release-plan','ops-handover'},
 'customer_care': {'brd','prd','release-plan','ops-handover'},
 'analytics': {'portfolio-epic','lean-business-case','brd','prd','release-plan','ops-handover','benefits-report'},
 'actuarial': {'brd','prd','integration-contract','qa-report'},
 'claims_sme': {'brd','prd','integration-contract','qa-report'},
 'vendor': {'prd','integration-contract','release-plan','ops-handover'},
 'admin': set(),
}
ROLE_DOCS = {role:frozenset(kinds) for role,kinds in ROLE_DOCS.items()}

CREATE_STREAM = frozenset({'lpm','vmo','value_owner','executive'})
CREATE_INITIATIVE = frozenset({'lpm','epic_owner','vmo','product_manager','program_manager'})
MANAGE_CONNECTORS = frozenset({'admin','lpm'})
VIEW_CONNECTORS = frozenset({'admin','lpm','vmo','program_manager','fde'})
PUBLISH_CONTRACT = frozenset({'lpm','vmo','program_manager'})
APPROVAL_OVERSIGHT = frozenset({'executive','lpm','vmo','rte','program_manager','audit','risk'})
AUDIT_VIEW = frozenset({'executive','lpm','vmo','program_manager','qa','security','risk','audit','release','ops','fde','admin'})
AUDIT_FULL = frozenset({'executive','lpm','vmo','program_manager','audit','risk','security'})
AGENT_DRAFT = frozenset({'fde','architect','product_owner','program_manager','qa','epic_owner'})
STAGE_GENERATORS = frozenset({'lpm','epic_owner','program_manager','rte','fde','product_owner','analytics'})

# Role-specific landing content. These are review/coordination views, not a claim
# that the demo implements full SAFe portfolio/ART/team operating processes.
ROLE_WORKSPACES = {
 'executive': ('Strategic sponsorship', 'Strategic outcomes, major investment exceptions and investment decisions.', ['portfolio','benefits'], 'insights'),
 'lpm': ('Lean Portfolio Management', 'Strategic epics, investment guardrails, prioritization and value realization.', ['portfolio','benefits'], 'insights'),
 'vmo': ('Portfolio operations', 'Portfolio flow, review cycles, dependencies and value-stream performance.', ['portfolio','benefits'], 'insights'),
 'finance': ('Financial stewardship', 'Business-case assumptions, investment decisions and benefit validation.', ['portfolio','benefits'], 'insights'),
 'epic_owner': ('Epic lifecycle', 'Investment hypotheses, lean business cases and progress to business outcomes.', ['portfolio','product','benefits'], 'initiatives'),
 'enterprise_architect': ('Enterprise architecture', 'Cross-stream technical standards, architecture decisions and enabler dependencies.', ['architecture','build'], 'contracts'),
 'business_owner': ('Business outcomes', 'Operational needs, business acceptance and value realization.', ['product','benefits'], 'approvals'),
 'value_owner': ('Value stream outcomes', 'Flow baselines, benefit targets, improvement work and value-stream decisions.', ['product','benefits'], 'approvals'),
 'product_manager': ('Product management', 'Roadmap alignment, product requirements and measurable capabilities.', ['product','architecture'], 'initiatives'),
 'product_owner': ('Product ownership', 'Business/product requirements, backlog intent and acceptance evidence.', ['product','quality'], 'contracts'),
 'rte': ('ART delivery coordination', 'Cross-team flow, stage commitments, impediments and integrated release readiness.', ['architecture','build','quality','release'], 'initiatives'),
 'program_manager': ('Integrated delivery controls', 'Delivery commitments, dependencies, risk, approvals and forecast accountability.', ['portfolio','architecture','release'], 'initiatives'),
 'team_coach': ('Team flow and coaching', 'Team impediments, execution progress and delivery practice improvements.', ['build','quality'], 'initiatives'),
 'fde': ('AI-enabled engineering', 'Technical plans, end-to-end builds, integrations and validated implementation evidence.', ['architecture','build','quality'], 'contracts'),
 'engineer': ('Engineering peer review', 'Implementation correctness, code quality, build evidence and maintainability.', ['build'], 'approvals'),
 'architect': ('Solution architecture', 'System design, interface contracts and nonfunctional quality.', ['architecture'], 'approvals'),
 'integration': ('Integration and data', 'Interface contracts, data quality, migrations and interoperability evidence.', ['architecture'], 'approvals'),
 'qa': ('Quality and validation', 'Independent tests, defect evidence, release quality and required sign-offs.', ['quality'], 'approvals'),
 'security': ('Security assurance', 'Security controls, threat assessment, findings and technical risk.', ['quality','release'], 'approvals'),
 'risk': ('Risk and compliance', 'Control exceptions, risk acceptance and evidence-based compliance review.', ['quality','release'], 'evidence'),
 'audit': ('Independent audit', 'Traceable approvals, immutable history and control assurance.', ['portfolio','quality','release'], 'evidence'),
 'release': ('Release control', 'Deployment readiness, change authorization and rollback planning.', ['release'], 'approvals'),
 'ops': ('Operational readiness', 'Runbooks, SLOs, observability, production handover and acceptance.', ['operations'], 'approvals'),
 'customer_care': ('Customer care handover', 'Customer-facing changes, support readiness and issues after release.', ['operations'], 'contracts'),
 'analytics': ('Benefits and measurement', 'Baseline evidence, outcome telemetry, validation and realized business value.', ['benefits'], 'insights'),
 'actuarial': ('Underwriting domain assurance', 'Rating, pricing and insurance-rule interpretation relevant to acceptance.', ['product','quality'], 'contracts'),
 'claims_sme': ('Claims domain assurance', 'Claims controls, business workflows and business-rule validation.', ['product','quality'], 'contracts'),
 'vendor': ('Supplier coordination', 'Integration obligations, external dependencies and release commitments.', ['architecture','release'], 'contracts'),
 'admin': ('Platform administration', 'Identity provisioning, connector configuration and platform activity controls.', [], 'integrations'),
}
ROLE_WORKSPACES = {k:dict(title=v[0],summary=v[1],stages=v[2],primary_page=v[3]) for k,v in ROLE_WORKSPACES.items()}
