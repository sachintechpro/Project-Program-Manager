"""SAFe-inspired, risk-based decisions. No universal approval authority is implied.

Every stakeholder has a relevant control action. 'Mandatory' applies only when
relevant to the initiative; audit and platform controls are NOT business approval.
"""
from .enterprise_data import table
from .catalog import INITIATIVE_TEMPLATES
BY_ROLE={x['role']:x for x in table('role_approval_controls')}

def applies(control,initiative,stream):
    code=control['control_code']; key=str(getattr(initiative,'key',''));name=str(getattr(initiative,'title','')).lower();stream_key=str(getattr(stream,'key',''))
    if code=='underwriting-sme':return stream_key in {'underwriting','servicing'} and any(x in name for x in ('compensation','endorsement','underwriting','policy'))
    if code=='claims-sme':return stream_key in {'claims','cyber'}
    if code=='customer-support':return True
    if code=='risk-review':return stream_key=='cyber' or any(x in name for x in ('payment','reserve','breach'))
    if code=='sponsor-strategy':return True
    if code=='supplier-dependency':return True
    if code=='integration-access':return True
    return True

def mandatory(control,initiative,stream):
    if not applies(control,initiative,stream):return False
    code=control['control_code']
    if code=='sponsor-strategy':return float(getattr(initiative,'budget',0))>=500_000
    if code=='risk-review':return str(getattr(stream,'key',''))=='cyber' or any(x in str(getattr(initiative,'title','')).lower() for x in ('payment','reserve'))
    if code=='supplier-dependency':return any(s in str(getattr(initiative,'title','')).lower() for s in ('surveyor','cyber breach'))
    return control['mandatory']=='true'

def controls_for(stage,initiative,stream):
    out=[]
    for row in table('role_approval_controls'):
        if row['stage']!=stage or not applies(row,initiative,stream):continue
        out.append({**row,'mandatory':mandatory(row,initiative,stream),'condition_met':True})
    return out
