"""Plain-English, role-scoped help. The same catalog supports tooltips and chat.

No company secrets, instance data, financial values, or prompt instructions are stored here.
"""
from functools import lru_cache
from pathlib import Path
import csv, json, re

ROOT = Path(__file__).resolve().parent.parent / 'seed' / 'help'

@lru_cache(maxsize=1)
def field_catalog():
    with (ROOT / 'fields.csv').open(encoding='utf-8', newline='') as f:
        return {r['key']:r for r in csv.DictReader(f)}

@lru_cache(maxsize=1)
def page_catalog():
    with (ROOT / 'pages.csv').open(encoding='utf-8', newline='') as f:
        return {r['page']:r for r in csv.DictReader(f)}

@lru_cache(maxsize=1)
def role_catalog():
    with (ROOT / 'roles.csv').open(encoding='utf-8', newline='') as f:
        return {r['role']:r for r in csv.DictReader(f)}

def canonical(field):
    return re.sub(r'[^a-z0-9_.]+','_',str(field or '').strip().lower().replace(' ','_')).strip('_')[:80]

def get_field(name):
    return field_catalog().get(canonical(name))

def help_payload(role):
    """Public explanation metadata, never business record values. Permission filter applies to sensitive help."""
    finance_roles={'executive','lpm','vmo','finance','epic_owner','value_owner','business_owner','product_manager','program_manager','analytics'}
    fields={k:dict(explanation=v['explanation'], example=v['example'], note=v['note'])
            for k,v in field_catalog().items() if v.get('scope')!='finance' or role in finance_roles}
    return {'pages':page_catalog(),'fields':fields,'role':role_catalog().get(role,{}),
            'mode':'guided','safety':'Guidance is read-only. Stage transitions still require human approval.'}
