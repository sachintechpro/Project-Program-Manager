"""Generate deterministic, readable fictional process evidence and review checklists."""
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'seed'/'maps'
SCENARIOS={
 'underwriting':{
 'source':['Broker submission events','Customer/account duplicate checks','Document receipt and validation logs','Underwriting referral audit trail','Rating engine rule evaluation','Policy binding and confirmation events'],
 'artifact':['ACORD submission and payroll schedules','Producer account ID and business name match','Location/class code document checklist','Appetite referral and underwriter decision','Rated quote and authority limits','Bound policy ID and confirmation notice'],
 'handoff':['Broker to underwriting intake','Intake to account clearance','Clearance to completeness team','Review team to assigned underwriter','Underwriter to rating specialist','Rating approval to policy administration'],
 'control':['Broker IAM and submission receipt','Entity matching and producer association','Mandatory class, location and payroll validation','Licensed underwriter decision and audit','Rating-version and delegated authority verification','Binding authority and policy-document reconciliation'],
 'exception':['Missing signed application','Ambiguous insured legal entity','Missing payroll class or loss runs','Outside delegated appetite','Referral or pricing override','Bind rejected or binder discrepancy'],
 'suggest':['Guided broker form','Reuse verified entity identity','Document completeness scoring','Explainable referrals with underwriting approval','Rule version comparison','Policy issuance event confirmation']},
 'claims':{
 'source':['FNOL submission timestamp','Policy/coverage lookup','Adjuster assignment queue','Loss evidence and vendor scheduling','Reserve approval ledger','Payment and settlement confirmation'],
 'artifact':['Loss notice and incident date','Effective coverage and exclusions','Assigned adjuster workload','Investigation/photos/expert reports','Reserve change and authority sign-off','Settlement letter and disbursement reference'],
 'handoff':['Claimant or broker to FNOL intake','FNOL to coverage analyst','Coverage to assignment team','Adjuster to field specialist','Investigation to reserve approver','Reserve authorization to payments'],
 'control':['FNOL receipt and data protection','Coverage determination by authorized handler','Assignment by license and expertise','Evidence chain of custody','Reserve authority and segregation of duties','Sanctions/payment destination checks'],
 'exception':['Loss time or peril unclear','Coverage discrepancy','No qualified adjuster available','Independent expert evidence delayed','Reserve threshold exceeded','Payment returned or disputed'],
 'suggest':['Structured FNOL capture','Coverage checklist visibility','Skill-based assignment queue','Digital evidence exchange','Threshold-driven reserve routing','Electronic settlement confirmation']},
 'cyber':{
 'source':['24x7 incident intake events','Policyholder identity verification','Cyber coverage response conditions','Incident severity triage','Panel vendor allocation service','Partner acknowledgement events'],
 'artifact':['Incident number and initial facts','Insured ID and caller authorization','Coverage triage record','Severity and containment decision','Approved incident response partner','Engagement acknowledgement'],
 'handoff':['Insured to incident desk','Desk to customer verification','Verification to cyber claims','Cyber claims to breach triage','Triage to panel coordinator','Coordinator to partner'],
 'control':['Preserve event times; no disclosure to unauthorized person','Confirm authority without impeding emergency response','Coverage determination remains human-controlled','Escalate active ransomware/extortion urgently','Approved panel, jurisdiction and conflict checks','Document secure communication and consent'],
 'exception':['Active containment emergency','Unverified caller','Policy limit or waiting-period dispute','Potential widespread or critical event','No available forensic partner','Partner fails acknowledgement SLA'],
 'suggest':['24-hour structured hotline intake','Low-friction identity evidence','Coverage summary for authorized handler','Priority classification with human override','Capacity-aware panel routing','Real-time partner acknowledgement alerts']},
 'servicing':{
 'source':['Portal endorsement submissions','Policy master validation logs','Underwriting referral worklist','Rating and billing adjustment feed','Policy/billing integration event queue','Document delivery acknowledgements'],
 'artifact':['Servicing request and effective date','Existing policy version and insured IDs','Referral rationale and decision','New premium and tax calculations','Policy and invoice reconciliation','Endorsement notice'],
 'handoff':['Insured or broker to servicing intake','Service desk to policy admin','Policy admin to underwriting','Underwriting to rating and billing','Rating to integration service','Integration to notification team'],
 'control':['Authenticate broker or insured','Check active policy and effective dates','Maintain underwriting approval for material coverage change','Validate pro-rata and tax rules','Transactional consistency and replay protection','Confirm correct recipient and document version'],
 'exception':['Out-of-date effective date','Policy is cancelled or nonrenewing','Insured risk change requires referral','Incorrect earned premium adjustment','Partial sync or duplicate event','Rejected delivery or wrong addressee'],
 'suggest':['Guided servicing intake','Validated policy snapshot','Rules-based referral routing','Preview pricing with human sign-off','Idempotent event reconciliation','Confirmation and self-service tracking']},
 'risk':{
 'source':['Underwriting inspection referrals','Risk engineer assignment notes','Field scheduler appointments','Mobile survey and images','Peer-review revision queue','Risk report publication records'],
 'artifact':['Risk location and inspection reason','Scope, hazard and location checklist','Visit booking and contact','Site photos, controls and observations','Peer-reviewed risk recommendations','Issued insurer/broker risk report'],
 'handoff':['Underwriter to risk operations','Risk operations to engineer','Engineer to insured scheduling','Scheduling to field engineer','Field engineer to peer reviewer','Peer reviewer to underwriting/broker'],
 'control':['Inspection priority based on insured exposure','Approved scope and required qualifications','Safe site access and appointment consent','Photo permissions and geographic data controls','Qualified independent technical peer review','Report publication authority and confidentiality'],
 'exception':['Missing property details','Insufficient engineer capacity','Unsafe or unavailable site','Hazard data or photos incomplete','Critical recommendation needs rework','Client disputes findings'],
 'suggest':['Reusable inspection trigger','Skill/capacity-aware scheduling','Self-service visit scheduling','Offline inspection capture','Evidence-complete peer-review packet','Track mitigation acceptance']},
 'distribution':{
 'source':['Broker portal request logs','Producer IAM entitlement events','Submission/policy status API responses','Document management access logs','Service exception routing queue','Broker notification delivery'],
 'artifact':['Broker inquiry and policy reference','Producer appointment and authorization','Verified submission/status snapshot','Authorized document metadata','Exception owner and resolution','Broker-facing response record'],
 'handoff':['Broker to distribution desk','Desk to IAM controls','IAM to underwriting systems','Status retrieval to document center','Service issue to exception team','Case resolution to broker'],
 'control':['Authenticate portal session','Producer appointment and account-level entitlement','Enforce least privilege across policy systems','Broker-specific document disclosure rights','Specialist authority for nonstandard replies','Log outbound recipient and response'],
 'exception':['Unclear insured account','Broker is not appointed','Stale policy/status feed','Restricted or missing document','Open underwriting referral','Invalid contact channel'],
 'suggest':['Contextual broker self-service','Automated entitlement check','Joined status view from authoritative sources','Document search with role filters','Exception triage by account ownership','Proactive broker status alerts']}}
ROLE_GUIDANCE={
 'business_owner':('Does the mapped end event deliver value to the commercial insured or broker?','Confirmed start/end boundaries, coverage authority and operational acceptance criteria'),
 'value_owner':('Does the flow include the real handoffs across business functions?','Current-state handoffs, constraints and a feasible future-state owner'),
 'actuarial':('Are underwriting authority, pricing and exposure controls preserved?','Class codes, appetite/pricing review and authorized referrals'),
 'claims_sme':('Are claims authority and evidence/settlement controls maintained?','Coverage, reserving, claims assignment and payment approvals'),
 'security':('Are cyber urgency, privacy and vendor access controls protected?','Incident response, consent, privacy and least-privilege evidence'),
 'finance':('Are servicing impacts on premium and billing reconciled?','Rate calculations, accounting handoffs and discrepancy controls'),
 'customer_care':('Can broker service resolve requests without improper disclosure?','Broker authentication, service response quality and exception escalation'),
 'product_manager':('Are the value hypothesis and improvement candidates coherent?','Outcome KPIs, feasible scope and product acceptance criteria'),
 'architect':('Are proposed integrations feasible without losing source authority?','Data lineage, API boundaries, system dependencies and exceptions'),
 'qa':('Are start/end measures and negative paths independently verifiable?','Testable process boundaries, exception paths and quality measures'),
 'ops':('Can the proposed process be operated and supported reliably?','Runbook ownership, queues, recovery paths and operational SLAs'),
 'analytics':('Could the baseline be measured from event timestamps consistently?','Metric definition, denominators, authoritative data and sample periods'),
}
rows=[];reviews=[];prompts=[]
for file in sorted(P.glob('*.json')):
 d=json.loads(file.read_text());key=file.stem
 domain=SCENARIOS[key]
 for state in ('current','future'):
  for index,step in enumerate(d[state]):
   score=int(d['monthly_volume'])
   rows.append(dict(stream_key=key,state=state,step_id=step['id'],step_name=step['name'],
       input_or_record=domain['artifact'][index],source_to_check=domain['source'][index],
       handoff=domain['handoff'][index],required_control=domain['control'][index],
       exception_to_test=domain['exception'][index],future_improvement=domain['suggest'][index],
       monthly_cases_modeled=score,reported_basis='Illustrative planning scenario — not a measured observation',
       evidence_collection='Collect case ID + created/started/completed timestamps for a defined 30-day sample'))
 for role in d['review_roles']:
  purpose,evidence=ROLE_GUIDANCE.get(role,('Is the proposed flow acceptable for your responsibilities?','Relevant operational evidence'))
  reviews.append(dict(stream_key=key,review_role=role,approval_question=purpose,evidence_required=evidence,
      response_options='approve | decline | request_information',mapped_stage='map_validation'))
 for idx,(topic,source,owner) in enumerate([
  ('Confirm what customers actually value',domain['artifact'][0],'business_owner'),
  ('Verify when the measurement clock starts and ends',domain['source'][0]+' + '+domain['source'][-1],'analytics'),
  ('Identify the highest wait and rework drivers',domain['source'][2]+' + '+domain['source'][3],'value_owner'),
  ('Validate a safe, measurable future state',domain['control'][3]+' + '+domain['control'][4],'architect'),
  ('Confirm support, QA and exception ownership',domain['exception'][-1]+' + '+domain['source'][-1],'qa'),
 ]):
  prompts.append(dict(stream_key=key,agenda_order=idx+1,meeting_question=topic,example_evidence_to_request=source,recommended_owner_role=owner,
  status='suggested_only_not_a_recorded_meeting'))

def write(filename,records):
  p=P/filename
  with p.open('w',newline='',encoding='utf-8') as f:
   w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
write('step_evidence.csv',rows)
write('role_review_guidance.csv',reviews)
write('workshop_questions.csv',prompts)
print(f'Wrote {len(rows)} linked step evidence rows, {len(reviews)} review guides and {len(prompts)} meeting questions')
