from pathlib import Path
p=Path(__file__).parents[1]/'app'/'static'/'app.js';s=p.read_text()
def swap(a,b,expected=1):
 global s
 n=s.count(a)
 if n!=expected:raise AssertionError(f'expect {expected} found {n} {a[:90]}')
 s=s.replace(a,b)
swap("['initiatives','≋','Initiative journeys'],", "['initiatives','≋','Initiative journeys'],['controls','✓','My role decisions'],['reference','▤','Scenario data'],")
swap("'raci','raid'].includes(S.page)", "'raci','raid','controls'].includes(S.page)")
swap("if(S.user.role==='admin'&&['streams','initiatives','contracts','raci','raid'].includes(p))", "if(S.user.role==='admin'&&['streams','initiatives','contracts','raci','raid','reference'].includes(p))")
swap("'guide':'Guide','raci':'RACI matrix'", "'guide':'Guide','controls':'My role decisions','reference':'Scenario examples','raci':'RACI matrix'")
swap("const prim=work.primary_page==='approvals'&&!perm.reviewer&&!perm.see_all_approvals?'contracts':work.primary_page;", "const prim=work.primary_page==='approvals'&&!perm.reviewer&&!perm.see_all_approvals?'controls':work.primary_page;")
swap("const [sum,streams,inits,audit,connections]=await Promise.all([", "const [sum,streams,inits,audit,connections]=await Promise.all([")
# App guide and navigation guidance
swap("<b>Stage exit requirement:</b> Each required Markdown contract must be approved by its assigned reviewer. The system automatically advances when all required approvals are recorded.","<b>Stage exit requirement:</b> Required contracts and applicable mandatory role-control decisions must both be approved. Advisory confirmations are visible but do not block delivery.")
swap("<button class=\"btn sm\" data-register-page=\"raid\" data-scope-init=\"${i.id}\">RAID log ↗</button></div>","<button class=\"btn sm\" data-register-page=\"raid\" data-scope-init=\"${i.id}\">RAID log ↗</button><button class=\"btn sm\" data-reference-init=\"${i.id}\">Example data ↗</button><button class=\"btn sm\" data-page=\"controls\">My role decisions ↗</button></div>")
swap("$('view').innerHTML=html;}\nasync function contractPage", "$('view').innerHTML=html;await showJourneyControls(i.id);}\nasync function contractPage")
swap("case 'approvals':return approvalsPage();", "case 'approvals':return approvalsPage();case 'controls':return controlsPage();case 'reference':return referencePage();")
swap("if(t.dataset.art)return run(()=>route('contract',Number(t.dataset.art)));", "if(t.dataset.art)return run(()=>route('contract',Number(t.dataset.art)));\nif(t.dataset.referenceInit){S.referenceInitiative=Number(t.dataset.referenceInit);return run(()=>route('reference'))}\nif(t.dataset.controlDecision)return run(()=>saveControlDecision(t));")
swap("const safe=['dashboard','approvals','insights'", "const safe=['dashboard','approvals','controls','reference','insights'")
# Add brief context to role profile, and assigned review count.
swap("['Active initiatives',sum.active,'Enterprise context; open only authorized evidence']];", "['Active initiatives',sum.active,'Enterprise context; open only authorized evidence']];")
swap("<button class=\"btn primary\" data-page=\"${H(prim)}\">Open ${H(prim.replaceAll('_',' '))} ↗</button>","<button class=\"btn primary\" data-page=\"${H(prim)}\">Open ${H(prim.replaceAll('_',' '))} ↗</button><button class=\"btn\" data-page=\"controls\">My role decisions ↗</button>")
# Add after approvals screen listing? Put a banner button before contract queue by altering title once.
swap("'Each stage advances only after its required contracts receive human approvals. Changing a contract", "'Assigned contract approvals and separate role-specific readiness controls. Open My role decisions to review the controls relevant to your job. Changing a contract")
# Future link drop-down in reference screen.
js='''
const schemaLabels={business_steps:'Workflow steps',requirements:'Requirements',business_rules:'Insurance decision rules',data_fields:'Data and validation',interfaces:'Interfaces',test_cases:'Test cases',risks:'Risks',dependencies:'Dependencies',stakeholder_assignments:'Stakeholder roles',metrics:'KPI baselines',cost_estimates:'Cost estimates',release_controls:'Release controls',handover_tasks:'Handover tasks'};
function decisionPanel(c,iid,stage){
 const approved=c.decision==='approved'&&c.evidence_current;
 const isMine=c.assigned_to_me===true;
 const verb=c.decision_action==='approve'?'Approve':c.decision_action==='attest'?'Attest':c.decision_action==='acknowledge'?'Acknowledge':'Confirm';
 const fieldid='control-'+iid+'-'+c.control_code;
 return `<div class="card" style="margin-top:12px"><div class="spaced"><h3 class="pane-title">${H(c.decision_title)}</h3>${pill(approved?'approved':c.decision==='changes_requested'?'rejected':'draft')}</div><p class="muted">${H(roleName(c.role))} · ${c.mandatory?'Required to advance the stage':'Advisory / oversight'} · ${H(c.condition)}</p><div class="small"><b>Required evidence:</b> ${H(c.evidence_needed)}</div>${c.reviewed_by?`<div class="small muted">Last reviewed: ${H(c.reviewed_by)} · ${when(c.reviewed_at)}${c.evidence_current?'':' · old evidence version'}</div>`:''}${isMine?`<div class="field-grid" style="margin-top:10px"><label class="field">Evidence reference<input id="${fieldid}-ref" placeholder="ART-12, QA-04 or documented review evidence" value="${H(c.evidence_ref||'')}"></label><label class="field span2">Decision explanation<textarea id="${fieldid}-comment" placeholder="Explain what was verified or why work must be revised">${H(c.comment||'')}</textarea></label></div><div class="form-actions"><button class="btn primary sm" data-control-decision="approved" data-control-code="${H(c.control_code)}" data-control-i="${iid}" data-control-stage="${H(stage)}" data-control-digest="${H(c.input_digest)}">${verb} ${c.decision_action==='attest'?'evidence':'readiness'}</button><button class="btn sm" data-control-decision="changes_requested" data-control-code="${H(c.control_code)}" data-control-i="${iid}" data-control-stage="${H(stage)}" data-control-digest="${H(c.input_digest)}">Request changes</button></div>`:`<div class="small muted">Read-only. This decision belongs to ${H(roleName(c.role))}.</div>`}</div>`;
}
async function saveControlDecision(t){
 const iid=Number(t.dataset.controlI),code=t.dataset.controlCode,fieldid='control-'+iid+'-'+code;
 const c=$(`${fieldid}-comment`)?.value||'',ref=$(`${fieldid}-ref`)?.value||'';
 const res=await api(`/api/initiatives/${iid}/control-reviews/${code}`,{method:'POST',body:{decision:t.dataset.controlDecision,comment:c,evidence_ref:ref,expected_stage:t.dataset.controlStage,input_digest:t.dataset.controlDigest}});
 toast(res.advanced?`Approved; initiative advanced to ${stageLabels[res.next_stage]}`:'Your role decision was recorded and linked to this evidence version');
 if(S.page==='initiative')await route('initiative',iid);else await route('controls');
}
async function showJourneyControls(id){
 let response=await api('/api/initiatives/'+id+'/control-reviews');
 if(!response.controls.length)return;
 $('view').insertAdjacentHTML('beforeend',`<div class="grid-heading"><h2>Role-controlled decisions</h2><span class="tag">${response.outstanding} required decision(s) awaiting approval</span></div><p class="muted">These decisions are distinct from contract approval. They apply only within each stakeholder's area of authority and are tied to the current evidence version.</p><div class="grid cols2">${response.controls.map(c=>decisionPanel(c,id,response.stage)).join('')}</div>`);
}
async function controlsPage(){
 const rows=await api('/api/control-reviews');
 const pending=rows.filter(x=>x.control.decision!=='approved' || !x.control.evidence_current);
 const controls=rows.filter(x=>x.control.decision==='approved'&&x.control.evidence_current);
 const describe='Every stakeholder has a role-specific control action. Only designated mandatory decisions block stage advancement. A test, compliance, operations or administrative confirmation does not grant portfolio funding authority.';
 $('view').innerHTML=title('GOVERNANCE / HUMAN CONTROL','My role decisions.',describe)+`<div class="grid cols3"><div class="card"><div class="stat-label">Currently assigned</div><div class="stat-num">${rows.length}</div></div><div class="card"><div class="stat-label">Pending / needs refresh</div><div class="stat-num">${pending.length}</div></div><div class="card"><div class="stat-label">Confirmed against current evidence</div><div class="stat-num">${controls.length}</div></div></div>`;
 if(!rows.length){$('view').insertAdjacentHTML('beforeend',empty('No initiatives are presently at your role\'s review stage. Your authority remains available when an initiative reaches the relevant gate.'));return}
 $('view').insertAdjacentHTML('beforeend',`<div class="grid-heading"><h2>Assigned decisions</h2></div><div class="grid cols2">${rows.map(x=>`<div><div class="eyebrow">${H(stageLabels[x.stage])} · ${H(x.initiative_title)}</div>${decisionPanel({...x.control,assigned_to_me:true},x.initiative_id,x.stage)}${S.user.role==='admin'?'':`<button class="btn sm" data-init="${x.initiative_id}">Open initiative ↗</button>`}</div>`).join('')}</div>`);
}
async function referencePage(){
 const all=await api('/api/initiatives');
 const iid=S.referenceInitiative||all[0]?.id;
 if(!iid){$('view').innerHTML=empty('No initiative has been created.');return}
 const result=await api('/api/initiatives/'+iid+'/reference');
 const rows=Object.entries(result.tables||{});
 $('view').innerHTML=title('CONTEXT / REFERENCE DATA','Commercial & specialty reference records.','Small schema-controlled CSV tables provide consistent examples for the selected initiative. They are planning inputs, never claims of completed production work.',`<button class="btn" data-init="${iid}">Open initiative ↗</button>`)+`<div class="filter-row"><label class="muted">Initiative</label><select id="reference-initiative">${all.map(i=>`<option value="${i.id}" ${i.id===iid?'selected':''}>${H(i.title)}</option>`).join('')}</select><span class="tag">${rows.reduce((n,[k,r])=>n+r.length,0)} linked records</span></div>`+(result.template_key?`<div class="callout"><b>Example source:</b> ${H(result.template_key)}. Records come from <code>seed/data/</code> and use initiative-specific IDs, definitions and explicit units. Original requirements, test cases and review outcomes remain separately traceable.</div>`:note(H(result.message)))+rows.map(([name,vals])=>{const cols=Object.keys(vals[0]||{});return `<div class="grid-heading"><h2>${H(schemaLabels[name]||name)}</h2><span class="tag">${vals.length} records · ${H(name+'.csv')}</span></div><div class="table-wrap"><table><thead><tr>${cols.map(c=>`<th>${H(c.replaceAll('_',' '))}</th>`).join('')}</tr></thead><tbody>${vals.map(v=>`<tr>${cols.map(c=>`<td>${H(v[c])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`}).join('')+`<div class="callout">Use these examples to complete BRD/PRD and acceptance evidence. Every generated contract records the source example. The underlying CSVs remain a readable historical reference; the approved Markdown and audit ledger are authoritative for actual initiative decisions.</div>`;
}
'''
# Insert before render() so closures are defined before event handlers.
swap('async function render(){',js+'\nasync function render(){')
swap("if(t.dataset.art)return run(()=>route('contract',Number(t.dataset.art)));", "if(t.dataset.art)return run(()=>route('contract',Number(t.dataset.art)));") if False else None
# add switch for new reference chooser
swap("if(t.id==='initiative-stream-filter'){S.stream=Number(t.value);run(()=>render())}","if(t.id==='initiative-stream-filter'){S.stream=Number(t.value);run(()=>render())}\nif(t.id==='reference-initiative'){S.referenceInitiative=Number(t.value);run(()=>render())}")
# ensure form template value is included: select is outside form -> currently not posted, fix it.
swap("const r=await api('/api/initiatives',{method:'POST',body:data});toast('Initiative opened at portfolio authorization')", "data.template=$('init-template')?.value||'';const r=await api('/api/initiatives',{method:'POST',body:data});toast('Initiative opened at portfolio authorization')")
# when example selected, existing fillFields writes same scope; schema uses source key and scenario pack.
swap("The new initiative begins at Portfolio authorization.","The new initiative begins at Portfolio authorization. Selecting a sample links requirements, tests, integrations, and metric definitions to its generated documents.")
swap("'Review with the assigned human','Open a contract, switch to the reviewer role, inspect content and approve or reject.","'Review with the assigned human','Open a contract, switch to the reviewer role, inspect content and approve or reject; then complete required role decisions.")
p.write_text(s);print('patched app UI')
