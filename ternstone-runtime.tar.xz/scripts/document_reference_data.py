from pathlib import Path
import json,csv
root=Path(__file__).resolve().parents[1]
data=root/'seed'/'data'
schema=json.loads((data/'schema.json').read_text(encoding='utf-8'))
controls=list(csv.DictReader((data/'role_approval_controls.csv').open(newline='',encoding='utf-8')))
rows=[]
rows.append('# Role-specific decisions and human controls\n')
rows.append('Each stakeholder receives an action appropriate to their professional responsibility. An action is not always final approval: the roles with **Confirm** or **Attest** only verify their own evidence; they do not authorize funding or product release. The assigned user must sign in with that role. The system captures the decision, comment, artifact digest and time. Required controls block stage advancement. Advisory controls do not.\n')
rows.append('| Stage | Stakeholder role | Decision / confirmation | Default required? | What they must examine |\n|---|---|---|---|---|')
for r in controls:
    rows.append(f"| {r['stage'].title()} | {r['role'].replace('_',' ').title()} | {r['decision_title']} ({r['decision_action']}) | {'Yes' if r['mandatory']=='true' else 'Conditional / no'} | {r['evidence_needed'].replace('|','/')} |")
rows+=['\n**Conditional controls:** Executive sponsorship is required above the established portfolio threshold; underwriting and claims SMEs are required for applicable lines of business; the compliance/Risk review is mandatory for selected sensitive changes; vendor review is mandatory for selected supplier-dependent work. System administration is a provisioning attestation, **never** business-data approval.\n','**Approval safety:** Stage-specific documents must exist before confirmation. A new input digest invalidates earlier confirmations. Only the assigned role may act. A rejection returns work for rework and is preserved in the audit trail.\n','**SAFe scope:** These additional review controls are a fictional organization\'s policy model, not universal mandatory SAFe roles or canonical SAFe events. Existing ART/PI and LPM governance remain separate.']
(root/'docs'/'ROLE_DECISION_CONTROLS.md').write_text('\n'.join(rows)+'\n',encoding='utf-8')
text=['# Reference CSV dictionary and data lineage\n','Each CSV has exactly one topic and primary identifier. All references use stable IDs instead of copying repeated amounts into every file. Use the schema descriptions below to understand required values. All financial figures, volumes and outcomes are modeled; they must not be reported as actual operational outcomes.\n']
for name,s in schema.items():
    if name.startswith('_'):continue
    nr=sum(1 for _ in csv.DictReader((data/(name+'.csv')).open(newline='',encoding='utf-8')))
    text.extend([f"## `{name}.csv` — {nr} rows", s['purpose']+'\n', '| Column | Type | Interpretation |', '|---|---|---|'])
    for k,typ in s['fields'].items():
        helptext=s.get('field_help',{}).get(k, '')
        text.append(f'| `{k}` | `{typ}` | {helptext} |')
    text+=['']
text+=['\n## How the joins work\n','`value_streams.stream_id` → `initiatives.stream_id` → `*.initiative_key` → individual record IDs. `test_cases.requirement_id` points to `requirements.requirement_id`. Cost lines in `cost_estimates.csv` total to `initiatives.estimated_cost_usd` by initiative. This budget is a modeled plan, not actual spending.\n','## Rules to prevent misunderstanding\n','- Use one unit per metric and include the period on operating volumes; never compare hours and days without conversion.\n- Do not mark unexecuted example tests as Pass or business benefits as Realized.\n- Treat financial assumptions as restricted to authorized portfolio/financial roles.\n- Make source records read-only after portfolio approval; implement later revisions through authorized change control.\n- Run `python scripts/validate_reference_csv.py`; it detects missing headers and required fields, duplicate identifiers, invalid roles, unresolved references, nonnumeric amounts, missing positive/negative tests, incorrect stage names, and cost/budget mismatches.\n']
(root/'docs'/'REFERENCE_DATA_DICTIONARY.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
print('Wrote 29 role controls and a 16-table plain-English field dictionary')
