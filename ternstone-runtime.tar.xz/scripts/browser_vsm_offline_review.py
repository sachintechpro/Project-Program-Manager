"""Exercise all six maps and human decision UI in Chromium without network access."""
import json,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
from app.value_mapping import measures,recommendations,reference_evidence

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'test-screens';OUT.mkdir(exist_ok=True)
JS=(BASE/'app/static/map_ui.js').read_text()
CSS=(BASE/'app/static/style.css').read_text()
all_keys=['underwriting','claims','cyber','servicing','risk','distribution']
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width in (1440,390):
        page=browser.new_page(viewport={'width':width,'height':850},device_scale_factor=1)
        errs=[]
        page.on('pageerror',lambda e:errs.append(str(e)))
        page.set_content('<style>'+CSS+'</style><div id="view"></div>')
        page.add_script_tag(content=JS)
        for key in all_keys:
            obj=json.loads((BASE/'seed/maps'/f'{key}.json').read_text())
            data={
                'value_stream':{'name':key.title(),'lob':'Commercial & Specialty','id':1,'baseline':12,'target':7},
                'version':1,'map':obj,'current':measures(obj['current']),'future':measures(obj['future']),
                'recommendations':recommendations(obj),'meetings':[], 'reviews':[],
                'reference_evidence':reference_evidence(key),'review_status':'in_review',
                'review_roles':obj['review_roles'],'approved_for_mapping':False,
                'can_edit':True,'can_meet':True,'can_review':False,'current_role':'program_manager',
            }
            page.evaluate('''async ({data,sid})=>{
              window.__vsmData=data;
              window.__calls=[];
              window.__ctx={S:{page:'value_map',mapStream:sid,user:{role:'program_manager',permissions:{create_initiative:true}}},
                $:(id)=>document.getElementById(id),
                H:(v)=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'),
                roleName:(id)=>String(id).replaceAll('_',' '),
                title:(k,title,subtitle,buttons)=>`<div class="vsm-test-heading"><h1>${title}</h1><p>${subtitle}</p>${buttons}</div>`,
                api:async (url,options)=>{if(!options)return JSON.parse(JSON.stringify(window.__vsmData));window.__calls.push({url,options});return JSON.parse(JSON.stringify(window.__vsmData));},
                toast:(message)=>window.__toast=message,route:async ()=>{},run:async()=>{},financeView:()=>true};
              await window.TernstoneMap.render(window.__ctx);
            }''',{'data':data,'sid':all_keys.index(key)+1})
            assert page.locator('.vsm-hero').count()==1,(key,width,'hero')
            assert page.locator('[data-vsm-form="value"]').count()==1,(key,width,'define form')
            for stage in ('workshop','current','improve','future','validate'):
                page.locator(f'[data-vsm-tab="{stage}"]').click()
                if stage in ('current','future'):
                    assert page.locator('.vsm-bar-row').count()==6,(key,width,stage,'process rows')
                    assert page.locator('.vsm-flow-step').count()==6,(key,width,stage,'flow nodes')
                    assert page.locator('.vsm-hint').count()>=6,(key,width,stage,'tooltips')
                    page.locator('[data-vsm-inspect]').first.click()
                    assert page.locator('#vsm-inspect-panel').is_visible(),(key,width,stage,'inspector')
                    assert 'Required control' in page.locator('#vsm-inspect-panel').inner_text()
                if stage=='improve':
                    assert page.locator('.vsm-pair').count()==6,(key,width,'compare pairs')
                if stage=='workshop':assert page.locator('.vsm-guidance details').count()==5,(key,width,'questions')
                if stage=='validate':assert 'Approve, decline, or ask for evidence' in page.locator('#view').inner_text()
            assert not errs,(key,width,errs)
            print(f'OK {key} {width}px — all 6 mapping tabs, six flow steps, evidence tooltips and charts')
            # Verify the distinct role-control UI on a reviewer persona.
            if key=='underwriting' and width==1440:
                data['current_role']='qa';data['can_review']=True;data['can_edit']=False
                data['meetings']=[{'title':'Real workshop','meeting_date':'2026-11-17','attended_roles':['qa']}]
                page.evaluate('''async data=>{window.__vsmData=data;window.__ctx.S.user.role='qa';await window.TernstoneMap.render(window.__ctx);}''',data)
                page.locator('[data-vsm-tab="validate"]').click()
                assert page.locator('[name="decision"][value="approve"]').count()==1
                assert page.locator('[name="decision"][value="decline"]').count()==1
                assert page.locator('[name="decision"][value="request_information"]').count()==1
                page.locator('[data-vsm-form="review"] textarea[name="comment"]').fill('Please provide the source system baseline timestamps and exception paths.')
                page.locator('[name="decision"][value="request_information"]').click()
                calls=page.evaluate('window.__calls')
                assert calls[-1]['options']['body']['decision']=='request_information',calls[-1]

                print('OK approval buttons / decision payload for reviewer role')
        page.close()
    browser.close()
print('PASS all six maps, desktop and mobile, no JavaScript errors')
