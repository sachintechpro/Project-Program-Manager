from pathlib import Path
p=Path(__file__).parents[1]/'app'/'static'/'app.js';s=p.read_text()
def swap(a,b):
 global s
 if s.count(a)!=1:raise RuntimeError(f'expected one occurrence of {a[:55]!r}, found {s.count(a)}')
 s=s.replace(a,b)
swap("if(t.dataset.referenceInit){S.referenceInitiative=Number(t.dataset.referenceInit);return run(()=>route('reference'))}","if(t.dataset.referenceInit){S.referenceInitiative=Number(t.dataset.referenceInit);return run(()=>route('reference'))}\nif(t.dataset.referenceExport)return window.location.assign(`/api/initiatives/${t.dataset.referenceExport}/reference-export`);\nif(t.dataset.rowEdit)return run(()=>referenceEditor(t.dataset.rowTable,Number(t.dataset.rowEdit)));")
swap("const result=await api('/api/initiatives/'+iid+'/reference');", "const result=await api('/api/initiatives/'+iid+'/reference');S.referenceData=result;S.referenceInitiative=iid;")
swap("<span class=\"tag\">${rows.reduce((n,[k,r])=>n+r.length,0)} linked records</span></div>","<span class=\"tag\">${rows.reduce((n,[k,r])=>n+r.length,0)} linked records</span><button class=\"btn sm\" data-reference-export=\"${iid}\">Export example CSVs ↗</button></div><div id=\"reference-edit-panel\" class=\"form-panel hidden\"></div>")
swap("${cols.map(c=>`<th>${H(c.replaceAll('_',' '))}</th>`).join('')}</tr>","${cols.filter(c=>!c.startsWith('__')).map(c=>`<th>${H(c.replaceAll('_',' '))}</th>`).join('')}<th>Action</th></tr>")
swap("${vals.map(v=>`<tr>${cols.map(c=>`<td>${H(v[c])}</td>`).join('')}</tr>`).join('')}","${vals.map(v=>`<tr>${cols.filter(c=>!c.startsWith('__')).map(c=>`<td>${H(v[c])}</td>`).join('')}<td>${v.__can_edit?`<button class=\"btn sm\" data-row-edit=\"${v.__record_id}\" data-row-table=\"${H(name)}\">Edit ↗</button>`:'Read only'}</td></tr>`).join('')}")
# insert function before referencePage
swap('async function referencePage(){', '''function referenceEditor(table,id){
 const result=S.referenceData;const row=(result.tables[table]||[]).find(x=>x.__record_id===id);
 if(!row?.__can_edit)throw Error('Only the original author may revise a new initiative\'s reference data before portfolio authorization');
 const schema=result.schemas[table];if(!schema)throw Error('Missing table schema');
 const inputs=Object.entries(schema.fields).map(([name,type])=>{
   const v=row[name]||'';const readonly=(name===schema.key || name==='initiative_key');
   if(type.startsWith('enum:'))return `<label class="field">${H(name.replaceAll('_',' '))}<select name="${H(name)}">${type.slice(5).split('|').map(op=>`<option value="${H(op)}" ${op===v?'selected':''}>${H(op)}</option>`).join('')}</select></label>`;
   if(type==='boolean')return `<label class="field">${H(name.replaceAll('_',' '))}<select name="${H(name)}"><option value="true" ${v==='true'?'selected':''}>Yes</option><option value="false" ${v==='false'?'selected':''}>No</option></select></label>`;
   if(type==='role')return `<label class="field">${H(name.replaceAll('_',' '))}<select name="${H(name)}">${S.catalog.roles.map(r=>`<option value="${H(r.id)}" ${r.id===v?'selected':''}>${H(r.name)}</option>`).join('')}</select></label>`;
   return `<label class="field ${v.length>90?'span2':''}">${H(name.replaceAll('_',' '))}<input name="${H(name)}" value="${H(v)}" ${readonly?'readonly':''} ${type==='integer'||type==='decimal'?`type="number" min="0" step="${type==='integer'?'1':'any'}"`:''}></label>`;
 }).join('');
 const box=$('reference-edit-panel');box.innerHTML=`<h3>Revise ${H(table)} · row v${row.__version}</h3><p class="muted">Only the original author can edit intake examples. Each change is versioned, logged and used when generating future stage contracts.</p><form data-form="reference-row" data-reference-row="${id}" data-reference-version="${row.__version}"><div class="field-grid">${inputs}</div><div class="form-actions"><button class="btn primary" type="submit">Save audited row revision</button></div></form>`;
 box.classList.remove('hidden');box.scrollIntoView({behavior:'smooth',block:'nearest'});
}
async function referencePage(){''')
swap("if(f.dataset.form==='register'){", """if(f.dataset.form==='reference-row'){
 const id=Number(f.dataset.referenceRow);
 const r=await api('/api/scenario-records/'+id,{method:'PUT',body:{fields:formObject(f),expected_version:Number(f.dataset.referenceVersion)}});
 toast('Reference data saved as version '+r.version);await route('reference');
}
else if(f.dataset.form==='register'){""")
p.write_text(s);print('patched reference UI')
