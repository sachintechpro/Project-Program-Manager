"""Export small readable CSVs from authoritative map template JSON; verify consistency."""
from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parents[1]
FOLDER=ROOT/'seed/maps'
KEYS=('underwriting','claims','cyber','servicing','risk','distribution')

def write(name,fields,rows):
    p=FOLDER/name
    with p.open('w',newline='',encoding='utf-8') as fp:
        out=csv.DictWriter(fp,fieldnames=fields);out.writeheader();out.writerows(rows)
    assert len({tuple(r.get(k) for k in fields[:2]) for r in rows})>0
    print(name,len(rows))

values=[];steps=[];stakeholders=[];agendas=[];improvements=[]
for key in KEYS:
    d=json.loads((FOLDER/(key+'.json')).read_text())
    values.append({'stream_key':key,'customer':d['value']['customer'],'value_statement':d['value']['statement'],
     'trigger':d['value']['trigger'],'accepted_outcome':d['value']['outcome'],'boundary':d['value']['boundary'],
     'out_of_scope':d['value']['exclusions'],'human_controls':d['value']['guardrails'],
     'modeled_monthly_cases':d['monthly_volume'],'measurement_unit':d['unit'],'reference_status':'illustrative'})
    for state in ('current','future'):
        for n,s in enumerate(d[state],start=1):
            steps.append({'stream_key':key,'state':state,'step_id':s['id'],'step_order':n,'step_name':s['name'],
            'owner_role':s['owner_role'],'system':s['system'],'active_clock_hours':s['touch_hours'],
            'waiting_clock_hours':s['wait_hours'],'modeled_first_pass_pct':s['first_pass_pct'],
            'observed_constraint_example':s.get('problem',''),'proposed_change':s.get('improvement','')})
    for role in d['invited_roles']:
        stakeholders.append({'stream_key':key,'role_id':role,'invited_to_mapping':'yes','map_review_required':'yes' if role in d['review_roles'] else 'no'})
    for n,question in enumerate(d['agenda'],start=1):
        agendas.append({'stream_key':key,'agenda_order':n,'question':question,'actual_meeting_held':'no'})
    for n,idea in enumerate(d['candidate_initiatives'],start=1):
        improvements.append({'stream_key':key,'priority_for_discussion':n,'idea':idea,'status':'hypothesis_needs_validation'})
write('value_definitions.csv',list(values[0]),values)
write('process_steps.csv',list(steps[0]),steps)
write('stakeholder_participation.csv',list(stakeholders[0]),stakeholders)
write('discovery_agenda.csv',list(agendas[0]),agendas)
write('improvement_candidates.csv',list(improvements[0]),improvements)
# Validation: these CSVs are derived exports, never the authoritative editable records.
assert len(steps)==72
for key in KEYS:
    assert sum(r['stream_key']==key and r['state']=='current' for r in steps)==6
    assert sum(r['stream_key']==key and r['state']=='future' for r in steps)==6
    assert len({r['role_id'] for r in stakeholders if r['stream_key']==key})==sum(r['stream_key']==key for r in stakeholders)
print('Cross-file keys and process-step counts verified')
