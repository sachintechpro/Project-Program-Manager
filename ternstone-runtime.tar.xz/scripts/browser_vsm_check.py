from playwright.sync_api import sync_playwright
from pathlib import Path
p=Path('/mnt/data/valueops-vsm')
with sync_playwright() as x:
    b=x.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for screen,width in [('desktop',1440),('mobile',390)]:
        page=b.new_page(viewport={'width':width,'height':850},device_scale_factor=1)
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto('http://127.0.0.1:8767/',wait_until='domcontentloaded')
        page.locator('[data-role="program_manager"]').first.click()
        page.wait_for_selector('#shell:not(.hidden)',timeout=20000)
        if screen=='mobile':
            page.locator('#menu-toggle').click()
        page.get_by_role('button',name='Value streams',exact=False).first.click()
        page.wait_for_selector('[data-map-stream]',timeout=15000)
        print('bubble count',page.locator('[data-map-stream]').count(),screen)
        page.locator('[data-map-stream]').first.click()
        page.wait_for_selector('.vsm-tabs',timeout=15000)
        print('view title',page.locator('#page-title').inner_text(),screen)
        page.screenshot(path=str(p/f'vsm_{screen}_define.png'),full_page=True)
        for stage in ('workshop','current','improve','future','validate'):
            page.locator(f'[data-vsm-tab="{stage}"]').click()
            page.wait_for_timeout(200)
            if stage=='current':page.screenshot(path=str(p/f'vsm_{screen}_flow.png'),full_page=True)
            if stage=='improve':page.screenshot(path=str(p/f'vsm_{screen}_improve.png'),full_page=True)
        page.locator('[data-vsm-tab="workshop"]').click()
        page.locator('[data-vsm-new-meeting]').click()
        assert page.locator('[data-vsm-form="meeting"]').is_visible()
        assert page.locator('input[name="title"]').is_visible()
        print('JS errors',errors)
        assert not errors
        page.close()
    b.close()
