"""Real FastAPI TestClient + offline Chromium; avoids blocked loopback navigation."""
import sys,os,re
from pathlib import Path
os.environ['DEMO_MODE']='true';os.environ['DATABASE_URL']='sqlite:////mnt/data/valueops-advanced/browser_new.sqlite';os.environ['SECRET_KEY']='browser-test-secret'
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from app.main import app
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'test-screens';out.mkdir(exist_ok=True)
html=(root/'app/static/index.html').read_text().replace('<script src="/assets/app.js"></script>','').replace('<link rel="stylesheet" href="/assets/style.css">','')
source=(root/'app/static/app.js').read_text()
css=re.sub(r'@import[^;]+;','',(root/'app/static/style.css').read_text())
with TestClient(app) as c, sync_playwright() as p:
 def bridge(path,method='GET',headers=None,body=None):
    h={k:v for k,v in (headers or {}).items() if k.lower() not in ('cookie','host')}
    res=c.request(method,path,headers=h,content=body)
    return {'status':res.status_code,'text':res.text,'content_type':res.headers.get('content-type','application/json')}
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1440,'height':990});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=12000)
 page.add_style_tag(content=css)
 page.expose_function('__requestBridge',bridge)
 page.evaluate('''()=>{
     window.EventSource=class {constructor(){} close(){}};
     window.fetch=async(url,opt={})=>{
       const result=await window.__requestBridge(String(url),opt.method||'GET',opt.headers||{},opt.body||null);
       return new Response(result.text,{status:result.status,headers:{'content-type':result.content_type}});
     };
 }''')
 page.add_script_tag(content=source);page.wait_for_timeout(300)
 page.locator('button[data-role="program_manager"]').first.click();page.wait_for_timeout(500)
 for label,target in [('My role decisions','controls'),('Scenario data','reference'),('Initiative journeys','initiatives')]:
    page.locator('button[data-page="'+target+'"]').first.click();page.wait_for_timeout(300)
    print('PAGE',label,'=',page.locator('main h1').first.inner_text())
    page.screenshot(path=str(out/(target+'.png')))
 page.get_by_role('button',name='+ New initiative').first.click();page.wait_for_timeout(130)
 page.locator('#init-template').select_option('wc-submission');page.wait_for_timeout(500)
 form=page.locator('form[data-form="initiative"]')
 assert 'compensation' in form.locator('input[name="title"]').input_value().lower()
 form.locator('input[name="title"]').fill('Workers Compensation broker submission readiness pilot')
 form.locator('button[type="submit"]').first.click();page.wait_for_timeout(700)
 main=page.locator('main').inner_text()
 assert 'broker submission readiness pilot' in main.lower(),main[:900]
 page.screenshot(path=str(out/'new_initiative.png'))
 page.locator('button[data-reference-init]').first.click();page.wait_for_timeout(540)
 assert 'Requirements' in page.locator('main').inner_text()
 assert page.locator('button[data-row-edit]').count()>0
 page.locator('button[data-row-edit]').first.click();page.wait_for_timeout(100)
 assert page.locator('form[data-form="reference-row"]').count()==1
 page.screenshot(path=str(out/'editable_csv_row.png'))
 page.locator('button[data-page="controls"]').first.click();page.wait_for_timeout(350)
 assert 'My role decisions' in page.locator('main').inner_text()
 page.locator('#persona-switch').select_option('qa');page.wait_for_timeout(500)
 page.locator('button[data-page="reference"]').first.click();page.wait_for_timeout(420)
 assert page.locator('button[data-row-edit]').count()==0
 page.screenshot(path=str(out/'qa_readonly.png'))
 page.locator('#persona-switch').select_option('vmo');page.wait_for_timeout(370)
 page.locator('button[data-page="controls"]').first.click();page.wait_for_timeout(450)
 assert page.locator('button[data-control-decision="approved"]').count()>0
 print('APPROVE BUTTON GEOMETRY',page.locator('button[data-control-decision="approved"]').first.evaluate("el=>({outer:el.outerHTML,rect:el.getBoundingClientRect().toJSON(),style:getComputedStyle(el).display,visibility:getComputedStyle(el).visibility,color:getComputedStyle(el).color})"))
 page.screenshot(path=str(out/'vmo_review_actions.png'))
 print('Browser page errors',errors)
 assert not errors
 browser.close()
