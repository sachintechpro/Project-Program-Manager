from pathlib import Path
p=Path(__file__).resolve().parents[1]/'app'/'map_routes.py'
s=p.read_text()
s=s.replace('from .value_mapping import seed_map,validate_map,measures,recommendations,markdown_report','from .value_mapping import seed_map,validate_map,measures,recommendations,markdown_report,reference_evidence')
needle='''    def get_stream(db,sid,user):'''
extra='''    class MapInquiryResponse(Base):
        __tablename__='stream_map_review_responses'
        id=Column(Integer,primary_key=True)
        review_id=Column(Integer,ForeignKey('stream_map_reviews.id'),nullable=False,unique=True)
        author_id=Column(Integer,nullable=False)
        author_name=Column(String(120),nullable=False)
        response=Column(Text,nullable=False)
        evidence_reference=Column(Text,default='')
        created_at=Column(DateTime,default=m.now)

    def decision_kind(d):
        return {'confirm':'approve','request_changes':'decline'}.get(d,d)
    def review_status(latest,required_roles):
        if all(x in latest and decision_kind(latest[x].decision)=='approve' for x in required_roles):return 'approved'
        if any(x in latest and decision_kind(latest[x].decision)=='decline' for x in required_roles):return 'declined'
        if any(x in latest and decision_kind(latest[x].decision)=='request_information' for x in required_roles):return 'needs_information'
        return 'in_review'

'''
assert needle in s;s=s.replace(needle,extra+needle)
start=s.index('    def doc_output(db,stream,obj,user):')
end=s.index('    class MapUpdate(BaseModel):',start)
s=s[:start]+'''    def doc_output(db,stream,obj,user):
        d=json.loads(obj.body);rev=reviews(db,obj)
        latest={r.role:r for r in rev}
        responses={x.review_id:x for x in db.execute(select(MapInquiryResponse).where(MapInquiryResponse.review_id.in_([r.id for r in latest.values()]))).scalars().all()} if latest else {}
        status=review_status(latest,d['review_roles'])
        return {'value_stream':m.visible_stream(stream,user),'version':obj.version,'map':d,
         'current':measures(d['current']),'future':measures(d['future']),'recommendations':recommendations(d),
         'reference_evidence':reference_evidence(stream.key),
         'meetings':[meeting_dict(x,user) for x in meetings(db,stream.id)],
         'reviews':[{'id':r.id,'role':r.role,'decision':r.decision,'kind':decision_kind(r.decision),'name':r.actor_name,
          'comment':r.comment,'version':r.map_version,'date':m.utcstr(r.created_at),
          'response':({'response':responses[r.id].response,'evidence_reference':responses[r.id].evidence_reference,
                       'author_name':responses[r.id].author_name,'date':m.utcstr(responses[r.id].created_at)} if r.id in responses else None)} for r in latest.values()],
         'review_roles':d['review_roles'],'review_status':status,'approved_for_mapping':status=='approved',
         'can_edit':can_edit(user,obj),
         'can_meet':user.role in MAP_MEETING_AUTHORS and user.role in d['invited_roles'],
         'can_review':user.role in d['review_roles'],
         'current_role':user.role,'editor_name':'Assigned mapping facilitator' if obj.editor_id else 'Open for authorized facilitator'}

''' + s[end:]
start=s.index('    class MapDecision(BaseModel):')
end=s.index('    @app.get(\'/api/streams/{sid}/map/history\')',start)
s=s[:start]+'''    class MapDecision(BaseModel):
        expected_version:int=Field(ge=1)
        decision:str
        comment:str=Field(default='',max_length=2400)
    @app.post('/api/streams/{sid}/map/reviews')
    def review_map(sid:int,req:MapDecision,request:Request,user:m.User=Depends(m.guard),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user);doc=json.loads(obj.body)
        if user.role not in doc['review_roles']:raise HTTPException(403,'This role is not an assigned map reviewer')
        if req.decision not in ('approve','decline','request_information','confirm','request_changes'):
            raise HTTPException(422,'Choose Approve, Decline, or Request more information')
        if obj.version!=req.expected_version:raise HTTPException(409,'The map has changed; review the latest version')
        kind=decision_kind(req.decision)
        if kind in ('decline','request_information') and len(req.comment.strip())<8:
            raise HTTPException(422,'Explain the reason and evidence needed (at least 8 characters)')
        if kind=='approve' and not meetings(db,sid):
            raise HTTPException(409,'Record at least one actual stakeholder discovery workshop before approving the map')
        if kind=='approve' and req.decision=='approve' and len(req.comment.strip())<8:
            raise HTTPException(422,'Cite the evidence checked before approving (at least 8 characters)')
        prior=db.execute(select(MapReview).where(MapReview.map_id==obj.id,MapReview.map_version==obj.version,MapReview.role==user.role).order_by(MapReview.id.desc())).scalars().first()
        if kind=='approve' and prior and decision_kind(prior.decision)=='request_information':
            answer=db.execute(select(MapInquiryResponse).where(MapInquiryResponse.review_id==prior.id)).scalar_one_or_none()
            if not answer:raise HTTPException(409,'The facilitator must answer your information request before approval')
        review=MapReview(map_id=obj.id,map_version=obj.version,role=user.role,actor_id=user.id,actor_name=user.name,
                         decision=req.decision,comment=req.comment.strip())
        db.add(review);db.flush()
        m.log(db,user,'value_map.review_recorded',f'VS-{sid}',{'review_id':review.id,'role':user.role,
            'decision':kind,'map_version':obj.version,'comment_digest':m.sha(review.comment)})
        db.commit();return doc_output(db,st,obj,user)

    class MapInquiryAnswer(BaseModel):
        expected_version:int=Field(ge=1)
        response:str=Field(min_length=12,max_length=3000)
        evidence_reference:str=Field(default='',max_length=500)
    @app.post('/api/streams/{sid}/map/reviews/{review_id}/answer')
    def answer_map_review(sid:int,review_id:int,req:MapInquiryAnswer,request:Request,user:m.User=Depends(m.guard),db:m.Session=Depends(m.db_session)):
        st,obj=lookup(db,sid,user)
        if not can_edit(user,obj):raise HTTPException(403,'Only the mapping facilitator can answer this information request')
        if obj.version!=req.expected_version:raise HTTPException(409,'The map was revised; answer on the current version')
        review=db.get(MapReview,review_id)
        if not review or review.map_id!=obj.id or review.map_version!=obj.version or decision_kind(review.decision)!='request_information':
            raise HTTPException(404,'Current information request not found')
        latest=db.execute(select(MapReview).where(MapReview.map_id==obj.id,MapReview.map_version==obj.version,MapReview.role==review.role).order_by(MapReview.id.desc())).scalars().first()
        if latest.id!=review.id:raise HTTPException(409,'Reviewer has already issued a newer decision')
        if db.execute(select(MapInquiryResponse).where(MapInquiryResponse.review_id==review.id)).scalar_one_or_none():
            raise HTTPException(409,'Already answered; ask reviewer to assess the response')
        row=MapInquiryResponse(review_id=review.id,author_id=user.id,author_name=user.name,response=req.response.strip(),
                               evidence_reference=req.evidence_reference.strip())
        db.add(row)
        m.log(db,user,'value_map.information_provided',f'VS-{sid}',{'review_id':review.id,
            'reviewer_role':review.role,'map_version':obj.version,'response_digest':m.sha(row.response)})
        db.commit();return doc_output(db,st,obj,user)

''' + s[end:]
old='''        text=markdown_report(st,json.loads(obj.body),meetings(db,sid),reviews(db,obj),obj.version)'''
new='''        rev=reviews(db,obj)
        answers={x.review_id:x for x in db.execute(select(MapInquiryResponse).where(MapInquiryResponse.review_id.in_([r.id for r in rev]))).scalars().all()} if rev else {}
        text=markdown_report(st,json.loads(obj.body),meetings(db,sid),rev,obj.version,answers)'''
assert old in s;s=s.replace(old,new)
p.write_text(s)

p=Path(__file__).resolve().parents[1]/'app'/'value_mapping.py'
s=p.read_text().replace('import json','import json,csv')
needle='def seed_map(key,**_):'
loader='''def reference_evidence(stream_key):
    """Read verified-schema, illustrative process references; never declare these real observations."""
    tables={}
    for name in ('step_evidence','role_review_guidance','workshop_questions'):
        path=MAP_DIR/(name+'.csv')
        with path.open(encoding='utf-8',newline='') as f:
            tables[name]=[r for r in csv.DictReader(f) if r['stream_key']==stream_key]
    return {'steps':{r['state']+':'+r['step_id']:r for r in tables['step_evidence']},
            'review_roles':{r['review_role']:r for r in tables['role_review_guidance']},
            'workshop_questions':tables['workshop_questions']}

'''
assert needle in s;s=s.replace(needle,loader+needle)
s=s.replace('def markdown_report(stream,doc,meetings,reviews,version):','def markdown_report(stream,doc,meetings,reviews,version,responses=None):')
s=s.replace('''    for r in reviews:parts.append(f'- {r.role}: {r.decision}; {r.actor_name}; {r.comment}')''','''    for r in reviews:
        parts.append(f'- {r.role}: {r.decision}; {r.actor_name}; {r.comment}')
        if responses and r.id in responses:
            answer=responses[r.id]
            parts.append(f'  - Facilitator response by {answer.author_name}: {answer.response}; evidence: {answer.evidence_reference}')''')
p.write_text(s)
print('Patched review status, approvals, decline, information request/answer and source-guided map output')
