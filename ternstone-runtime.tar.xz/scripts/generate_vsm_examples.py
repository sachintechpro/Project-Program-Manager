import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.catalog import STREAM_TEMPLATES
from app.value_mapping import MAP_DIR,make_step,validate_map,measures

# Each pipe-delimited row: step name | role | system | existing constraint | improvement concept.
FLOWS={
 'underwriting':'''Broker submission|product_owner|Broker intake|Missing ACORD and payroll schedules|Validate mandatory information at source
Account clearance|actuarial|Account master|Repeated duplicate entity checks|Reuse verified entity matching
Completeness review|integration|Document intake|Manual broker follow-up|Detect missing schedules before referral
Appetite referral|actuarial|Underwriting rules|Multiple approval queues|Apply explainable rules and human referrals
Rating and terms|business_owner|Rating engine|Serial pricing approvals|Validate rating inputs earlier
Bind and confirm policy|business_owner|Policy administration|Binding documents and confirmation delayed|Automate authorized binding and confirmation''',
 'claims':'''First notice of loss|customer_care|Claims intake|Incomplete loss evidence|Guide evidence capture
Coverage verification|claims_sme|Policy administration|Manual endorsement retrieval|Assemble effective coverage snapshot
Adjuster assignment|claims_sme|Claims platform|Specialist assignment queues|Route by severity and authority
Loss investigation|vendor|Field inspection|External evidence delays|Track vendor SLA and reports
Reserve approval|business_owner|Reserving controls|Repeated authority escalations|Pre-route reserve approvals
Settlement and payment|customer_care|Payments and notice|Manual settlement and payment communication|Link approved settlement and payment confirmation''',
 'cyber':'''Incident intake|customer_care|24-hour desk|After-hours callback delay|Enable round-the-clock intake
Verify insured|security|Identity verification|Manual contact validation|Use verified incident identity
Coverage triage|claims_sme|Cyber policy|Coverage forms retrieved by hand|Surface relevant forms and exclusions
Assess severity|security|Response console|Unclear escalation thresholds|Standardize severity and handoff rules
Assign partner|vendor|Response directory|Availability confirmed by calls|Maintain approved partner availability
Confirm engagement|ops|Vendor dispatch|No shared acknowledgment clock|Timestamp engagement and contacts''',
 'servicing':'''Service intake|customer_care|Policy portal|Missing endorsement details|Guide request-specific intake
Policy verification|integration|Policy admin|Conflicting policy snapshots|Retrieve effective authorized policy
Underwriting referral|actuarial|Underwriting workbench|Repeated business-rule questions|Route only exceptional changes
Premium adjustment|finance|Rating and billing|Manual calculations|Validate proration and rating
System synchronization|integration|Policy and billing APIs|Inconsistent updates|Use reconciliation and idempotent events
Customer confirmation|customer_care|Document delivery|Certificate delays|Publish verified completion notice''',
 'risk':'''Risk referral|actuarial|Underwriting system|Missing occupancy and exposure details|Prepopulate risk profile
Inspection scope|business_owner|Risk workbench|Scope clarification loops|Standardize survey objectives
Schedule inspection|vendor|Field scheduling|Travel and specialist queues|Match qualified inspectors by region
Conduct survey|vendor|Inspection mobile app|Manual photo re-entry|Capture tagged site evidence
Peer review|qa|Review queue|Report rework|Review significant findings first
Deliver report|customer_care|Document center|No receipt confirmation|Track report acknowledgment''',
 'distribution':'''Broker inquiry|customer_care|Broker portal|Email and phone duplication|Unify tracked inquiry intake
Entitlement check|security|Producer IAM|Appointment checks repeated|Verify producer/account access
Retrieve status|integration|Policy/submission systems|Multiple manual lookups|Read status from authorized APIs
Find documents|product_owner|Document management|Manual attachment retrieval|Search versioned documents
Resolve exception|actuarial|Underwriting queue|Unassigned escalations|Route to accountable owner
Broker response|customer_care|Communications|Repeated follow-ups|Record response and acknowledgment'''
}
# Customer, value, start, accepted outcome, process boundary, excluded work, guardrail.
VALUES={
'underwriting':'Commercial broker and insured|An authorized bound policy with accurate terms and timely confirmation|Application received|Binding confirmed to broker for accepted business|Submission received through binding confirmation for bound cases|Declines and referrals are separate paths and excluded from submission-to-bind median|Underwriter authority, payroll class codes and pricing controls',
'claims':'Commercial claimant and broker|Fair, timely settlement with payment status|First notice of loss|Approved settlement paid and confirmed|FNOL to settlement payment confirmation for settled cases|Denied and litigated claims are separately measured paths|Coverage, fraud, reserves and delegated authority',
'cyber':'Insured organization in crisis|Rapid authorized expert incident response|Incident notification received|Partner confirms engagement|Notification to partner assignment|Forensic remediation and claim closure|Breach privacy, privilege, vendor conflicts and coverage',
'servicing':'Commercial insured and broker|Correct servicing without billing mismatch|Service request received|Authorized change confirmed|Request to verified update|New-business underwriting|Premium reconciliation and segregation of financial duties',
'risk':'Insured business and risk engineer|Actionable loss prevention recommendations|Inspection requested|Reviewed risk report delivered|Referral to report delivery|Insured physical remediation|Inspector qualification, site safety and evidence integrity',
'distribution':'Commercial broker and producer|Accurate status and documents with fewer calls|Inquiry received|Verified answer delivered|Inquiry to resolution|Underwriting decision authority|Producer appointment and confidential document access'
}
VOLUME={'underwriting':4200,'claims':1800,'cyber':85,'servicing':6200,'risk':900,'distribution':3800}
SPECIAL={'underwriting':'actuarial','claims':'claims_sme','cyber':'security','servicing':'finance','risk':'actuarial','distribution':'customer_care'}
WAIT=[.1,.17,.23,.22,.19,.09];ACTIVE=[.14,.12,.20,.26,.20,.08]
def allocate(total,weights):
    a=[round(total*w,2) for w in weights[:-1]]
    return a+[round(total-sum(a),2)]
MAP_DIR.mkdir(parents=True,exist_ok=True)
for stream in STREAM_TEMPLATES:
    key=stream['key'];entries=[x.split('|') for x in FLOWS[key].splitlines()]
    value=dict(zip(('customer','statement','trigger','outcome','boundary','exclusions','guardrails'),VALUES[key].split('|')))
    roles=list(dict.fromkeys(['business_owner','value_owner','program_manager','product_manager','product_owner','rte','architect','integration','qa','security','ops','customer_care','analytics','fde','engineer','team_coach','vmo',SPECIAL[key]]+([r for _,r,*_ in entries])))
    required=list(dict.fromkeys(['business_owner','value_owner',SPECIAL[key],'product_manager','architect','qa','ops','analytics']))
    doc={'reference':'illustrative/'+key+'/v1','modeled':True,'value':value,'monthly_volume':VOLUME[key],
         'clock':'elapsed clock hours','metric':stream['metric'],'unit':'hours' if key=='cyber' else 'days',
         'note':'Illustrative elapsed clock hours distributed to steps; validate from event timestamps before using in investment claims.',
         'invited_roles':roles,'review_roles':required,
         'agenda':['Agree who receives value and what counts as delivered','Confirm process boundary, exceptions and constraints','Review queue delays, rework, data sources and ownership','Approve measurable future-state hypothesis and improvement actions'],
         'candidate_initiatives':[x[4] for x in entries[:4]],'current':[],'future':[]}
    for mode in ('current','future'):
        total=stream['baseline' if mode=='current' else 'target']*(1 if key=='cyber' else 24)
        active=round(total*(.30 if key=='cyber' else .065) if mode=='current' else total*(.36 if key=='cyber' else .11),2)
        touches=allocate(active,ACTIVE);waits=allocate(total-active,WAIT)
        for idx,(name,role,system,pain,action) in enumerate(entries):
            row=make_step(('C' if mode=='current' else 'F')+str(idx+1),name,role,touches[idx],waits[idx],
                          min(99,round((91 if mode=='current' else 97)+.8*(idx%3),1)),pain if mode=='current' else '',system)
            row['improvement']=action if mode=='future' else ''
            doc[mode].append(row)
    assert validate_map(doc)
    assert abs(measures(doc['current'])['elapsed_hours']-stream['baseline']*(1 if key=='cyber' else 24))<.02
    (MAP_DIR/(key+'.json')).write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
    print(key,measures(doc['current'])['elapsed_hours'],measures(doc['future'])['elapsed_hours'])
(MAP_DIR/'SCHEMA.md').write_text('''# Value stream map reference inputs\n\nSix fictional commercial and specialty insurance process maps. Steps use **elapsed clock hours**: touch_hours is active handling; wait_hours is elapsed waiting. Monthly volume and first-pass quality are illustrative, not measured. Current/future totals deliberately match the value stream headline estimates, not independently observed medians. Do not claim a measured end-to-end median by summing per-step estimates.\n\nEach record defines customer value, start, outcome, boundaries, risks, roles, workflow steps, workshop agenda, and candidate improvements. Original reference JSON remains unchanged. Actual edits, workshop notes, and reviewer decisions are separately versioned and audited in the application database.\n''')
