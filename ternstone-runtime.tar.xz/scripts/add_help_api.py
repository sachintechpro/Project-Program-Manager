from pathlib import Path
p=Path(__file__).resolve().parents[1]/'app/main.py'
s=p.read_text()
marker="@app.get('/api/connectors')"
assert marker in s and "@app.post('/api/help/chat')" not in s
block='''# Read-only, role-aware help. It never calls the workflow mutation endpoints.
from .help_catalog import help_payload, page_catalog, get_field
from .help_service import answer as help_answer, permitted_page

@app.get('/api/help/catalog')
def help_catalog_endpoint(user:User=Depends(get_user),db:Session=Depends(db_session)):
    payload=help_payload(user.role)
    openai_connector=db.execute(select(Connector).where(Connector.provider=='openai')).scalar_one_or_none()
    payload['ai_available']=bool(openai_connector and openai_connector.mode=='live' and openai_connector.config_encrypted and FERNET)
    return payload

class ContextHelpRequest(BaseModel):
    question:str=Field(min_length=1,max_length=600)
    page:str=Field(default='dashboard',max_length=40)
    field_key:str=Field(default='',max_length=100)
    initiative_id:Optional[int]=None
    use_ai:bool=False

@app.post('/api/help/chat')
def help_chat(req:ContextHelpRequest,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    from .help_service import permitted_page
    pages=page_catalog()
    page=req.page if req.page in pages or req.page in ('initiative','contract') else 'dashboard'
    finance=can_view_financials(user)
    perms={'can_view_financials':finance,'view_connectors':user.role in VIEW_CONNECTORS,'view_audit':user.role in AUDIT_VIEW}
    if not permitted_page(user.role,page,perms):
        page='dashboard'
    initiative=None
    artifacts=[]
    controls=[]
    if req.initiative_id and user.role!='admin':
        initiative=db.get(Initiative,req.initiative_id)
        if not initiative:raise HTTPException(404,'Initiative not found')
        if initiative.current_stage!='closed':
            v=db.get(ValueStream,initiative.value_stream_id)
            controls=[c for c in review_state(db,initiative,v,initiative.current_stage)
                      if c['role']==user.role or user.role in APPROVAL_OVERSIGHT and (finance or initiative.current_stage not in ('portfolio','benefits') or c['role'] not in ('finance','lpm','executive','analytics'))]
        artifacts=[a for a in db.execute(select(Artifact).where(Artifact.initiative_id==initiative.id,Artifact.stage==initiative.current_stage)).scalars().all() if a.kind in ROLE_DOCS.get(user.role,())]
    field=req.field_key if get_field(req.field_key) else ''
    if field and get_field(field).get('scope')=='finance' and not finance:field=''
    message,next_page,followups=help_answer(req.question,user.role,page,field,initiative,artifacts,controls,perms,user.role in STAGE_GENERATORS)
    mode='guided'
    if req.use_ai:
        connector=db.execute(select(Connector).where(Connector.provider=='openai')).scalar_one_or_none()
        if not connector or connector.mode!='live':raise HTTPException(409,'AI chat is not enabled. The guided assistant remains available.')
        cfg=get_config(connector)  # explicit company-approved connector only; no ambient key fallback
        # Minimal, authorized context only. Do not send full documents, credentials, sensitive records, or unrestricted finance data.
        hints=[f'Role: {ROLE_LOOKUP[user.role]["name"]}', f'Current page: {page}', f'Guided answer: {message}']
        if initiative is not None:
            hints.append('Initiative stage: '+initiative.current_stage)
            hints.append('Initiative title: '+initiative.title[:120])
            hints.append('My assigned controls: '+', '.join(c['decision_title']+' ('+c['decision']+')' for c in controls if c['role']==user.role)[:500])
        if field:
            h=get_field(field)
            hints.append('Focused field: '+field+' — '+h['explanation']+' Example: '+h['example'])
        system=('You are a concise embedded work assistant for a commercial specialty insurance SAFe-inspired demo. '
                'Use only the supplied context and give actionable role-scoped guidance. '
                'Do not invent values, approvals, test runs, costs, capabilities or platform actions. '
                'Do not reveal data outside the user role or present guidance as authorization. '
                'Do not execute tools or ask for credentials. '
                'If context is missing, say so and point to the appropriate page. Keep response under 180 words.')
        try:
            with httpx.Client(timeout=25,follow_redirects=False) as client:
                resp=client.post('https://api.openai.com/v1/chat/completions',headers={'Authorization':'Bearer '+cfg['api_key']},json={
                    'model':cfg.get('model','gpt-4.1-mini'),
                    'messages':[{'role':'system','content':system},{'role':'user','content':'\\n'.join(hints)+'\\n\\nQuestion: '+req.question}],
                    'temperature':0.1,'max_tokens':400})
                resp.raise_for_status()
                message=resp.json()['choices'][0]['message']['content'].strip()[:2500]
                mode='connected-ai'
        except Exception as exc:
            raise HTTPException(502,'Connected AI is unavailable ('+type(exc).__name__+'). Try guided help.')
    log(db,user,'help.guidance_viewed','HELP-'+page,{'mode':mode,'field':field[:80],'initiative_id':initiative.id if initiative is not None else None})
    db.commit()
    return {'answer':message,'mode':mode,'page':page,'role':user.role,'action_page':next_page if permitted_page(user.role,next_page,perms) else 'dashboard',
            'followups':followups,'initiative_stage':initiative.current_stage if initiative else None,
            'read_only':True,'note':'Chat provides guidance. Record edits and approvals only in controlled workflow forms.'}

'''
s=s.replace(marker,block+marker)
p.write_text(s)
print('Appended help API')
