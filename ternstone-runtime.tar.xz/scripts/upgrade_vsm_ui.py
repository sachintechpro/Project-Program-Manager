from pathlib import Path
p=Path(__file__).resolve().parents[1]/'app'/'static'/'map_ui.js'
s=p.read_text()
s=s.replace("const formField=(name,label,val,tip='',multiline=false)=>", "const formField=(name,label,val,tip='',multiline=false,readonly=false)=>")
start=s.index('function metrics(')
end=s.index('function define()',start)
s=s[:start]+r'''function hint(label, explanation){return `<span class="vsm-hint" tabindex="0" aria-label="${H(label)}: ${H(explanation)}" title="${H(explanation)}">?</span>`;}
function evidence(state,step){return D.reference_evidence?.steps?.[state+':'+step.id]||null;}
function metrics(m,label){return `<div class="vsm-metric"><span>${label} ${hint(label,'Illustrative process durations. They are not confirmed service-level measurements.')}</span><b>${unit(m.elapsed_hours)}</b><small>${fmt(m.touch_hours)} h touch · ${fmt(m.wait_hours)} h waiting</small><small>${fmt(m.flow_efficiency_pct)}% modeled flow efficiency ${hint('Flow efficiency','Active handling hours divided by total touch-plus-wait hours. A modeled ratio, not observed productivity.')}</small></div>`;}
function relativeBreakdown(step,scale){const total=Number(step.touch_hours)+Number(step.wait_hours);return {touch:100*Number(step.touch_hours)/scale,wait:100*Number(step.wait_hours)/scale,total};}
function interactiveChart(state){
 const steps=D.map[state];const scale=Math.max(1,...D.map.current.map(x=>Number(x.touch_hours)+Number(x.wait_hours)),...D.map.future.map(x=>Number(x.touch_hours)+Number(x.wait_hours)));
 return `<div class="vsm-graph card" role="region" aria-label="${state==='current'?'Current':'Future'} state process time visualization">
 <div class="vsm-graph-heading"><div><div class="eyebrow">GRAPHICAL PROCESS EVIDENCE</div><h3>What takes time at each handoff?</h3><p>Select a bar to inspect its evidence, mandatory controls and exception path.</p></div><div class="vsm-legend"><span><i class="vsm-swatch vsm-active"></i> Active handling</span><span><i class="vsm-swatch vsm-wait"></i> Waiting / queue</span></div></div>
 ${steps.map((step,i)=>{const b=relativeBreakdown(step,scale);const ref=evidence(state,step);const detail=`${step.name}. Active ${fmt(step.touch_hours)} hours, waiting ${fmt(step.wait_hours)} hours, ${fmt(step.first_pass_pct)} percent first-pass. ${ref?.required_control||'Control to validate'}; source: ${ref?.source_to_check||step.system}.`;
 return `<button type="button" class="vsm-bar-row" data-vsm-inspect="${state}:${i}" title="${H(detail)}" aria-label="Inspect ${H(step.name)} evidence and controls"><span class="vsm-bar-label"><b>${String(i+1).padStart(2,'0')}</b> ${H(step.name)}</span><span class="vsm-bar-track"><i class="vsm-bar-touch" style="width:${b.touch.toFixed(2)}%"></i><i class="vsm-bar-wait" style="width:${b.wait.toFixed(2)}%"></i></span><span class="vsm-bar-total">${fmt(b.total)} h</span></button>`;}).join('')}
 <div class="vsm-graph-axis">Same scale for current and proposed future process • hours of modeled effort plus waiting</div><div id="vsm-inspect-panel" class="vsm-inspect-panel" aria-live="polite">Select any process bar to see its source, handoff and exceptions.</div></div>`;
}
function pairedGraphic(){
 const old=D.map.current, proposed=D.map.future,scale=Math.max(1,...old.map(s=>Number(s.touch_hours)+Number(s.wait_hours)));
 return `<div class="card vsm-paired"><div class="eyebrow">CURRENT VS FUTURE, SAME SCALE</div><h2>Which handoffs are expected to improve?</h2><p>Each numbered pair compares the same *position* in the flow. If the future process has different steps, review the names rather than assuming the stages are identical.</p><div class="vsm-legend"><span><i class="vsm-swatch vsm-active"></i> Touch</span><span><i class="vsm-swatch vsm-wait"></i> Wait</span></div>
 ${old.map((a,i)=>{const b=proposed[i];const d1=relativeBreakdown(a,scale), d2=b?relativeBreakdown(b,scale):null;
 return `<div class="vsm-pair"><div class="vsm-pair-label"><strong>${i+1}. ${H(a.name)}</strong><small>${b&&a.name!==b.name?'Proposed: '+H(b.name):'Same named step'}</small></div><div class="vsm-pair-bar"><small>Before</small><div class="vsm-bar-track"><i class="vsm-bar-touch" style="width:${d1.touch}%"></i><i class="vsm-bar-wait" style="width:${d1.wait}%"></i></div><b>${fmt(d1.total)}h</b></div>${d2?`<div class="vsm-pair-bar"><small>Target</small><div class="vsm-bar-track"><i class="vsm-bar-touch" style="width:${d2.touch}%"></i><i class="vsm-bar-wait" style="width:${d2.wait}%"></i></div><b>${fmt(d2.total)}h</b></div>`:''}</div>`;}).join('')}</div>`;
}
function evidencePanel(state,i){
 const item=D.map[state]?.[i];if(!item)return '';
 const ref=evidence(state,item);return `<h3>${H(item.name)} — ${state==='current'?'observed process hypothesis':'proposed process hypothesis'}</h3><div class="vsm-facts">
 <div><b>Owner</b><p>${H(role(item.owner_role))}</p></div><div><b>System</b><p>${H(item.system)}</p></div>
 <div><b>Evidence to collect ${hint('Evidence','Real implementation requires timestamps and case IDs from the authoritative business system.')}</b><p>${H(ref?.source_to_check||'Select the real source system')}</p></div>
 <div><b>Input / outcome record</b><p>${H(ref?.input_or_record||'Define input/output evidence')}</p></div>
 <div><b>Handoff to validate</b><p>${H(ref?.handoff||'Confirm next process owner')}</p></div>
 <div><b>Required control</b><p>${H(ref?.required_control||'Confirm compliance and business controls')}</p></div>
 <div><b>Exception to test</b><p>${H(ref?.exception_to_test||'Identify the negative path')}</p></div>
 <div><b>Improvement direction</b><p>${H(ref?.future_improvement||item.improvement||'Validate with stakeholders')}</p></div></div>
 <div class="vsm-mini-metrics">Active ${fmt(item.touch_hours)} h · Waiting ${fmt(item.wait_hours)} h · First-pass ${fmt(item.first_pass_pct)}% · Example monthly demand ${fmt(ref?.monthly_cases_modeled||D.map.monthly_volume)}</div>
 <p class="muted vsm-evidence-warning">Reference evidence is a source-to-check checklist, not a claim that the real system has been queried.</p>`;
}
function flow(state){
 const steps=D.map[state],editable=D.can_edit;
 return `<div class="vsm-flow" aria-label="${state} process map">${steps.map((s,i)=>{const ref=evidence(state,s);return `<div class="vsm-flow-step">
 <div class="vsm-step-no">${state==='current'?'CURRENT':'PROPOSED'} · ${i+1}/${steps.length} ${hint('Stage evidence',ref?.source_to_check||s.system)}</div>
 <h3>${H(s.name)}</h3><p>${H(role(s.owner_role))} · ${H(s.system)}</p>
 <div class="vsm-step-stat"><b>${fmt(s.touch_hours)} h</b><small>Touch ${hint('Touch time','Active work effort, in clock hours for this illustrative flow')}</small></div>
 <div class="vsm-step-stat wait"><b>${fmt(s.wait_hours)} h</b><small>Waiting ${hint('Waiting time','Elapsed queue or handoff time, including non-working hours')}</small></div>
 <div class="vsm-step-foot">${fmt(s.first_pass_pct)}% first-pass ${hint('First-pass quality','Fraction of work passing this stage without rework. Modeled, not measured.')}</div>
 <p class="vsm-step-issue">${H(state==='current'?s.problem:s.improvement)}</p>
 <button class="btn sm" data-vsm-inspect="${state}:${i}">View evidence ↗</button>${editable?`<button class="btn sm" data-vsm-edit="${state}:${i}">Edit step</button>`:''}</div>${i<steps.length-1?'<div class="vsm-flow-arrow" aria-label="Handoff to next step">→</div>':''}`;}).join('')}</div><div id="vsm-step-form" class="form-panel hidden"></div>`;
}
''' + s[end:]

start=s.index('function statePage(')
end=s.index('function improvements()',start)
s=s[:start]+r'''function statePage(state){
 const m=D[state],label=state==='current'?'Current state':'Future state';
 return `<div class="vsm-detail-intro"><div><div class="eyebrow">${state==='current'?'MAP THE CURRENT BUSINESS PROCESS':'DESIGN THE IMPROVED BUSINESS PROCESS'}</div><h2>${label}: customer request to accepted outcome</h2><p>${state==='current'?'Review real work, including queues, exceptions and handoffs. Confirm assumed values with system evidence.':'Plan better handoffs and controls, then verify that future targets are feasible. These are not realized outcomes.'}</p></div>${metrics(m,label)}</div>
 ${interactiveChart(state)}
 <p class="muted">Scroll through the process steps below →</p>${flow(state)}
 ${D.can_edit?`<button class="btn sm" data-vsm-add="${state}">+ Add process step</button>`:''}
 <div class="callout"><strong>Measurement note:</strong> Bar widths use a common scale. Touch = active handling; Wait = elapsed queue time; first-pass = no rework. Stage sums here are planning assumptions, <strong>not measured case-level medians</strong>.</div>`;
}
''' + s[end:]
# augment improvement view
start=s.index('function improvements()')
end=s.index('function validation()',start)
segment=s[start:end]
segment=segment.replace('`;<', '`;<') if False else segment
segment=segment.replace('return `<div class="vsm-comparison">', 'return `${pairedGraphic()}<div class="vsm-comparison">',1)
s=s[:start]+segment+s[end:]

start=s.index('function validation()')
end=s.index('async function render(',start)
s=s[:start]+r'''function validation(){
 const latest=Object.fromEntries(D.reviews.map(r=>[r.role,r]));
 const done=D.review_roles.filter(r=>latest[r]?.kind==='approve').length;
 const declined=D.review_roles.filter(r=>latest[r]?.kind==='decline').length;
 const inquiries=D.review_roles.filter(r=>latest[r]?.kind==='request_information').length;
 const statusLabel={approved:'Approved for mapping',declined:'Declined — revise the map',needs_information:'More information requested',in_review:'Waiting for reviewers'}[D.review_status]||'In review';
 return `<div class="vsm-split"><div class="card"><div class="eyebrow">ROLE-BASED DECISION / VERSION ${D.version}</div>
 <h2>Approve, decline, or ask for evidence</h2><p>These decisions validate the <strong>mapping facts and future-state proposal</strong>. They do not authorize portfolio funding or release.</p>
 ${!D.meetings.length?`<div class="callout warning">A genuine stakeholder workshop must be recorded before approval. Suggested agenda items do not count as a held meeting.</div>`:''}
 <div class="vsm-decision-overview"><strong>${H(statusLabel)}</strong><span>${done} approvals · ${inquiries} information requests · ${declined} declines</span></div>
 <div class="vsm-progress" title="${done} of ${D.review_roles.length} role approvals"><span style="width:${100*done/D.review_roles.length}%"></span></div>
 <small>${done} of ${D.review_roles.length} required approvals for this revision. Updating the map or meeting notes invalidates previous decisions.</small>
 <div class="vsm-review-list">${D.review_roles.map(r=>{const x=latest[r];const kind=x?.kind;const guidance=D.reference_evidence?.review_roles?.[r];
 return `<div class="vsm-review-row"><span><strong>${H(role(r))}</strong>${guidance?`<small class="vsm-review-question">${H(guidance.approval_question)}</small>`:''}</span>
 <span class="vsm-review-status ${kind==='approve'?'confirmed':kind==='decline'?'changes':kind==='request_information'?'needs':''}">${kind==='approve'?'Approved':kind==='decline'?'Declined':kind==='request_information'?(x.response?'Information provided — review again':'More information requested'):'Awaiting decision'}</span>
 ${guidance?`<small><strong>Evidence:</strong> ${H(guidance.evidence_required)}</small>`:''}
 ${x?.comment?`<small><strong>${kind==='approve'?'Evidence checked':'Review note'}:</strong> ${H(x.comment)} · ${H(x.name)}</small>`:''}
 ${x?.response?`<div class="vsm-answer"><strong>Facilitator response:</strong> ${H(x.response.response)}${x.response.evidence_reference?`<br><strong>Source:</strong> ${H(x.response.evidence_reference)}`:''}<br><small>Reviewer must make a new decision; response is not automatic approval.</small></div>`:''}
 ${kind==='request_information'&&!x.response&&D.can_edit?`<button type="button" class="btn sm" data-vsm-answer="${x.id}">Answer information request ↗</button>`:''}</div>`}).join('')}</div>
 <div id="vsm-answer-form" class="form-panel hidden"></div>
 ${D.can_review?`<form data-vsm-form="review" class="vsm-review-form"><div class="eyebrow">YOUR ROLE: ${H(role(D.current_role))}</div><label class="field">Decision evidence / reason<textarea name="comment" rows="3" minlength="8" required placeholder="Which fact, source or control did you check? For a decline or information request, state exactly what is missing."></textarea></label>
 <div class="vsm-decision-buttons"><button class="btn primary" type="submit" name="decision" value="approve" ${D.meetings.length?'':'disabled title="Record a stakeholder workshop first"'}>✓ Approve map</button><button class="btn" type="submit" name="decision" value="request_information">? Ask for more information</button><button class="btn vsm-decline" type="submit" name="decision" value="decline">✕ Decline</button></div><p class="muted">These actions create an audit record and do not bypass the LPM funding process.</p></form>`:'<p class="muted">You can review the evidence, but your role is not assigned an approval for this value stream.</p>'}</div>
 <div class="card"><div class="eyebrow">DECISION PACKAGE</div><h2>Carry evidence into the portfolio.</h2><p>Export a Markdown record with the value definition, both maps, quantitative hypotheses, genuine workshop notes, role decisions and facilitator responses.</p>
 <button class="btn primary" data-vsm-download>↓ Export map and decision log</button><button class="btn" data-vsm-history>Map revision history</button><div id="vsm-history-box"></div>
 <hr><h3>Before funding an improvement</h3><ol class="vsm-agenda"><li>Verify the baseline with source-system case timestamps.</li><li>Record disagreements, assumptions and outstanding evidence in RAID.</li><li>Confirm security, claims and underwriting decision authority.</li><li>State an improvement hypothesis with a benefit owner.</li><li>Submit an initiative through LPM and the Portfolio Kanban.</li></ol>
 ${C.S.user.permissions?.create_initiative?'<button class="btn" data-vsm-initiative="0">Propose an initiative ↗</button>':''}
 ${D.approved_for_mapping?'<div class="callout good">All assigned reviewers approved this mapping revision. LPM funding remains separate.</div>':'<div class="callout">A map decision is not an investment, implementation or release approval.</div>'}</div></div>`;
}
''' + s[end:]

# add inspect and answer button handlers in click handler
anchor="  else if(btn.dataset.vsmEdit){const [state,i]=btn.dataset.vsmEdit.split(':');stepEditor(state,Number(i))}"
assert anchor in s
s=s.replace(anchor,'''  else if(btn.dataset.vsmInspect){const [state,i]=btn.dataset.vsmInspect.split(':');const panel=$('vsm-inspect-panel');if(panel){panel.innerHTML=evidencePanel(state,Number(i));panel.scrollIntoView({behavior:'smooth',block:'nearest'});}else{const doc=btn.closest('.vsm-flow-step');if(doc){let panel=doc.querySelector('.vsm-embedded-evidence');if(!panel){panel=document.createElement('div');panel.className='vsm-embedded-evidence';doc.append(panel)}panel.innerHTML=evidencePanel(state,Number(i));}}}
  else if(btn.dataset.vsmAnswer){const id=Number(btn.dataset.vsmAnswer);const x=D.reviews.find(r=>r.id===id);if(!x||x.kind!=='request_information')throw Error('Information request not found');const panel=$('vsm-answer-form');panel.innerHTML=`<h3>Respond to ${H(role(x.role))}</h3><p>${H(x.comment)}</p><form data-vsm-form="answer" data-review-id="${id}"><label class="field">What evidence answers the question?<textarea name="response" rows="4" minlength="12" required placeholder="Provide a specific answer, not a generic approval statement."></textarea></label><label class="field">Supporting source or evidence reference<input name="evidence_reference" placeholder="Source system, document ID or recorded workshop"></label><button class="btn primary" type="submit">Submit response to reviewer</button></form>`;panel.classList.remove('hidden');panel.scrollIntoView({behavior:'smooth',block:'nearest'});}
''' +anchor)
old="""await C.api('/api/streams/'+C.S.mapStream+'/map/reviews',{method:'POST',body:{expected_version:D.version,decision:data.get('decision'),comment:String(data.get('comment')||'')}});C.toast('Your role decision recorded for this version');await render(C)"""
new="""await C.api('/api/streams/'+C.S.mapStream+'/map/reviews',{method:'POST',body:{expected_version:D.version,decision:ev.submitter?.value||data.get('decision'),comment:String(data.get('comment')||'')}});C.toast('Your review decision is recorded for map version '+D.version);await render(C)"""
assert old in s;s=s.replace(old,new)
old="""  }else if(type==='review'){"""
new="""  }else if(type==='answer'){
   const id=Number(f.dataset.reviewId);
   await C.api('/api/streams/'+C.S.mapStream+'/map/reviews/'+id+'/answer',{method:'POST',body:{expected_version:D.version,response:String(data.get('response')||''),evidence_reference:String(data.get('evidence_reference')||'')}});
   C.toast('Response recorded for the assigned reviewer');await render(C);
  }else if(type==='review'){"""
assert old in s;s=s.replace(old,new)
# Add context-aware agenda questions, no fabricated meeting notes
old='''<h3>Suggested workshop agenda</h3><ol class="vsm-agenda">${D.map.agenda.map(s=>`<li>${H(s)}</li>`).join('')}</ol>'''
new='''<h3>Suggested workshop agenda</h3><ol class="vsm-agenda">${D.map.agenda.map(s=>`<li>${H(s)}</li>`).join('')}</ol><div class="vsm-guidance"><h3>Ask for this evidence</h3>${(D.reference_evidence?.workshop_questions||[]).map(x=>`<details><summary>${H(x.meeting_question)} ${hint('Suggested question',x.example_evidence_to_request)}</summary><p><strong>Bring:</strong> ${H(x.example_evidence_to_request)}</p><small>Suggested question only — not recorded meeting minutes</small></details>`).join('')}</div>'''
assert old in s;s=s.replace(old,new)
p.write_text(s)
print('Reworked all mapped state visualizations, short tooltips, role decisions and facilitator responses')
