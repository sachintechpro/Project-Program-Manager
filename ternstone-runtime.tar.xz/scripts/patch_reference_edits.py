from pathlib import Path
p=Path(__file__).parents[1]/'app'/'main.py';s=p.read_text()
def swap(a,b):
 global s
 if s.count(a)!=1:raise RuntimeError(f'missing or duplicate: {a[:70]}, {s.count(a)}')
 s=s.replace(a,b)
swap('class ControlReview(BaseModelDB):','''class ScenarioRecord(BaseModelDB):
    __tablename__='initiative_reference_records'
    id=Column(Integer,primary_key=True)
    initiative_id=Column(Integer,ForeignKey('initiatives.id'),nullable=False)
    table_name=Column(String(80),nullable=False)
    source_record_id=Column(String(150),nullable=False)
    payload=Column(Text,nullable=False)
    author_id=Column(Integer,ForeignKey('users.id'),nullable=False)
    version=Column(Integer,default=1)
    updated_at=Column(DateTime,default=now)

class ScenarioRecordRevision(BaseModelDB):
    __tablename__='initiative_reference_revisions'
    id=Column(Integer,primary_key=True)
    record_id=Column(Integer,ForeignKey('initiative_reference_records.id'),nullable=False)
    version=Column(Integer,nullable=False)
    payload=Column(Text,nullable=False)
    digest=Column(String(64),nullable=False)
    author_id=Column(Integer,nullable=False)
    created_at=Column(DateTime,default=now)

class ControlReview(BaseModelDB):''')
swap("    if req.template:\n        base=", "    if req.template:\n        base=") # no-op
swap("        db.add(ScenarioLink(initiative_id=i.id,template_key=req.template))", "        db.add(ScenarioLink(initiative_id=i.id,template_key=req.template))\n        create_reference_snapshot(db,i,req.template,user)")
swap("        context=doc_appendix(kind,linked.template_key) if linked else ''", "        copies=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id)).scalars().all()\n        overrides={}\n        for rec in copies:overrides.setdefault(rec.table_name,[]).append(json.loads(rec.payload))\n        context=doc_appendix(kind,linked.template_key,overrides if overrides else None) if linked else ''")
anchor="@app.get('/api/reference-catalog')\n"
insert='''def create_reference_snapshot(db,i,source,user):
    for name in scenario_schemas():
        if name.startswith('_') or name in ('value_streams','initiatives','role_approval_controls'):continue
        rows=[x for x in scenario_table(name) if x.get('initiative_key')==source]
        for row in rows:
            data={k:(v.replace(source,i.key) if isinstance(v,str) else v) for k,v in row.items()}
            # Distinguish the new initiative's data from the source example's identifiers.
            data['initiative_key']=i.key
            primary=scenario_schemas()[name]['key']
            content=json.dumps(data,sort_keys=True,ensure_ascii=False)
            record=ScenarioRecord(initiative_id=i.id,table_name=name,source_record_id=data[primary],payload=content,author_id=user.id,version=1)
            db.add(record);db.flush()
            db.add(ScenarioRecordRevision(record_id=record.id,version=1,payload=content,digest=sha(content),author_id=user.id))

class ScenarioEditRequest(BaseModel):
    expected_version:int=Field(ge=1)
    fields:dict[str,str]

@app.put('/api/scenario-records/{rid}')
def edit_reference_record(rid:int,req:ScenarioEditRequest,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    rec=db.get(ScenarioRecord,rid)
    if not rec:raise HTTPException(404,'Reference record not found')
    i=db.get(Initiative,rec.initiative_id)
    if rec.author_id!=user.id:raise HTTPException(403,'Only the original author can edit this reference record')
    if i.current_stage!='portfolio':raise HTTPException(409,'Approved initiative reference data is locked; use contract revision or formal change control')
    if req.expected_version!=rec.version:raise HTTPException(409,'This row has changed. Reload to avoid overwriting it')
    schema=scenario_schemas()[rec.table_name]
    old=json.loads(rec.payload)
    if set(req.fields)!=set(schema['fields']):raise HTTPException(422,'Values must follow the complete published CSV schema')
    pk=schema['key']
    if req.fields[pk]!=old[pk] or req.fields.get('initiative_key')!=i.key:
        raise HTTPException(422,'Primary and initiative identifiers are stable and cannot be changed')
    for field,typ in schema['fields'].items():
        val=req.fields[field]
        if not isinstance(val,str):raise HTTPException(422,'Fields must be plain text')
        if len(val)>1500:raise HTTPException(422,'Value exceeds the schema length limit')
        if field!='test_evidence_ref' and not val.strip():raise HTTPException(422,f'{field} cannot be blank')
        if typ=='role' and val not in ROLE_LOOKUP:raise HTTPException(422,f'{field} must be a known stakeholder role')
        if typ.startswith('enum:') and val not in typ.split(':',1)[1].split('|'):raise HTTPException(422,f'{field} must use a permitted value')
        if typ=='boolean' and val not in ('true','false'):raise HTTPException(422,f'{field} must be true or false')
        if typ in ('integer','decimal'):
            try:n=float(val)
            except ValueError:raise HTTPException(422,f'{field} must be numeric')
            if n<0 or typ=='integer' and not n.is_integer():raise HTTPException(422,f'{field} must be nonnegative and correctly typed')
        if typ.startswith('ref:') and field not in ('initiative_key',):
            # The reference must resolve within the same initiative snapshot.
            target=typ[4:]
            valid=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id,ScenarioRecord.table_name==target)).scalars().all()
            valid_ids={json.loads(x.payload).get(scenario_schemas()[target]['key']) for x in valid}
            if val not in valid_ids:raise HTTPException(422,f'{field} must reference an existing row in {target}')
        if rec.table_name=='test_cases' and field=='execution_status' and val!='not_run':
            raise HTTPException(422,'Do not mark a sample test as executed. Use real test evidence in the QA contract.')
        if rec.table_name=='metrics' and field=='actual_status' and val!='unmeasured':
            raise HTTPException(422,'Do not claim a measured benefit without authoritative operational evidence.')
    payload=json.dumps(req.fields,sort_keys=True,ensure_ascii=False)
    if payload==rec.payload:return {'id':rec.id,'version':rec.version,'saved':False}
    rec.payload=payload;rec.version+=1;rec.updated_at=now()
    db.add(ScenarioRecordRevision(record_id=rec.id,version=rec.version,payload=payload,digest=sha(payload),author_id=user.id))
    log(db,user,'reference.revised',f'REF-{rec.id}',{'initiative':i.id,'table':rec.table_name,'version':rec.version,'digest':sha(payload)})
    db.commit();return {'id':rec.id,'version':rec.version,'saved':True}

@app.get('/api/initiatives/{iid}/reference-export')
def export_reference_csv(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    require_business_data_access(user)
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    link=db.execute(select(ScenarioLink).where(ScenarioLink.initiative_id==iid)).scalar_one_or_none()
    template=link.template_key if link else (i.key if i.key in INIT_MAP else None)
    if not template:raise HTTPException(404,'No example pack attached')
    data=reference_rows(db,i,template,can_view_financials(user),user)
    bio=io.BytesIO()
    import csv
    with zipfile.ZipFile(bio,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('README.md','# Initiative reference rows\\n\\nModelled examples and author-edited planning data; not verified production activity.\\n')
        for name,arr in data.items():
            if not arr:continue
            out=io.StringIO();writer=csv.DictWriter(out,fieldnames=list(scenario_schemas()[name]['fields']))
            writer.writeheader();writer.writerows([{k:r[k] for k in writer.fieldnames} for r in arr])
            z.writestr(name+'.csv',out.getvalue())
        safe={k:v for k,v in scenario_schemas().items() if k in data}
        z.writestr('schema.json',json.dumps(safe,indent=2))
    return Response(content=bio.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="{i.key}-reference.zip"'})

def reference_rows(db,i,template,financial_access,user):
    copies=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id).order_by(ScenarioRecord.id)).scalars().all()
    if copies:
        out={}
        for r in copies:
            if r.table_name=='cost_estimates' and not financial_access:continue
            val=json.loads(r.payload)
            val['__record_id']=r.id;val['__version']=r.version
            val['__can_edit']=bool(r.author_id==user.id and i.current_stage=='portfolio')
            out.setdefault(r.table_name,[]).append(val)
        return out
    return scenario_preview(template,financial_access)['tables']

'''
swap(anchor,insert+anchor)
start="""    data=scenario_preview(link.template_key,can_view_financials(user))
    data['example_available']=True;data['message']='Illustrative source examples. Test status not_run and unmeasured metrics are not production results.'
"""
finish="""    data=scenario_preview(link.template_key,can_view_financials(user))
    data['tables']=reference_rows(db,i,link.template_key,can_view_financials(user),user)
    data['counts']={k:len(v) for k,v in data['tables'].items()}
    data['example_available']=True;data['message']='Illustrative source examples. User-owned row edits are versioned and audited; tests and benefits remain unmeasured until real evidence exists.'
"""
swap(start,finish)
p.write_text(s)
# change enterprise_data.doc_appendix to render edited rows where provided
q=Path(__file__).parents[1]/'app'/'enterprise_data.py';v=q.read_text()
v=v.replace('def doc_appendix(kind,template_key):','def doc_appendix(kind,template_key,record_overrides=None):')
v=v.replace("data=[x for x in table(name) if x.get('initiative_key')==template_key]","data=(record_overrides.get(name,[]) if record_overrides else [x for x in table(name) if x.get('initiative_key')==template_key])")
q.write_text(v)
print('patched reference row editing')
