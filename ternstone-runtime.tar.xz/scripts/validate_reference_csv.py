"""Strict relational and semantic checks for the fictional specialty-insurance CSV catalog."""
from pathlib import Path
import json,csv,sys,collections,datetime
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.catalog import ROLES,STAGE_IDS
DATA=ROOT/'seed'/'data'; schema=json.loads((DATA/'schema.json').read_text());roles={r[0] for r in ROLES};problems=[];tables={};indexes={}
def bad(msg):problems.append(msg)
for name,sc in schema.items():
    if name.startswith('_'):continue
    path=DATA/(name+'.csv'); fields=list(sc['fields'])
    with path.open(encoding='utf-8',newline='') as f:
        reader=csv.DictReader(f);rows=list(reader)
        if reader.fieldnames!=fields:bad(f'{name}: expected headers {fields}, got {reader.fieldnames}')
    if not rows:bad(f'{name}: missing data')
    tables[name]=rows
    key=sc['key'];ids=[r.get(key,'').strip() for r in rows]
    duplicates=[k for k,v in collections.Counter(ids).items() if v>1]
    if '' in ids or duplicates:bad(f'{name}: missing or repeated PK {duplicates}')
    indexes[name]=set(ids)
for name,sc in schema.items():
    if name.startswith('_'):continue
    for ix,row in enumerate(tables[name],2):
        for field,typ in sc['fields'].items():
            val=row.get(field,'')
            if val is None or val.strip()=='':
                if field not in {'test_evidence_ref'}:bad(f'{name}:{ix}:{field} empty')
                continue
            if typ=='id' and (len(val)>120 or any(c.isspace() for c in val)):bad(f'{name}:{ix}:{field} invalid id')
            if typ.startswith('ref:') and val not in indexes.get(typ[4:],set()):bad(f'{name}:{ix}:{field} unknown {val}')
            if typ=='role' and val not in roles:bad(f'{name}:{ix}:{field} unknown role {val}')
            if typ.startswith('enum:') and val not in typ.split(':',1)[1].split('|'):bad(f'{name}:{ix}:{field} invalid option {val}')
            if typ=='boolean' and val not in {'true','false'}:bad(f'{name}:{ix}:{field} invalid boolean')
            if typ in ('integer','decimal'):
                try:
                    n=float(val)
                    if n<0 or typ=='integer' and (not n.is_integer()):bad(f'{name}:{ix}:{field} invalid amount')
                except ValueError:bad(f'{name}:{ix}:{field} invalid number')

by_init={r['initiative_key']:r for r in tables['initiatives']}
metrics={r['initiative_key']:r for r in tables['metrics']}
for key,r in by_init.items():
    data={name:[row for row in rows if row.get('initiative_key')==key] for name,rows in tables.items()}
    if key not in metrics:bad(f'{key}: missing KPI')
    if sum(int(x['planned_cost_usd']) for x in data['cost_estimates']) != int(r['estimated_cost_usd']):bad(f'{key}: cost breakdown does not reconcile to budget')
    if len(data['requirements'])<3:bad(f'{key}: insufficient requirement coverage')
    if len(data['business_steps'])<4:bad(f'{key}: insufficient process steps')
    if [int(s['sequence']) for s in data['business_steps']]!=list(range(1,len(data['business_steps'])+1)):bad(f'{key}: process sequence is inconsistent')
    if len({f['field_name'] for f in data['data_fields']})!=len(data['data_fields']):bad(f'{key}: duplicate entity field names')
    tests=collections.Counter(t['requirement_id'] for t in data['test_cases'])
    for req in data['requirements']:
        if tests[req['requirement_id']]<2:bad(f'{key}: requirement {req["requirement_id"]} lacks paired positive/negative tests')
    if any(x['execution_status']!='not_run' for x in data['test_cases']):bad(f'{key}: sample tests must not claim execution')
    if any(x['actual_status']!='unmeasured' for x in data['metrics']):bad(f'{key}: sample benefits must not claim measured results')
    if float(metrics[key]['baseline_value'])<=float(metrics[key]['target_value']) and metrics[key]['direction']=='decrease':bad(f'{key}: improvement direction inconsistent')
    if 'hours' in r['operating_volume'] and metrics[key]['metric_unit']=='days':pass # rate and duration are separate concepts
controls=tables['role_approval_controls']
if len(controls)!=len(roles) or {x['role'] for x in controls}!=roles:bad('Every stakeholder must have exactly one distinct role-specific control entry')
if any(c['stage'] not in STAGE_IDS[:-1] for c in controls):bad('Unknown approval stage')
if len({(c['role'],c['stage']) for c in controls})!=len(controls):bad('Repeated role-stage control definitions')
if problems:
    print('SCHEMA AUDIT FAILED:\n'+'\n'.join(' - '+x for x in problems));sys.exit(1)
report={'tables':len(tables),'rows':sum(len(x) for x in tables.values()),'initiatives':len(by_init),'roles_with_review_actions':len(controls),'foreign_key_errors':0,'duplicate_ids':0,'missing_required_values':0,'unexecuted_test_cases':len(tables['test_cases']),'reference_results_are_actual':False,'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(DATA/'validation-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('VALIDATED',json.dumps(report,indent=2))
