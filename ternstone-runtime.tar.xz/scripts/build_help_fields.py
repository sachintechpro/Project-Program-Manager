"""Author readable field glossary from explicit definitions and scenario schema."""
import csv, json, re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
schema=json.loads((root/'seed/data/schema.json').read_text())
# key -> (explanation, example, SAFe / validation note)
defs={
 'name':('The human-readable name of this value stream or person.','Commercial & Specialty Underwriting','Use a clear name that another team can recognize.'),
 'title':('A short description of the initiative or decision.','Workers Compensation submission checks','Name the business result or workflow being changed.'),
 'stream_id':('The value stream that owns this initiative.','Commercial & Specialty Underwriting','The investment and resulting work must link to one stream.'),
 'initiative_key':('Stable identifier linking records belonging to one initiative.','wc-submission','Do not reuse the key for a different initiative.'),
 'initiative_id':('The application ID for an initiative.','INIT-12','Use it to find linked contracts and evidence.'),
 'lob':('The commercial or specialty insurance product area.','Workers Compensation','Choose the line that owns the business rule.'),
 'line_of_business':('The insurance product or risk class affected.','Commercial Property','Keep coverage and jurisdiction assumptions clear.'),
 'owner':('Person or function accountable for operating this value stream.','Underwriting leadership','An owner remains accountable after implementation.'),
 'owner_role':('Role responsible for the task or expected result.','product_owner','Use a defined role rather than an ambiguous team.'),
 'theme':('The strategic improvement this stream supports.','Faster quote-to-bind','Connect this to an approved enterprise objective.'),
 'description':('Plain-English boundary or purpose of the work.','From broker submission through policy binding','State where the process begins and ends.'),
 'metric':('The main measure of value stream performance.','Median days to bind','Use a specific unit and a dependable data source.'),
 'baseline':('Measured performance before the change.','11.8 days','Keep a dated source and consistent units.'),
 'target':('Desired future performance for the same measure.','6.2 days','Set a target date and accountable benefit owner.'),
 'baseline_value':('Measured current-state value for this metric.','11.8','Do not enter a target or invented result as a baseline.'),
 'target_value':('Desired future-state value for this metric.','6.2','Measure against the same definition as baseline.'),
 'unit':('The unit used to compare baseline and target.','days','Use the same unit for both figures.'),
 'metric_unit':('Unit in which this KPI is reported.','business days','Specify hours days percent or dollars explicitly.'),
 'volume':('Expected amount of operational work over a stated period.','4,200 submissions per month','Always state the period and transaction type.'),
 'operating_volume':('Expected business transaction volume for the example.','4,200 submissions / month','Use this to understand capacity demand.'),
 'budget':('Requested or approved investment amount.','$420,000','Planning amount; not an actual expense. Finance approval is separate.'),
 'annual_benefit':('Expected annual financial value of the improvement.','$920,000 per year','A hypothesis until validated after launch.'),
 'estimated_cost_usd':('Illustrative total initiative cost in US dollars.','420000','Cost component rows should reconcile to the initiative total.'),
 'estimated_annual_benefit_usd':('Estimated annual benefit before validation.','920000','Do not report it as realized savings.'),
 'planned_cost_usd':('Estimated cost for this activity or category.','75000','Must reconcile with the initiative budget.'),
 'cost_category':('Category of planned expenditure.','Integration engineering','Use consistent categories across initiatives.'),
 'cost_id':('Unique identifier for an initiative cost item.','COST-WC-01','Do not duplicate within the reference data.'),
 'forecast_status':('Whether the cost estimate has been formally updated.','planning','Distinguish plan from actual finance data.'),
 'estimate_basis':('Explanation for the cost estimate.','Estimated engineering effort and tooling','State key assumptions and the date of the estimate.'),
 'workflow':('Sequence of business activities from request to outcome.','Broker submits → underwriter checks → quote','Describe exceptional paths as well as happy paths.'),
 'rules':('Business constraints and decisions the solution must honor.','Underwriter approves prohibited-class exceptions','Keep final authority with the specified business role.'),
 'risk':('Uncertain event that could affect the initiative.','Incorrect appetite filtering','Include cause impact and mitigation.'),
 'dependencies':('Systems teams or decisions required before work can complete.','Broker portal and policy platform','Name the owner and expected handoff.'),
 'response':('What will be done to manage this risk issue or dependency.','Validate mapping; escalate failure to architect','Make the next action testable and assign a date.'),
 'evidence_ref':('Reference to the artifact or test that supports a decision.','ART-12 or TEST-WC-03','A reference is not proof unless its target exists and is current.'),
 'due_date':('Date by which the next action or resolution is needed.','2026-12-15','Escalate if the date threatens a delivery milestone.'),
 'priority':('Relative urgency and consequence of this item.','high','Use business impact rather than who requested it.'),
 'status':('Current workflow condition for the item.','open','Update it when the real condition changes.'),
 'type':('Classifies RAID as risk assumption issue or dependency.','risk','Risk is possible; issue has already happened.'),
 'scope':('Whether the item belongs to a stream or one initiative.','INIT-12','Keep scope narrow enough for one owner.'),
 'responsible':('Role or roles actually performing this activity.','fde','R in RACI; more than one can do work.'),
 'accountable':('One role ultimately answerable for the outcome.','program_manager','A in RACI; use exactly one for clarity.'),
 'consulted':('Roles whose input is needed before work completes.','architect;qa','C in RACI; two-way communication.'),
 'informed':('Roles who receive the result or decision.','rte;business_owner','I in RACI; normally one-way updates.'),
 'evidence_needed':('Specific verifiable information required before a control decision.','Current QA report and passed test run','Do not treat a report summary alone as independently verified.'),
 'decision_title':('What the assigned human must confirm or approve.','Confirm technical integration readiness','Decision authority must match the role.'),
 'decision_action':('Whether the role approves confirms or attests evidence.','attest','Not all actions authorize funding or a release.'),
 'mandatory':('Whether this control blocks the current stage.','true','Depends on initiative risk and policy.'),
 'condition':('When this role decision applies.','When external integrations exist','Do not request irrelevant approvals.'),
 'role':('Organizational role accountable for the control.','qa','Login determines who may take the action.'),
 'stage':('Current step in the portfolio-to-operations lifecycle.','quality','Approval is valid only for its recorded stage and evidence.'),
 'requirement':('What the solution must do or enforce.','Reject incomplete payroll detail','Write clear observable behavior.'),
 'requirement_type':('Classifies functional nonfunctional or control need.','functional','Keep one testable obligation per requirement.'),
 'acceptance_criteria':('Observable conditions for accepting a requirement.','Missing FEIN shows a validation error','Link each criterion to a test or reviewed evidence.'),
 'requirement_id':('Stable ID linking the requirement to tests and artifacts.','REQ-WC-001','Use this ID across BRD PRD tests and release evidence.'),
 'rule_description':('Full explanation of a business decision rule.','Route prohibited class to human underwriting','Specify exceptions and decision authority.'),
 'negative_case':('What must happen when the rule is not satisfied.','Incomplete submission blocks quote','Test failure paths as well as success.'),
 'human_decision_required':('Whether a qualified person must make the final choice.','true','Do not let AI self-authorize regulated decisions.'),
 'data_type':('Allowed type of a business field.','date','Define precision format and allowed values.'),
 'field_name':('Name used to identify a field in a data contract.','policy_effective_date','Prefer stable and unambiguous names.'),
 'business_entity':('Business record that owns this field.','Policy','Distinguish system record from display label.'),
 'is_required':('Whether input must exist before the workflow can continue.','true','Validate at the appropriate boundary.'),
 'system_of_record':('Authoritative application for this specific fact.','Policy administration platform','The platform links to source data; it does not replace every source.'),
 'classification':('Sensitivity of the field.','confidential','Use classification to control visibility and transmission.'),
 'validation':('Rule applied to ensure data is usable.','FEIN format and nonempty value','Validate both syntax and business meaning.'),
 'source_system':('System providing information for this interface.','Broker portal','Specify ownership and delivery guarantees.'),
 'target_system':('System receiving information from this interface.','Policy administration','Define failures and retries.'),
 'integration_style':('Integration method for exchanging information.','REST API','Use approved enterprise integration standards.'),
 'direction':('Whether data flows into out of or both ways across an interface.','inbound','Avoid ambiguous data ownership.'),
 'idempotency_policy':('Rule preventing duplicate processing during retries.','Unique submission ID','Mandatory for sensitive write and payment workflows.'),
 'failure_response':('Expected handling when the integration fails.','Retry then route to support queue','Include alerting and recovery ownership.'),
 'test_type':('Kind of validation being performed.','integration','Cover contract rules security and regression.'),
 'scenario':('Short description of the test situation.','Payroll class code missing','Include expected and negative behavior.'),
 'expected_result':('What a passing test must observe.','Submission is blocked; reason is shown','Do not write only "works as expected".'),
 'execution_status':('Whether the test was actually executed.','not_run','Only a real test run may change this to passed.'),
 'test_evidence_ref':('Link to the executed test logs or test artifact.','CI-2026-11-17-53','No result should be claimed without evidence.'),
 'likelihood':('How likely a risk is before mitigation.','medium','Use an agreed scoring scale.'),
 'impact':('How severe the risk consequence would be.','high','Include business or regulatory harm.'),
 'mitigation':('Steps to prevent or reduce a risk.','Add validation and independent regression tests','Name a human action owner.'),
 'risk_statement':('Cause and consequence of a potential failure.','Incorrect rule may reject eligible risks','Write more than a short label.'),
 'external_system':('System or partner on which progress depends.','Claims administration','List the provider and needed-by date.'),
 'needed_for':('Deliverable blocked until this dependency is satisfied.','Claims reserve integration testing','Link to critical milestones where possible.'),
 'delivery_condition':('Observable requirement for closing the dependency.','Sandbox API approved and available','Avoid subjective completion criteria.'),
 'provider_role':('Role supplying a dependency.','integration','A dependency has both provider and consumer.'),
 'raci_code':('One-letter responsibility code: R A C or I.','A','One accountable party for each work item.'),
 'responsibility':('The deliverable or decision assigned to a role.','Validate claim handling rules','Use a verb and tangible deliverable.'),
 'metric_name':('Named KPI used to evaluate benefits.','Median submission-to-quote days','Define process boundary and aggregation.'),
 'measurement_source':('System producing the measured evidence.','Policy workflow timestamp data','Keep source freshness visible.'),
 'measurement_frequency':('How often the outcome is recalculated.','monthly','Do not force daily values for slow-moving outcomes.'),
 'actual_status':('State of measured benefits after deployment.','unmeasured','Never equate forecast to verified actual.'),
 'benefit_owner_role':('Role accountable for sustained business outcome.','value_owner','Project closure does not end benefit ownership.'),
 'control_name':('Named release safeguard.','Rollback validation','Must link to observed evidence.'),
 'acceptance_requirement':('Condition required before releasing.','Rollback tested in staging','Define who confirms the check.'),
 'verifier_role':('Role authorized to validate the control.','release','The verifier must inspect source evidence.'),
 'evidence_source':('Where verification results are stored.','Deployment log and test run','Prefer system-generated evidence.'),
 'verification_status':('Whether a required release control was verified.','pending','Do not automatically turn a planned task green.'),
 'handover_id':('Unique handover action ID.','HAND-WC-01','Allows support teams to find ownership and proof.'),
 'task_name':('Specific operational handover activity.','Publish support runbook','Make completion and owner observable.'),
 'receiving_role':('Team that accepts ongoing operational responsibility.','ops','Handover requires receiver acknowledgment.'),
 'expected_evidence':('Proof a handover task was completed.','Approved runbook version','Include version and system location.'),
 'completion_status':('Whether the receiving team has accepted the handover task.','pending','An incomplete handover should remain visible.'),
 'sequence':('Order of the process step.','3','Process maps should follow the actual workflow.'),
 'step_name':('Business step performed by a participant.','Validate producer authorization','Use a clear verb and object.'),
 'actor_role':('Role or system performing the step.','underwriter','Keep people and automated actors separate.'),
 'inputs':('Records required to execute the step.','Submission and policy details','Identify required source systems.'),
 'outputs':('Artifacts or state changes produced by the step.','Cleared submission','Next step must know what it receives.'),
 'target_elapsed_hours':('Expected elapsed time for the step in hours.','4','Elapsed includes waiting; note exclusions.'),
 'exception_route':('What happens when the step cannot complete normally.','Route to underwriting review','Assign an owner and escalation path.'),
 'email':('Authorized user email or provider account name.','team@example.org','Do not share credentials in assistance chat.'),
 'password':('Account secret used only for sign-in.','A strong unique password','Never disclose or paste into chat.'),
 'token':('Restricted API token for a permitted connector.','Scoped service token','Use secret storage and minimum permissions.'),
 'repo':('GitHub owner and repository to receive approved artifacts.','example-org/insurance-delivery','Verify destination before publishing.'),
 'base_url':('Approved provider website or API endpoint.','https://example.atlassian.net','Use HTTPS and validate the domain.'),
 'project_key':('Jira project identifier.','INS','Publish only to an approved project.'),
 'space_id':('Confluence destination space identifier.','123456','Check access and document retention.'),
 'tenant_id':('Microsoft Entra directory identifier.','organization tenant ID','Treat connection configuration as restricted.'),
 'client_id':('Registered application identifier for a connector.','Application ID','Do not grant broad tenant-wide permissions.'),
 'client_secret':('Credential for a registered application.','Secret stored securely','Never paste credential values into chat.'),
 'model':('Permitted language model for connected planning assistance.','Approved small language model','Only send information authorized for this connector.'),
 'api_key':('OpenAI API credential configured by an authorized administrator.','API key kept in secret store','Do not paste it into the help chat.'),
}
fin={'budget','annual_benefit','estimated_cost_usd','estimated_annual_benefit_usd','planned_cost_usd','cost_category','cost_id','forecast_status','estimate_basis'}
sc=json.loads((root/'seed/data/schema.json').read_text())
entries=[]
for k,(ex,eg,note) in defs.items(): entries.append((k,ex,eg,note,'finance' if k in fin else 'all'))
# Give every CSV column a general help entry, not only a table-qualified one.
known={k for k,*_ in entries}
for tbl,v in sc.items():
 if not isinstance(v,dict) or 'fields' not in v:continue
 path=root/'seed/data'/f'{tbl}.csv'
 sample=next(csv.DictReader(path.open(encoding='utf8',newline='')), {}) if path.exists() else {}
 for key,typ in v['fields'].items():
  if key in known:continue
  eg=str(sample.get(key,'Example value'))[:110] or 'Example value'
  entries.append((key,f'{key.replace("_"," ").capitalize()} recorded in the {tbl.replace("_"," ")} reference data.',eg,f'Type: {typ}. Link the value to the selected initiative and check it before sign-off.','finance' if tbl=='cost_estimates' else 'all'))
  known.add(key)
for tbl,v in sc.items():
 if not isinstance(v,dict) or 'fields' not in v:continue
 path=root/'seed/data'/f'{tbl}.csv'
 row=next(csv.DictReader(path.open(encoding='utf8',newline='')), {}) if path.exists() else {}
 for key,typ in v['fields'].items():
  ex,eg,note=defs.get(key,(f'The {key.replace("_"," ")} value in the {tbl.replace("_"," ")} reference table.',str(row.get(key,'Example value'))[:110],f'Schema type: {typ}. Keep this field consistent with its linked record.'))
  if not eg:eg=str(row.get(key,'Example value'))[:110]
  entries.append((tbl+'.'+key,ex,eg,note,'finance' if tbl=='cost_estimates' or key in fin else 'all'))
out=root/'seed/help/fields.csv'
with out.open('w',encoding='utf8',newline='') as f:
 writer=csv.writer(f);writer.writerow(['key','explanation','example','note','scope']);writer.writerows(entries)
print('Wrote',len(entries),'field-help entries; unique',len({e[0] for e in entries}))
