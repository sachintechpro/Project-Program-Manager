"""Assemble honest QA evidence from pytest JUnit, Playwright, and local load metrics.
Refuses to fabricate absent results. Run after the three input runs are complete.
"""
import json,xml.etree.ElementTree as ET,datetime,csv
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'qa_evidence'
xml=ET.parse(OUT/'pytest_junit.xml').getroot()
raw=xml.findall('.//testcase')
assert len(raw)>=34,'Expected full backend regression, found only '+str(len(raw))
browser=json.loads((OUT/'browser_results.json').read_text());assert len(browser['tests'])>=38
perf=json.loads((OUT/'performance_results.json').read_text());assert len(perf['results'])>=3

areas={
 'test_workflows':'Lifecycle, contracts and approvals',
 'test_role_matrix':'Role-based access and security',
 'test_reference_and_controls':'Insurance data and role controls',
 'test_value_maps':'Value stream mapping',
 'test_vsm_review_graphics':'Value map review and graphics',
 'test_context_help':'Role-aware contextual help',
 'test_management_registers':'RACI / RAID governance',
 'test_raci_display_assignments':'RACI roles and display',
 'test_qa_bench':'QA evidence and Go-No-Go',
}
cases=[]
for i,node in enumerate(raw,1):
 name=node.get('name') or 'unnamed';orig=(node.get('classname') or '').split('.')[-1]
 area=areas.get(orig,'Backend functional regression')
 failure=node.find('failure') or node.find('error');skip=node.find('skipped')
 result='fail' if failure is not None else 'not_run' if skip is not None else 'pass'
 cases.append({'id':f'API-{i:03d}','area':area,'name':name.replace('test_','').replace('_',' ').capitalize(),
 'steps':f'Execute tests/{orig}.py::{name}; validate API status, domain state, and documented assertions.',
 'method':'automated','status':result,'evidence':f'pytest JUnit · {orig}::{name}',
 'duration_seconds':round(float(node.get('time') or '0'),3)})

cases.extend(browser['tests'])
for i,p in enumerate(perf['results'],1):
 cases.append({'id':f'LOAD-{i:03d}','area':'Local API performance / reliability','name':p['name'],
 'steps':f"Send {p['requests']} GETs at concurrency {p['concurrency']}; require no HTTP errors and p95 <= {p['target_p95_ms']} ms (project-defined SLO).",
 'method':'automated','status':p['result'],'evidence':f"Local ASGI run: p95 {p['p95_ms']} ms; {p['throughput_rps']} RPS; {p['errors']} errors",
 'duration_seconds':p['duration_seconds']})

# Manual screenshots inspected; note visual-only scope and evidence.
for device in ('desktop','mobile'):
 path=OUT/f'qa_bench_{device}.png'
 if not path.is_file():raise RuntimeError('Screenshot not found: '+str(path))
 cases.append({'id':'MAN-'+('001' if device=='desktop' else '002'),'area':'Visual exploratory inspection',
 'name':f'{device.title()} QA bench visual review','steps':'Open screenshot and inspect Ternstone typography, card hierarchy, table legibility and navigation layout.',
 'method':'manual','status':'pass','evidence':'qa_evidence/'+path.name+' (visually inspected)'})

providers=['GitHub','Jira Cloud','Confluence Cloud','Microsoft SharePoint','OpenAI']
for n,p in enumerate(providers,1):
 cases.append({'id':f'EXT-{n:03d}','area':'External provider integrations','name':f'Live {p} authentication and write/readback',
 'steps':'Connect authorized sandbox credentials; verify scoped access, write, readback, error path and rollback.',
 'method':'manual','status':'blocked','evidence':'No approved live provider secrets/sandbox available; simulated workflow tested locally'})

notrun=[
 ('PERF-101','Field Web Vitals LCP 75th percentile','Measure p75 page loads across representative real mobile sessions; compare to 2.5 s.'),
 ('PERF-102','Field Web Vitals INP 75th percentile','Measure p75 real user interactions; compare to 200 ms.'),
 ('PERF-103','Field Web Vitals CLS 75th percentile','Measure p75 real page load stability; compare to 0.1.'),
 ('PERF-104','Production load and cold-start soak','Measure staging service at agreed concurrency over a defined soak window with safe external traffic budgets.'),
 ('REL-101','Production availability and disaster recovery','Run multi-day availability checks, failover, database restore and backup recovery in managed infrastructure.'),
 ('SEC-101','External penetration and security assessment','Perform authorized independent AppSec assessment and remediate verified findings.'),
]
for id,name,steps in notrun:
 cases.append({'id':id,'area':'Production readiness gaps','name':name,'steps':steps,'method':'manual','status':'not_run','evidence':'No production instrumentation/approval available'})

summary={'total':len(cases),'passed':sum(x['status']=='pass' for x in cases),'failed':sum(x['status']=='fail' for x in cases),'blocked':sum(x['status']=='blocked' for x in cases),'not_run':sum(x['status']=='not_run' for x in cases)}
suites=defaultdict(lambda:{'pass':0,'fail':0,'blocked':0,'not_run':0})
for t in cases:suites[t['area']][t['status']]+=1
components=[{'area':area,**d,'scope':'Measured scenarios and documented exceptions'} for area,d in suites.items()]
metrics=[]
for p in perf['results']:
 metrics.append({'name':p['name']+' p95', 'unit':'ms','measured':p['p95_ms'],
 'target':f"≤{p['target_p95_ms']} ms (project-defined, local)", 'result':p['result'],
 'scope':f"{p['requests']} local GETs, concurrency {p['concurrency']}; {p['throughput_rps']} RPS, {p['errors']} errors"})
for name,unit,target in [('LCP p75','s','≤2.5 s (Google Web Vitals)'),('INP p75','ms','≤200 ms (Google Web Vitals)'),('CLS p75','score','≤0.1 (Google Web Vitals)'),('Availability (30d)','%','99.9% example SLO (requires monitoring)')]:
 metrics.append({'name':name,'unit':unit,'measured':None,'target':target,'result':'not_run','scope':'Not measured from production/browser field telemetry'})

integrations=[{'name':p,'method':'Simulated provider API checks and negative-path tests where applicable; no live writes','status':'blocked','note':'Real provider roundtrip unverified'} for p in providers]
pytest_duration=float(xml.find('.//testsuite').get('time','0'))
browser_duration=float(browser.get('duration_seconds',0))
perf_duration=sum(float(p['duration_seconds']) for p in perf['results'])
wall_seconds=round(pytest_duration+browser_duration+perf_duration,2)
completed=datetime.datetime.now(datetime.timezone.utc)
started=completed-datetime.timedelta(seconds=wall_seconds)
release='TERNSTONE-2026-11-17-QA-FINAL-R1'
report={
 'release_id':release,
 'environment':'isolated Linux test container; FastAPI TestClient + Chromium 1365px/390px + local ASGI HTTPX',
 'methodology':'Automated API/governance regression, desktop/mobile UI via in-process browser bridge, local bounded read load, visual screenshot review',
 'caveat':'Results are measured locally and limited to the stated cases. The public Render deployment and third-party live connectors require separate acceptance evidence.',
 'demo_readiness':'PASS' if summary['failed']==0 and summary['passed']>30 else 'FAIL',
 'counts':summary,'tests':cases,'components':components,'metrics':metrics,'integrations':integrations,
 'strategy':'Risk-based smoke, functional, integration-contract simulation, RBAC/CSRF, complete eight-gate delivery, RACI/RAID, all six mapped value streams, usability/responsive layouts, bounded API load, and honest evidence segregation.',
 'entry_exit':['All critical in-scope automated regression tests pass; no unexpected server errors',
 '29 role definitions and security boundaries covered by backend policies and regression tests',
 'All six value stream maps tested in desktop and mobile browser simulation',
 'Test Bench sign-off restricted to QA Lead and Release Manager, with CSRF and audited decisions',
 'No-GO for production until managed DB/SSO/real integrations/monitoring and security assessment are complete'],
 'adequacy':f"{summary['passed']} executed cases passed across {len(components)} component groups, with 6 map flows, multiple role-specific negative paths and desktop/mobile screens. {summary['blocked']} external integration scenarios blocked; {summary['not_run']} production criteria not executed. No unsampled paths are claimed fully tested.",
 'gaps':['Live external provider authentication, writes, readback, and failure handling remain unverified.',
 'Free-tier SQLite storage is ephemeral; restart/restore/reliability are not enterprise-grade.',
 'No real insurer transaction data; business KPIs and approvals are modeled examples.',
 'Real browser field Web Vitals, multi-day availability and capacity stress tests are not measured.',
 'No independent penetration test, SSO/MFA or multi-tenant segregation certification.',
 'No verified end-to-end live Render browser test due automated browser network restrictions.'],
 'traceability':'Case IDs and linked pytest function references, Playwright evidence, local HTTPX load metrics, PNG screenshots. The environment-specific evidence is packaged with the source release.',
 'started_at':started.isoformat(timespec='seconds'),'completed_at':completed.isoformat(timespec='seconds'),
 'duration_seconds':wall_seconds,
 'duration_note':'Sum of separate measured suite durations; not continuous uptime or a wall-clock service reliability measurement.',
 'run_breakdown_seconds':{'pytest':round(pytest_duration,2),'browser':round(browser_duration,2),'local_bounded_load':round(perf_duration,2)},
 'release_policy':{'demonstration':'Eligible for QA Lead and Release Manager reviews after passing checks','production':'NO-GO: significant infrastructure, integration and security assurance still required'}
}
(OUT/'release_report.json').write_text(json.dumps(report,indent=2))
(ROOT/'seed/qa/release_report.json').write_text(json.dumps(report,indent=2))
with (OUT/'test_results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['id','area','name','steps','method','status','evidence']);w.writeheader();w.writerows([{k:t.get(k,'') for k in w.fieldnames} for t in cases])
with (OUT/'performance_metrics.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['name','measured','unit','target','result','scope']);w.writeheader();w.writerows(metrics)
lines=['# Ternstone ValueOps — Final QA Execution and Go/No-Go Record','',
 f'**Release:** {release}','',f'**Environment:** {report["environment"]}','',
 f'**Run completed:** {completed.isoformat(timespec="seconds")}', '',
 f'**Executed / status:** {summary["passed"]} pass, {summary["failed"]} fail, {summary["blocked"]} blocked, {summary["not_run"]} not run, {summary["total"]} recorded cases', '',
 f'**Summed measured execution duration:** {wall_seconds} sec (pytest {pytest_duration:.2f}s; browser {browser_duration:.2f}s; local load {perf_duration:.2f}s).','',
 '## Decision','', '**Demonstration: GO candidate, subject to independent QA Lead and Release Manager sign-offs in the application.**', '',
 '**Actual insurer production: NO-GO.** Real provider integrations, persistent database, SSO/MFA, security review, DR/backup verification, production load and availability evidence are missing.','',
 '## Scope and evidence','',report['strategy'],'',
 '| Area | Passed | Failed | Blocked | Not run |','|---|---:|---:|---:|---:|']
for x in components:lines.append(f"| {x['area']} | {x['pass']} | {x['fail']} | {x['blocked']} | {x['not_run']} |")
lines+=['','## Measured local performance and comparison to explicitly scoped SLOs','', '| Test | p95 (ms) | Proposed local target | Requests | Concurrent readers | Errors |','|---|---:|---:|---:|---:|---:|']
for p in perf['results']:lines.append(f"| {p['name']} | {p['p95_ms']} | {p['target_p95_ms']} | {p['requests']} | {p['concurrency']} | {p['errors']} |")
lines+=['','The API targets above are project-specific, not insurance industry medians. Google Core Web Vitals recommends p75 LCP ≤2.5 seconds, INP ≤200 milliseconds and CLS ≤0.1; these browser field metrics have **not** been measured for this public site. A 99.9% availability goal is only a proposed target and was **not** verified.','',
 '## Reviewers and decision rights','',
 'QA Lead: can issue demo GO/NO-GO/Request Evidence for this report. Release Manager: separate, independently recorded demo decision. Program Manager and Platform Admin cannot sign for either. All decisions are audited, tied to report ID, and never grant production authorization.','',
 '## Known residual risks',''] + ['- '+x for x in report['gaps']]+['','## Source evidence','', '- `qa_evidence/pytest_junit.xml` — backend cases','- `qa_evidence/browser_results.json` — browser journeys','- `qa_evidence/qa_bench_desktop.png` / `qa_bench_mobile.png` — UI captures','- `qa_evidence/performance_results.json` — local load metrics','- `qa_evidence/test_results.csv` — test case matrix', '- `qa_evidence/performance_metrics.csv` — target comparisons','',
 'Published general references: https://web.dev/articles/vitals ; https://sre.google/sre-book/service-level-objectives/ ; https://owasp.org/projects/api-security-project/','']
(ROOT/'docs/RELEASE_QA.md').write_text('\n'.join(lines))
print('REPORT',json.dumps({'release_id':release,'counts':summary,'duration_seconds':wall_seconds,'pytest':pytest_duration,'browser':browser_duration,'performance':perf_duration}))
