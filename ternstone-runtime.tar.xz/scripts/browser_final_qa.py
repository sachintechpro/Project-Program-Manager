"""Actual browser UI against FastAPI TestClient through an isolated, in-process bridge.
No public URL or third-party services are hit. This is not a live Render browser test.
"""
import os, json, time, re
from pathlib import Path
os.environ['DEMO_MODE']='true';os.environ['SECRET_KEY']='browser-final-qa';os.environ['DATABASE_URL']='sqlite:///./qa_browser_bridge.db'
from fastapi.testclient import TestClient
from playwright.sync_api import sync_playwright
from app.main import app

BASE=Path(__file__).resolve().parent.parent
HTML=(BASE/'app/static/index.html').read_text(encoding='utf-8')
HTML=re.sub(r'<script src="/assets/[^"]+"></script>','',HTML)
HTML=HTML.replace('<link rel="stylesheet" href="/assets/style.css">','')
RESULTS=[];ERRORS=[];SUITE_START=time.perf_counter()

def record(name,passed,detail=''):
    RESULTS.append({'id':f'UI-{len(RESULTS)+1:03d}','area':'Browser UX / Accessibility','name':name,'method':'automated','status':'pass' if passed else 'fail','steps':'Render app with real FastAPI responses; follow controls; assert visible state, navigation, and no JS errors','evidence':detail or 'Playwright Chromium 1280/390px via in-process API bridge'})
    print(('PASS' if passed else 'FAIL'),name,detail)

with TestClient(app) as client, sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    try:
        for width,height,device in [(1365,840,'desktop'),(390,844,'mobile')]:
            client.cookies.clear()
            page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
            page.on('pageerror',lambda exc:ERRORS.append(str(exc)))
            def bridge(source,url,opts=None):
                opts=opts or {};method=(opts.get('method') or 'GET').upper();payload=opts.get('body');headers=opts.get('headers') or {}
                r=client.request(method,url,content=payload,headers=headers)
                try:body=r.json()
                except:body={}
                return {'status':r.status_code,'body':body}
            page.expose_binding('__apiBridge',bridge)
            page.set_content(HTML,wait_until='domcontentloaded')
            page.evaluate("""window.EventSource = class {constructor(){this.onmessage=null;} close(){}};
window.fetch = async (url,options={})=>{const obj=await window.__apiBridge(String(url),{method:options.method||'GET',body:options.body||null,headers:options.headers||{}});return {ok:obj.status>=200&&obj.status<300,status:obj.status,json:async()=>obj.body};};""")
            page.add_style_tag(content=re.sub(r'^@import[^;]+;', '', (BASE/'app/static/style.css').read_text()))
            for file in ('qa_bench.js','map_ui.js','app.js'):
                page.add_script_tag(content=(BASE/'app/static'/file).read_text())
            page.wait_for_selector('#login-personas button',timeout=30000)
            record(f'{device}: welcome and persona picker',page.locator('#login-personas button').count()>=20)
            # Login through actual API-backed UI
            page.locator('#login-personas button[data-role="program_manager"]').click()
            page.wait_for_selector('#shell:not(.hidden)',timeout=30000)
            record(f'{device}: program manager dashboard',page.locator('#page-title').inner_text()=='Overview')
            if device=='mobile':
                page.locator('#menu-toggle').click()
                record('mobile: sidebar opens',page.locator('#sidebar').evaluate("e=>e.classList.contains('open')"))
            bench=page.locator('button.qa-bench-link')
            record(f'{device}: test bench at bottom of left sidebar',bench.count()==1 and bool(bench.get_attribute('data-page')))
            bench.scroll_into_view_if_needed();bench.click()
            page.wait_for_function("document.querySelector('#page-title').textContent==='QA Test Bench'",timeout=30000)
            record(f'{device}: QA bench report loads',page.locator('text=Independent Go–No-Go decisions').count()>0)
            record(f'{device}: sidebar hidden after navigation',not page.locator('#sidebar').evaluate("e=>e.classList.contains('open')"))
            page.locator('[data-qa-smoke]').click()
            page.wait_for_function("document.querySelector('#qa-live-box')?.textContent.includes('Database query')",timeout=30000)
            record(f'{device}: live smoke check', 'PASS' in page.locator('#qa-live-box').inner_text())
            record(f'{device}: release status shows prod NO-GO', page.get_by_text('Production release readiness').count()>0 and page.locator('text=NO-GO').count()>0)
            record(f'{device}: restricted PM cannot sign QA',page.locator('[data-qa-sign]').count()==0)
            page.locator('#qa-filter').select_option('not_run')
            record(f'{device}: evidence filter works',page.locator('#qa-rows tr').count()>=1)
            # Roles: QA Lead sees only own signoff, release role sees own.
            page.locator('#persona-switch').select_option('qa')
            page.wait_for_function("document.querySelector('#role-current').textContent.toLowerCase().includes('tessa')",timeout=30000)
            (page.locator('#menu-toggle').click() if device=='mobile' and not page.locator('#sidebar').evaluate("e=>e.classList.contains('open')") else None); page.locator('.qa-bench-link').scroll_into_view_if_needed();page.locator('.qa-bench-link').click()
            page.wait_for_selector('[data-qa-sign]',timeout=30000)
            record(f'{device}: QA lead role-specific signoffs',page.locator('[data-qa-role="qa"]').count()==3 and page.locator('[data-qa-role="release"]').count()==0)
            page.locator('#persona-switch').select_option('release')
            page.wait_for_function("document.querySelector('#role-current').textContent.toLowerCase().includes('rowan')",timeout=30000)
            (page.locator('#menu-toggle').click() if device=='mobile' and not page.locator('#sidebar').evaluate("e=>e.classList.contains('open')") else None); page.locator('.qa-bench-link').scroll_into_view_if_needed();page.locator('.qa-bench-link').click()
            page.wait_for_selector('[data-qa-sign]',timeout=30000)
            record(f'{device}: release manager role-specific signoffs',page.locator('[data-qa-role="release"]').count()==3 and page.locator('[data-qa-role="qa"]').count()==0)
            # Check value maps: program manager can view all six maps.
            page.locator('#persona-switch').select_option('program_manager')
            page.wait_for_function("document.querySelector('#role-current').textContent.toLowerCase().includes('drew')",timeout=30000)
            page.locator('button[data-page="streams"]').first.evaluate('(el)=>el.click()')
            page.wait_for_selector('[data-map-stream]',timeout=30000)
            map_buttons=page.locator('[data-map-stream]');map_ids=list(dict.fromkeys(map_buttons.evaluate_all('(els)=>els.map(e=>e.dataset.mapStream)')))
            record(f'{device}: six value streams available',len(map_ids)>=6)
            for sid in map_ids[:6]:
                page.locator('[data-map-stream="'+sid+'"]').first.evaluate('(el)=>el.click()')
                page.wait_for_function("document.querySelector('#page-title').textContent==='Value stream map'",timeout=30000)
                page.wait_for_timeout(100)
                txt=page.locator('#view').inner_text()
                record(f'{device}: map {sid} renders',bool('Define Value' in txt or 'Define value' in txt or 'CUSTOMER VALUE' in txt),f'Value stream id {sid}')
                page.locator('button[data-page="streams"]').first.evaluate('(el)=>el.click()')
                page.wait_for_selector('[data-map-stream]',timeout=30000)
            # Final screenshot, representative, no data changes
            (page.locator('#menu-toggle').click() if device=='mobile' and not page.locator('#sidebar').evaluate("e=>e.classList.contains('open')") else None); page.locator('.qa-bench-link').scroll_into_view_if_needed();page.locator('.qa-bench-link').click()
            page.wait_for_selector('.qa-bench',timeout=30000)
            folder=BASE/'qa_evidence';folder.mkdir(exist_ok=True)
            page.screenshot(path=str(folder/f'qa_bench_{device}.png'),full_page=True)
            page.close()
    finally:browser.close()

record('Browser JavaScript exception scan',len(ERRORS)==0,'; '.join(ERRORS[:4]) if ERRORS else 'No uncaught JS exceptions')
output={'tests':RESULTS,'exceptions':ERRORS,'duration_seconds':round(time.perf_counter()-SUITE_START,2),'source':'Chromium browser against real FastAPI TestClient via local transport bridge; no live Render requests'}
(BASE/'qa_evidence').mkdir(exist_ok=True)
(BASE/'qa_evidence/browser_results.json').write_text(json.dumps(output,indent=2))
print(json.dumps({'total':len(RESULTS),'pass':sum(t['status']=='pass' for t in RESULTS),'fail':sum(t['status']=='fail' for t in RESULTS),'exceptions':ERRORS}))
if ERRORS or any(t['status']=='fail' for t in RESULTS):raise SystemExit(2)
