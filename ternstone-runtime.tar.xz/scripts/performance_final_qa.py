"""Bounded, local ASGI performance and reliability check. Never hit a public service.
Runs only GET requests and produces measured evidence; not a production load certification.
"""
import os,asyncio,time,statistics,math,json
from pathlib import Path
os.environ['DEMO_MODE']='true';os.environ['SECRET_KEY']='qa-load-local';os.environ['DATABASE_URL']='sqlite:///./qa_load.db'
from fastapi.testclient import TestClient
import httpx
from app.main import app
ROOT=Path(__file__).resolve().parent.parent

def percentile(values,p):
    s=sorted(values);return round(s[min(len(s)-1,max(0,math.ceil(p*len(s))-1))]*1000,2) if s else None

async def scenario(client,name,urls,concurrency,target_p95_ms):
    sem=asyncio.Semaphore(concurrency)
    timings=[];errors=[];codes={};start=time.perf_counter()
    async def call(idx,url):
        async with sem:
            a=time.perf_counter()
            try:
                r=await client.get(url,timeout=10)
                t=time.perf_counter()-a
                timings.append(t);codes[r.status_code]=codes.get(r.status_code,0)+1
                if r.status_code!=200: errors.append(f'{idx}: {r.status_code}')
            except Exception as exc:
                errors.append(f'{idx}: {type(exc).__name__}')
    await asyncio.gather(*(call(i,u) for i,u in enumerate(urls)))
    elapsed=time.perf_counter()-start
    p95=percentile(timings,.95)
    return {'name':name,'requests':len(urls),'concurrency':concurrency,'duration_seconds':round(elapsed,2),
        'throughput_rps':round(len(urls)/elapsed,1),'p50_ms':percentile(timings,.5),'p95_ms':p95,'p99_ms':percentile(timings,.99),
        'errors':len(errors),'http_codes':codes,'error_sample':errors[:3],
        'target_p95_ms':target_p95_ms,'result':'pass' if not errors and p95 is not None and p95<=target_p95_ms else 'fail'}

with TestClient(app) as session:
    login=session.post('/api/login',json={'role':'program_manager'})
    assert login.status_code==200
    cookie=session.cookies.get('ternstone_session')
    assert cookie
    async def main():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://qa-local',cookies={'ternstone_session':cookie}) as cl:
            for url in ('/health','/api/public','/api/streams','/api/qa/report'):
                r=await cl.get(url);assert r.status_code==200,(url,r.status_code)
            a=await scenario(cl,'Local API load · 8 concurrent readers', ['/api/streams','/api/initiatives','/api/qa/report','/health']*80,8,900)
            b=await scenario(cl,'Local API burst · 16 concurrent readers', ['/api/streams','/api/qa/report','/api/summary','/health']*60,16,1500)
            c=await scenario(cl,'Local health endurance sample · 500 queries', ['/health']*500,8,500)
            return [a,b,c]
    findings=asyncio.run(main())
    (ROOT/'qa_evidence').mkdir(exist_ok=True)
    (ROOT/'qa_evidence/performance_results.json').write_text(json.dumps({'scope':'Local ASGI in-process; not network, Render, or real insurer workload', 'results':findings},indent=2))
    for x in findings:print(x)
    if any(x['result']=='fail' for x in findings):raise SystemExit('Local performance SLO violation; investigate before demonstration GO')
