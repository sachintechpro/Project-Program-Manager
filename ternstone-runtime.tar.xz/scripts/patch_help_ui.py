from pathlib import Path
root=Path(__file__).resolve().parents[1]
js=root/'app/static/app.js'
s=js.read_text()
assert "function contextualHelpInstall" not in s
s=s.replace("S.catalog=await api('/api/catalog');showShell();await render()", "S.catalog=await api('/api/catalog');S.help=await api('/api/help/catalog');showShell();await render()")
s=s.replace("S.catalog=await api('/api/catalog');showShell();await route('dashboard')", "S.catalog=await api('/api/catalog');S.help=await api('/api/help/catalog');showShell();await route('dashboard')")
s=s.replace("function showSignin(){ if(live)","function showSignin(){if($('help-launch'))$('help-launch').classList.add('hidden');if($('help-drawer'))$('help-drawer').classList.add('hidden'); if(live)")
s=s.replace("function showShell(){ $('signin')", "function showShell(){if($('help-launch'))$('help-launch').classList.remove('hidden');if($('help-header-button'))$('help-header-button').classList.remove('hidden'); $('signin')")
s=s.replace("const a=x.artifact;const i=x.initiative;const detail=", "const a=x.artifact;const i=x.initiative;S.helpContractInit=i.id;const detail=")
# Label helper is safe (tooltip metadata never contains record values).
s=s.replace('function field(name,label,value=', 'function field(name,label,value=')  # no signature change
s=s.replace('function field(name,label,value=\'\',type=\'text\',span=false,extra=\'\'){return `<label class="field ${span?\'span2\':\'\'}">${label}<input',
'''function field(name,label,value='',type='text',span=false,extra=''){return `<label class="field ${span?'span2':''}">${label}${helpDot(name,label)}<input''')
s=s.replace('function area(name,label,value=\'\',span=true){return `<label class="field ${span?\'span2\':\'\'}">${label}<textarea',
'''function area(name,label,value='',span=true){return `<label class="field ${span?'span2':''}">${label}${helpDot(name,label)}<textarea''')
# Add a permanent launcher, drawer and keyboard controls outside view so render cannot destroy chat history.
html=root/'app/static/index.html'
h=html.read_text()
assert '<div id="help-drawer"' not in h
h=h.replace('<button class="icon-btn" id="refresh-btn"', '<button class="icon-btn" id="help-header-button" aria-label="Open contextual help" title="Help for this page">? Help</button><button class="icon-btn" id="refresh-btn"')
ui='''<button id="help-launch" type="button" class="help-launch hidden" aria-label="Open your role-aware work assistant" aria-controls="help-drawer" aria-expanded="false">? <span>Work assistant</span></button>
<section id="help-drawer" class="help-drawer hidden" role="dialog" aria-modal="false" aria-labelledby="help-title">
  <div class="help-top"><div><div class="help-overline">CONTEXTUAL WORK GUIDE</div><h2 id="help-title">Your work assistant</h2><div id="help-context" class="help-context"></div></div><button id="help-close" class="help-close" aria-label="Close assistant">×</button></div>
  <div class="help-page-info" id="help-page-info"></div>
  <div id="help-messages" class="help-messages" aria-live="polite" aria-relevant="additions text"></div>
  <div id="help-suggestions" class="help-suggestions"></div>
  <form id="help-form" class="help-form"><label for="help-question" class="sr-only">Ask about this page or your assigned work</label><textarea id="help-question" maxlength="600" rows="2" placeholder="Ask what to do next, explain a field, or check an approval…" required></textarea><div class="help-compose"><label id="help-ai-wrap" class="help-ai-choice hidden"><input type="checkbox" id="help-ai"> Use connected AI</label><span id="help-mode-note" class="help-mode-note">Guided answers · read-only</span><button class="btn primary sm" type="submit" id="help-send">Ask ↗</button></div></form>
  <div class="help-footnote">Advice only. Use the approved forms to make changes or record decisions. Do not enter credentials or sensitive customer data.</div>
</section>
'''
h=h.replace('<div id="toast" class="toast"',ui+'<div id="toast" class="toast"')
h=h.replace('<script src="/assets/app.js"></script>','<script src="/assets/app.js"></script>')
html.write_text(h)

# Implement assistant inside app's closure to reuse current session, route, role & initiative.
marker="function fillFields(form,x)"
assert marker in s
module=r'''// Context help is an assistive, read-only view over the authenticated role's available data.
let helpChat=[],helpFocused='',helpScheduled=false,helpWorking=false;
function helpKey(name){return String(name||'').toLowerCase().replace(/[^a-z0-9_]+/g,'_').replace(/^_|_$/g,'')}
function helpDot(key,label){const entry=S.help?.fields?.[key]||S.help?.fields?.[helpKey(key)]||S.help?.fields?.[helpKey(label)];if(!entry)return '';return `<button class="help-dot" type="button" data-help-field="${H(key)}" aria-label="Explain ${H(label)}" title="${H(entry.explanation)}">?</button>`}
function getHelpInit(){if(S.page==='initiative')return Number(S.initiative)||null;if(S.page==='contract')return Number(S.helpContractInit)||null;if(S.page==='reference')return Number(S.referenceInitiative)||null;if((S.page==='raci'||S.page==='raid')&&S.regScope?.initiative_id)return Number(S.regScope.initiative_id);return null}
function helpOpen(field='',prompt=''){
 if(!S.user)return;
 helpFocused=field||'';
 $('help-drawer').classList.remove('hidden');$('help-launch').setAttribute('aria-expanded','true');
 helpContextUpdate();
 if(field){
  const ent=S.help?.fields?.[field]||S.help?.fields?.[helpKey(field)];
  if(ent){helpAppend('assistant',ent.explanation+'\nExample: '+ent.example+'\n'+ent.note,'Field explanation');helpSuggestions(['What should I do next?','Which evidence is required?']);}
  else if(prompt)helpAsk(prompt,field);
 }
 $('help-question').focus();
}
function helpClose(){$('help-drawer').classList.add('hidden');$('help-launch').setAttribute('aria-expanded','false');$('help-launch').focus()}
function helpAppend(who,message,origin=''){
 helpChat.push({who,message,origin});if(helpChat.length>28)helpChat=helpChat.slice(-28);
 const row=document.createElement('div');row.className='help-message '+(who==='user'?'user':'assistant');
 if(origin){const over=document.createElement('span');over.className='help-message-origin';over.textContent=origin;row.append(over)}
 const body=document.createElement('div');body.className='help-message-text';body.textContent=message;row.append(body);
 $('help-messages').append(row);$('help-messages').scrollTop=$('help-messages').scrollHeight;
}
function helpSuggestions(items){const dst=$('help-suggestions');dst.innerHTML='';for(const x of items.slice(0,4)){const b=document.createElement('button');b.type='button';b.className='help-chip';b.textContent=x;b.dataset.helpPrompt=x;dst.append(b)}}
function helpContextUpdate(){if(!S.user||!S.help)return;
 const page=S.help.pages?.[S.page]||S.help.pages?.dashboard;
 const role=S.help.role||{};
 $('help-context').textContent=`${S.user.role_name} · ${page?.title||S.page}${getHelpInit()?' · INIT-'+getHelpInit():''}`;
 $('help-page-info').textContent=(page?.meaning||'Review your assigned work.')+' '+(role.next_step||'');
 $('help-ai-wrap').classList.toggle('hidden',!S.help.ai_available);
 $('help-mode-note').textContent=S.help.ai_available?'Guided by default · AI optional':'Guided answers · no external AI call';
 if(!$('help-suggestions').children.length)helpSuggestions(['What should I do next?','Explain this page','Which approvals are mine?']);
}
function helpDecorate(){if(!S.user||!S.help)return;const view=$('view');if(!view)return;
 for(const label of view.querySelectorAll('label.field')){
  if(label.querySelector('.help-dot')||label.dataset.helpAnnotated)continue;
  const input=label.querySelector('input,select,textarea');if(!input)continue;
  const key=(input.name||input.id||'').trim();
  const entry=S.help.fields?.[key]||S.help.fields?.[helpKey(key)];
  if(!entry)continue;
  label.dataset.helpAnnotated='yes';
  const dot=document.createElement('button');dot.type='button';dot.className='help-dot';dot.dataset.helpField=key;dot.setAttribute('aria-label','Explain '+key.replaceAll('_',' '));dot.title=entry.explanation;dot.textContent='?';
  label.insertBefore(dot,input);
 }
 // Table header explanations use the same machine-readable CSV field dictionary.
 const tbl=S.page==='reference' ? [...view.querySelectorAll('.grid-heading h2')].map(x=>x.textContent):[];
 for(const th of view.querySelectorAll('th')){
  if(th.querySelector('.help-dot')||th.dataset.helpAnnotated)continue;
  const label=th.textContent.trim();const key=helpKey(label);const entry=S.help.fields?.[key];
  if(!entry)continue;th.dataset.helpAnnotated='yes';const dot=document.createElement('button');dot.type='button';dot.className='help-dot help-inline';dot.dataset.helpField=key;dot.setAttribute('aria-label','Explain '+label);dot.title=entry.explanation;dot.textContent='?';th.append(dot);
 }
 for(const stat of view.querySelectorAll('.stat-label')){
   if(stat.querySelector('.help-dot')||stat.dataset.helpAnnotated)continue;
   const key=helpKey(stat.textContent);const entry=S.help.fields?.[key];if(!entry)continue;
   stat.dataset.helpAnnotated='yes';const dot=document.createElement('button');dot.type='button';dot.className='help-dot help-inline';dot.dataset.helpField=key;dot.title=entry.explanation;dot.setAttribute('aria-label','Explain '+stat.textContent);dot.textContent='?';stat.append(dot);
 }
 if(S.page==='reference'){
   for(const table of view.querySelectorAll('.table-wrap table')){
     const heading=table.previousElementSibling?.querySelector('h2')?.textContent || '';
     // Every CSV column has a schema definition; the general glossary is used if no exact table match exists.
     for(const th of table.querySelectorAll('th')){
       if(th.querySelector('.help-dot'))continue;
       const key=helpKey(th.textContent.trim()),entry=S.help.fields?.[key];if(!entry)continue;
       const dot=document.createElement('button');dot.type='button';dot.className='help-dot help-inline';dot.dataset.helpField=key;dot.title=entry.explanation;dot.setAttribute('aria-label','Explain '+th.textContent);dot.textContent='?';th.append(dot)
     }
   }
 }
 const head=view.querySelector('.page-head');if(head && !view.querySelector('#page-context-help')){
   const row=document.createElement('div');row.id='page-context-help';row.className='page-context-help';
   const pg=S.help.pages?.[S.page]||S.help.pages?.dashboard;
   const words=document.createElement('span');words.textContent=pg?.next_step||'Open a record to view its requirements and evidence.';row.append(words);
   const button=document.createElement('button');button.type='button';button.className='page-help-link';button.textContent='? Help on this page';button.dataset.helpPage='yes';row.append(button);
   head.insertAdjacentElement('afterend',row);
 }
}
function contextualHelpInstall(){
 const view=$('view');const watcher=new MutationObserver(()=>{
  if(helpScheduled||!S.user)return;helpScheduled=true;
  requestAnimationFrame(()=>{helpScheduled=false;helpContextUpdate();helpDecorate()})
 });watcher.observe(view,{childList:true,subtree:true});
 $('help-launch').addEventListener('click',()=>helpOpen());
 $('help-header-button').addEventListener('click',()=>helpOpen());
 $('help-close').addEventListener('click',helpClose);
 $('help-form').addEventListener('submit',ev=>{ev.preventDefault();const q=$('help-question').value.trim();if(q)helpAsk(q,helpFocused)});
 $('help-question').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('help-form').requestSubmit()}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('help-drawer').classList.contains('hidden'))helpClose()});
 document.addEventListener('click',ev=>{
  const t=ev.target.closest('button');if(!t)return;
  if(t.dataset.helpField){ev.preventDefault();ev.stopPropagation();helpOpen(t.dataset.helpField)}
  else if(t.dataset.helpPage){ev.preventDefault();helpOpen();helpAsk('Explain this page')}
  else if(t.dataset.helpPrompt){ev.preventDefault();helpOpen();helpAsk(t.dataset.helpPrompt)}
 });
}
async function helpAsk(question,field=''){
 if(helpWorking)return;helpWorking=true;
 const input=$('help-question');input.value='';$('help-send').disabled=true;
 helpAppend('user',question);
 try{
  const resp=await api('/api/help/chat',{method:'POST',body:{question,page:S.page,field_key:field||'',initiative_id:getHelpInit(),use_ai:!!$('help-ai')?.checked}});
  if(!S.user||resp.role!==S.user.role)return;
  helpAppend('assistant',resp.answer,resp.mode==='connected-ai'?'Connected AI · review before acting':'Guided answer · role-scoped');
  helpSuggestions(resp.followups||[]);
  if(resp.action_page && resp.action_page!==S.page){
   const b=document.createElement('button');b.className='help-chip help-go';b.type='button';b.dataset.page=resp.action_page;b.textContent='Open '+(S.help?.pages?.[resp.action_page]?.title||resp.action_page)+' ↗';$('help-suggestions').append(b)
  }
 }catch(e){helpAppend('assistant','I could not retrieve guidance: '+e.message+'. Your records and approvals were not changed.');}
 finally{helpFocused='';helpWorking=false;$('help-send').disabled=false;input.focus()}
}
'''
s=s.replace(marker,module+'\n'+marker)
s=s.replace("init().catch(e=>{toast(e.message,true);showSignin()});", "contextualHelpInstall();\ninit().catch(e=>{toast(e.message,true);showSignin()});")
js.write_text(s)
print('Updated app.js with contextual field help and chat')
