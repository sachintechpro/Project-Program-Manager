from pathlib import Path
p=Path(__file__).parents[1]/'app'/'main.py';s=p.read_text()
def swap(a,b):
 global s
 if s.count(a)!=1:raise RuntimeError(f'expected one {a[:70]} got {s.count(a)}')
 s=s.replace(a,b)
# Create mirrored KPI summary and a cost breakdown that reconciles exactly to the new initiative budget.
swap("            data['initiative_key']=i.key\n            primary=scenario_schemas()[name]['key']", """            data['initiative_key']=i.key
            if name=='metrics':
                data['baseline_value']=str(i.baseline);data['target_value']=str(i.target);data['metric_unit']=i.unit
            if name=='cost_estimates':
                from .catalog import INIT_MAP as _INIT_MAP
                original=_INIT_MAP[source]['budget'];share=float(data['planned_cost_usd'])/original if original else 0
                data['planned_cost_usd']=str(round(share*i.budget))
            primary=scenario_schemas()[name]['key']""")
swap("    revise_managed(db,user,m,old,init_obj(i));db.commit()", "    sync_reference_summary(db,i,user,old)\n    revise_managed(db,user,m,old,init_obj(i));db.commit()")
# When author changes CSV row, sync the displayed overview with metric/cost source values.
swap("    rec.payload=payload;rec.version+=1;rec.updated_at=now()", """    oldinit=init_obj(i)
    if rec.table_name=='metrics':
        i.baseline=float(req.fields['baseline_value']);i.target=float(req.fields['target_value']);i.unit=req.fields['metric_unit']
        if req.fields['direction']=='decrease' and i.target>=i.baseline:
            raise HTTPException(422,'The target must improve on the baseline for a decrease metric')
    rec.payload=payload;rec.version+=1;rec.updated_at=now()""")
swap("    log(db,user,'reference.revised',f'REF-{rec.id}',{'initiative':i.id,'table':rec.table_name,'version':rec.version,'digest':sha(payload)})", """    if rec.table_name=='cost_estimates':
        costs=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id,ScenarioRecord.table_name=='cost_estimates')).scalars().all()
        i.budget=float(sum(int(json.loads(r.payload)['planned_cost_usd']) for r in costs))
    if rec.table_name in ('metrics','cost_estimates') and oldinit!=init_obj(i):
        m=db.execute(select(ManagedRecord).where(ManagedRecord.resource_type=='initiative',ManagedRecord.resource_id==i.id)).scalar_one_or_none()
        if m:revise_managed(db,user,m,oldinit,init_obj(i))
    log(db,user,'reference.revised',f'REF-{rec.id}',{'initiative':i.id,'table':rec.table_name,'version':rec.version,'digest':sha(payload)})""")
# extra: sum rounding difference goes into first cost record, without changing reference identities
swap("            record=ScenarioRecord(initiative_id=i.id,table_name=name,source_record_id=data[primary],payload=content,author_id=user.id,version=1)", """            record=ScenarioRecord(initiative_id=i.id,table_name=name,source_record_id=data[primary],payload=content,author_id=user.id,version=1)""")
# sum any source cost amounts, assign last adjustment after clones inserted
swap("            db.add(ScenarioRecordRevision(record_id=record.id,version=1,payload=content,digest=sha(content),author_id=user.id))\n\nclass ScenarioEditRequest", """            db.add(ScenarioRecordRevision(record_id=record.id,version=1,payload=content,digest=sha(content),author_id=user.id))
    costs=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id,ScenarioRecord.table_name=='cost_estimates').order_by(ScenarioRecord.id)).scalars().all()
    if costs:
        adjustment=int(i.budget)-sum(int(json.loads(r.payload)['planned_cost_usd']) for r in costs)
        if adjustment:
            last=costs[-1];data=json.loads(last.payload);data['planned_cost_usd']=str(int(data['planned_cost_usd'])+adjustment)
            last.payload=json.dumps(data,sort_keys=True,ensure_ascii=False)
            rev=db.execute(select(ScenarioRecordRevision).where(ScenarioRecordRevision.record_id==last.id,ScenarioRecordRevision.version==1)).scalar_one_or_none()
            if rev:rev.payload=last.payload;rev.digest=sha(last.payload)

def sync_reference_summary(db,i,user,oldinit):
    records=db.execute(select(ScenarioRecord).where(ScenarioRecord.initiative_id==i.id)).scalars().all()
    for rec in records:
        row=json.loads(rec.payload);new=dict(row)
        if rec.table_name=='metrics':
            new['baseline_value']=str(i.baseline);new['target_value']=str(i.target);new['metric_unit']=i.unit
        if rec.table_name=='cost_estimates' and i.budget!=oldinit['budget']:
            old_budget=oldinit['budget'] or 0
            new['planned_cost_usd']=str(int(round(int(row['planned_cost_usd'])*i.budget/old_budget))) if old_budget else row['planned_cost_usd']
        if new!=row:
            content=json.dumps(new,sort_keys=True,ensure_ascii=False);rec.payload=content;rec.version+=1;rec.updated_at=now()
            db.add(ScenarioRecordRevision(record_id=rec.id,version=rec.version,payload=content,digest=sha(content),author_id=user.id))
            log(db,user,'reference.synced_from_initiative',f'REF-{rec.id}',{'version':rec.version})
    costs=[r for r in records if r.table_name=='cost_estimates']
    if costs and i.budget!=oldinit['budget']:
        last=costs[-1];data=json.loads(last.payload);diff=int(i.budget)-sum(int(json.loads(r.payload)['planned_cost_usd']) for r in costs)
        if diff:
            data['planned_cost_usd']=str(int(data['planned_cost_usd'])+diff);last.payload=json.dumps(data,sort_keys=True,ensure_ascii=False);last.version+=1;last.updated_at=now()
            db.add(ScenarioRecordRevision(record_id=last.id,version=last.version,payload=last.payload,digest=sha(last.payload),author_id=user.id))
            log(db,user,'reference.budget_reconciled',f'REF-{last.id}',{'adjustment_usd':diff})

class ScenarioEditRequest""")
p.write_text(s)
# Replace confusing generic REQ-### placeholders: use source-specific IDs in appendix.
q=Path(__file__).parents[1]/'app'/'catalog.py';v=q.read_text()
v=v.replace('- REQ-001: Capture and validate required request and policy context.','- Capture and validate required request and policy context (see linked requirement IDs).')
v=v.replace('- REQ-002: Enforce role-based access, audit every material state transition.','- Enforce role-based access and audit material state transitions.')
v=v.replace('- REQ-003: Apply business rules, preserve exception review by authorized humans.','- Apply business rules with human exception authority.')
v=v.replace('- REQ-004: Publish status changes to dependent stakeholders.','- Publish status changes with traceable correlation identifiers.')
v=v.replace('- REQ-005: Record outcome measurement and trace to investment.','- Record measured outcomes with investment traceability.')
v=v.replace('Each REQ has positive, negative, integration and authorization tests.','Each linked requirement ID has positive, negative, integration and authorization tests.')
v=v.replace('REQ-001 request capture; REQ-002 IAM and audit; REQ-003 business decisions; REQ-004 notifications; REQ-005 telemetry.','Use the initiative-specific requirement IDs recorded in the linked `requirements.csv`; verify each against implementation and test evidence.')
v=v.replace('Approved PRD REQ-001 through REQ-005, business rules and technical contracts.','Approved PRD requirement IDs in the linked `requirements.csv`, business rules and technical contracts.')
q.write_text(v)
print('normalized source, copied records and document requirement IDs')
