from pathlib import Path
p=Path(__file__).parents[1]/'app'/'main.py';s=p.read_text()
def swap(a,b,count=1):
 global s
 n=s.count(a)
 if n!=count:raise AssertionError(f'{a[:70]!r} expected {count}, got {n}')
 s=s.replace(a,b)
swap('from .role_policy import ROLE_DOCS,','from .enterprise_data import preview as scenario_preview, doc_appendix, table as scenario_table, schemas as scenario_schemas\nfrom .control_policy import controls_for\nfrom .role_policy import ROLE_DOCS,')
marker='class Connector(BaseModelDB):'
model='''class ScenarioLink(BaseModelDB):
    __tablename__='scenario_links'
    id=Column(Integer,primary_key=True)
    initiative_id=Column(Integer,ForeignKey('initiatives.id'),unique=True,nullable=False)
    template_key=Column(String(120),nullable=False)
    created_at=Column(DateTime,default=now)

class ControlReview(BaseModelDB):
    __tablename__='role_control_reviews'
    id=Column(Integer,primary_key=True)
    initiative_id=Column(Integer,ForeignKey('initiatives.id'),nullable=False)
    stage=Column(String(50),nullable=False)
    control_code=Column(String(100),nullable=False)
    role=Column(String(80),nullable=False)
    actor_id=Column(Integer,ForeignKey('users.id'),nullable=False)
    actor_name=Column(String(120),nullable=False)
    decision=Column(String(30),nullable=False)
    comment=Column(Text,default='')
    evidence_ref=Column(String(350),default='')
    input_digest=Column(String(64),nullable=False)
    created_at=Column(DateTime,default=now)

'''
swap(marker,model+marker)
swap("db.commit()\n\ndef setup():", "db.commit()\n\ndef setup():") # verify seed boundary only
# backfill source->link for all seeded initiatives on each startup, not replace existing
needle='''            seed_demo(db)
            seed_register_examples(db)
'''
swap(needle,'''            seed_demo(db)
            seed_register_examples(db)
            for base in INITIATIVE_TEMPLATES:
                seeded=db.execute(select(Initiative).where(Initiative.key==base['key'])).scalar_one_or_none()
                if seeded and not db.execute(select(ScenarioLink.id).where(ScenarioLink.initiative_id==seeded.id)).first():
                    db.add(ScenarioLink(initiative_id=seeded.id,template_key=base['key']))
''')
swap("'reviewer':any(any(a[3]==user.role for a in stage['artifacts']) for stage in STAGES)","'reviewer':any(any(a[3]==user.role for a in stage['artifacts']) for stage in STAGES), 'control_reviewer':True")
old="i=Initiative(key=key,value_stream_id=v.id,**req.model_dump(exclude={'stream_id','template'}));db.add(i);db.flush();init_managed_record(db,'initiative',i.id,user,init_obj(i,v));log(db,user,'initiative.created',f'INIT-{i.id}',{'title':i.title,'value_stream':v.name});db.commit();return init_obj(i,v)"
new="""i=Initiative(key=key,value_stream_id=v.id,**req.model_dump(exclude={'stream_id','template'}));db.add(i);db.flush()
    if req.template:
        base=next((x for x in INITIATIVE_TEMPLATES if x['key']==req.template),None)
        if not base:raise HTTPException(422,'Unknown scenario example')
        # Reuse example context only within the matching value stream.
        if base['stream']!=next((x['key'] for x in STREAM_TEMPLATES if x['key']==v.key),None):
            raise HTTPException(422,'Choose an example for the selected value stream')
        db.add(ScenarioLink(initiative_id=i.id,template_key=req.template))
    init_managed_record(db,'initiative',i.id,user,init_obj(i,v));log(db,user,'initiative.created',f'INIT-{i.id}',{'title':i.title,'value_stream':v.name,'example_source':req.template or None});db.commit();return init_obj(i,v)"""
swap(old,new)
swap('''        content=contract_text(kind,init_obj(i),stream_obj(v))''','''        linked=db.execute(select(ScenarioLink).where(ScenarioLink.initiative_id==i.id)).scalar_one_or_none()
        context=doc_appendix(kind,linked.template_key) if linked else ''
        content=contract_text(kind,init_obj(i),stream_obj(v)) + context''')
# Augment review with stage advance helper; controls are required, and previous seeded approvals are not rewritten.
old='''    advanced=False
    if req.decision=='approved':
        required=[a[0] for a in needed(i)]
        all_a=db.execute(select(Artifact).where(Artifact.initiative_id==i.id,Artifact.stage==i.current_stage)).scalars().all()
        if all(any(a.kind==kind and a.status=='approved' for a in all_a) for kind in required):
            old=i.current_stage;i.current_stage=STAGE_IDS[STAGE_IDS.index(old)+1]
            if i.current_stage=='closed':i.status='closed'
            advanced=True
            log(db,user,'initiative.stage_advanced',f'INIT-{i.id}',{'from':old,'to':i.current_stage,'approved_contracts':required})
'''
new='''    advanced=advance_if_ready(db,i,user) if req.decision=='approved' else False
'''
swap(old,new)
swap("    return [{'artifact':artifact_obj(a),'initiative':visible_initiative(i,None,user),'assigned_to_me':a.reviewer==user.role}","    return [{'artifact':artifact_obj(a),'initiative':visible_initiative(i,None,user),'assigned_to_me':a.reviewer==user.role}") # no op

# Insert backend workflow helpers and endpoints before /api/approvals.
anchor="@app.get('/api/approvals')\n"
insert='''def current_input_digest(db,i,stage):
    items=db.execute(select(Artifact).where(Artifact.initiative_id==i.id,Artifact.stage==stage).order_by(Artifact.kind)).scalars().all()
    return sha(json.dumps([(a.kind,a.version,a.hash) for a in items],sort_keys=True))

def latest_control(db,initiative_id,stage,code):
    return db.execute(select(ControlReview).where(ControlReview.initiative_id==initiative_id,ControlReview.stage==stage,ControlReview.control_code==code).order_by(ControlReview.id.desc()).limit(1)).scalar_one_or_none()

def review_state(db,i,v,stage):
    current_digest=current_input_digest(db,i,stage)
    output=[]
    for ctrl in controls_for(stage,i,v):
        last=latest_control(db,i.id,stage,ctrl['control_code'])
        decision=last.decision if last and last.input_digest==current_digest else 'pending'
        output.append({**ctrl,'decision':decision,'comment':last.comment if last else '', 'evidence_ref':last.evidence_ref if last else '', 'reviewed_by':last.actor_name if last else '', 'reviewed_at':utcstr(last.created_at) if last else None,'evidence_current':bool(last and last.input_digest==current_digest),'input_digest':current_digest})
    return output

def advance_if_ready(db,i,user):
    if i.current_stage=='closed':return False
    all_a=db.execute(select(Artifact).where(Artifact.initiative_id==i.id,Artifact.stage==i.current_stage)).scalars().all()
    required=[a[0] for a in needed(i)]
    if not all(any(a.kind==kind and a.status=='approved' for a in all_a) for kind in required):return False
    v=db.get(ValueStream,i.value_stream_id)
    if not all(r['decision']=='approved' for r in review_state(db,i,v,i.current_stage) if r['mandatory']):return False
    old=i.current_stage;i.current_stage=STAGE_IDS[STAGE_IDS.index(old)+1]
    if i.current_stage=='closed':i.status='closed'
    log(db,user,'initiative.stage_advanced',f'INIT-{i.id}',{'from':old,'to':i.current_stage,'approved_contracts':required,'required_controls':[r['control_code'] for r in review_state(db,i,v,old) if r['mandatory']]})
    return True

class ControlDecisionReq(BaseModel):
    decision:str
    comment:str=Field(default='',max_length=2000)
    evidence_ref:str=Field(default='',max_length=350)
    expected_stage:str
    input_digest:str=Field(min_length=64,max_length=64)

@app.get('/api/initiatives/{iid}/control-reviews')
def initiative_control_reviews(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    v=db.get(ValueStream,i.value_stream_id)
    if i.current_stage=='closed':return {'initiative_id':iid,'stage':'closed','controls':[],'outstanding':0}
    controls=review_state(db,i,v,i.current_stage)
    if user.role=='admin':controls=[c for c in controls if c['role']=='admin']
    else:controls=[c for c in controls if c['role']==user.role or user.role in APPROVAL_OVERSIGHT and (can_view_financials(user) or i.current_stage not in ('portfolio','benefits') or c['role'] not in ('finance','lpm','executive','analytics'))]
    for c in controls:c['assigned_to_me']=c['role']==user.role
    return {'initiative_id':iid,'stage':i.current_stage,'controls':controls,'outstanding':sum(c['mandatory'] and c['decision']!='approved' for c in controls),'portfolio_data_hidden':not can_view_financials(user)}

@app.get('/api/control-reviews')
def control_review_inbox(user:User=Depends(get_user),db:Session=Depends(db_session)):
    result=[]
    for i in db.execute(select(Initiative).where(Initiative.current_stage!='closed').order_by(Initiative.id.desc())).scalars().all():
        v=db.get(ValueStream,i.value_stream_id)
        for c in review_state(db,i,v,i.current_stage):
            if c['role']!=user.role:continue
            display='Technical integration provisioning for INIT-'+str(i.id) if user.role=='admin' else i.title
            result.append({'initiative_id':i.id,'initiative_title':display,'value_stream':None if user.role=='admin' else v.name,'stage':i.current_stage,'control':c})
    return result

@app.post('/api/initiatives/{iid}/control-reviews/{code}')
def submit_control_review(iid:int,code:str,req:ControlDecisionReq,request:Request,user:User=Depends(guard),db:Session=Depends(db_session)):
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    if i.current_stage=='closed' or i.current_stage!=req.expected_stage:raise HTTPException(409,'The workflow stage has changed. Refresh and review current work.')
    v=db.get(ValueStream,i.value_stream_id)
    ctrl=next((c for c in controls_for(i.current_stage,i,v) if c['control_code']==code),None)
    if not ctrl:raise HTTPException(404,'Role control is not applicable to this stage or initiative')
    role_required(user,ctrl['role'])
    if req.decision not in ('approved','changes_requested'):raise HTTPException(422,'Decision must be approved or changes_requested')
    digest=current_input_digest(db,i,i.current_stage)
    if req.input_digest!=digest:raise HTTPException(409,'The evidence has changed. Refresh before deciding.')
    available=db.execute(select(Artifact).where(Artifact.initiative_id==iid,Artifact.stage==i.current_stage)).scalars().all()
    if req.decision=='approved' and not all(any(a.kind==kind for a in available) for kind,*_ in needed(i)):
        raise HTTPException(409,'Generate the required stage contracts before confirming readiness.')
    if req.decision=='changes_requested' and len(req.comment.strip())<8:raise HTTPException(422,'Explain what needs correction')
    db.add(ControlReview(initiative_id=i.id,stage=i.current_stage,control_code=code,role=user.role,actor_id=user.id,actor_name=user.name,decision=req.decision,comment=req.comment,evidence_ref=req.evidence_ref,input_digest=digest))
    log(db,user,'control.'+req.decision,f'INIT-{i.id}',{'role':user.role,'control':code,'stage':i.current_stage,'digest':digest,'evidence_ref':req.evidence_ref})
    db.flush();advanced=advance_if_ready(db,i,user);db.commit()
    return {'decision':req.decision,'initiative_id':iid,'stage':req.expected_stage,'advanced':advanced,'next_stage':i.current_stage}

@app.get('/api/reference-catalog')
def reference_catalog(user:User=Depends(get_user)):
    require_business_data_access(user)
    return {'tables':[{'table':t,'columns':list(scenario_schemas()[t]['fields']),'description':scenario_table(t)[0].get('initiative_key','') if scenario_table(t) else ''} for t in scenario_schemas() if not t.startswith('_') and (can_view_financials(user) or t!='cost_estimates')], 'examples':[{'key':x['key'],'title':x['title'],'stream':x['stream']} for x in INITIATIVE_TEMPLATES]}

@app.get('/api/initiatives/{iid}/reference')
def initiative_reference(iid:int,user:User=Depends(get_user),db:Session=Depends(db_session)):
    require_business_data_access(user)
    i=db.get(Initiative,iid)
    if not i:raise HTTPException(404,'Initiative not found')
    link=db.execute(select(ScenarioLink).where(ScenarioLink.initiative_id==iid)).scalar_one_or_none()
    if not link and i.key in INIT_MAP:link=ScenarioLink(initiative_id=iid,template_key=i.key)
    if not link:return {'template_key':None,'tables':{},'counts':{},'example_available':True,'message':'Choose a matching sample scenario when creating a new initiative. Its records become readable reference context for all downstream contracts.'}
    data=scenario_preview(link.template_key,can_view_financials(user))
    data['example_available']=True;data['message']='Illustrative source examples. Test status not_run and unmeasured metrics are not production results.'
    return data

'''
swap(anchor,insert+anchor)
# Inject control reviews into evidence pack (filtered), and manifest for source pack. Raw events remain truthful.
needle="""        for a in arts:
            fm=f'---\\nschema: {a.kind}/v1"""
sub="""        if user.role!='admin':
            for st in STAGES:
                for ctrl in review_state(db,i,db.get(ValueStream,i.value_stream_id),st['id']):
                    if ctrl['role'] in ('finance','lpm','executive','analytics') and not can_view_financials(user):continue
                    if ctrl['reviewed_by']:
                        z.writestr(f'governance/{st["id"]}/{ctrl["control_code"]}.md',
                            '# Role control review\\n\\n- **Stage**: '+st['title']+'\\n- **Control**: '+ctrl['decision_title']+'\\n- **Role**: '+ctrl['role']+'\\n- **Decision**: '+ctrl['decision']+'\\n- **Reviewer**: '+ctrl['reviewed_by']+'\\n- **Evidence**: '+ctrl['evidence_ref']+'\\n- **Note**: '+ctrl['comment']+'\\n- **Source digest**: '+ctrl['input_digest']+'\\n')
        for a in arts:
            fm=f'---\\nschema: {a.kind}/v1"""
swap(needle,sub)
p.write_text(s)
print('patched main',len(s.splitlines()),'lines')
