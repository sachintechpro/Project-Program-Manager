from pathlib import Path
import json
p=Path(__file__).parents[1]/'seed'/'data'/'schema.json';schema=json.loads(p.read_text())
meaning={
'initiative_key':'Stable identifier that joins all reference tables for one initiative.',
'stream_id':'Stable identifier of the parent development value stream.',
'role':'Internal stakeholder role key from the 29-role catalog.',
'owner_role':'Role responsible for this item and its assigned response.',
'actor_role':'Role performing this operational step.',
'provider_role':'Role responsible for the external dependency.',
'verifier_role':'Role authorized to verify this release control.',
'initiative_title':'Plain-English name of the business improvement initiative.',
'line_of_business':'Commercial or specialty insurance line affected.',
'estimated_cost_usd':'Modeled total implementation investment in US dollars; not actual spend.',
'estimated_annual_benefit_usd':'Modeled full-year benefit in US dollars; not a realized result.',
'planned_cost_usd':'Modeled component cost in US dollars, reconciled to initiative investment.',
'baseline_value':'Measured or modeled current-state value; interpret with metric_unit.',
 'target_value':'Intended future-state value; interpret with metric_unit.',
'metric_unit':'Unit in which the KPI is measured, such as hours or days.',
'operating_volume':'Expected number of transactions and explicit measurement period.',
'actual_status':'Whether the KPI has a verified actual measurement; examples are unmeasured.',
'execution_status':'Whether a test was actually executed; examples are not_run.',
'acceptance_criteria':'Observable pass/fail condition agreed with the Product Owner.',
'expected_result':'Observable outcome that a test must demonstrate.',
'negative_case':'Invalid or unauthorized business scenario that must not silently pass.',
'system_of_record':'External system authoritative for this field; not this demo.',
'classification':'Sensitivity classification used for role and data safeguards.',
'correlation_id':'Identifier linking events across integrated services.',
'input_digest':'Fingerprint of the exact documents reviewed in a control decision.',
'requirement_id':'Stable requirement identifier referenced by tests and contracts.',
'cost_category':'Type of estimate; all components reconcile to the investment total.',
'evidence_source':'System or attachment where independently verified evidence is stored.',
'measurement_source':'Authoritative operational measurement source for the defined KPI.',
'current_demo_stage':'Current simulated workflow location, not a real external release.',
'condition':'When this stakeholder review applies and may be blocking.',
'mandatory':'Whether the approval blocks the next gate, subject to its condition.'}
purposes={
 'value_streams':'Organizational business flow and target operating measures.','initiatives':'Modeled investment intake and business scope.','business_steps':'Ordered work from request through completed outcome.','requirements':'Individually traceable business, product and control needs.','business_rules':'Insurance decision logic and human authority limits.','data_fields':'Data contracts, types, required fields and permitted system owners.','interfaces':'Cross-system integration and failure behavior.','test_cases':'Independent, not-yet-executed verification scenarios.','risks':'Potential causes and planned mitigations, separate from actual issues.','dependencies':'Cross-team, shared-platform and vendor prerequisites.','stakeholder_assignments':'Scenario-specific responsibility assignments; not corporate HR access.','metrics':'Baseline, target, ownership and measurement source for business benefits.','cost_estimates':'Budget assumption breakdown, matching total requested funding.','release_controls':'Specific release criteria and required verification evidence.','handover_tasks':'Practical service acceptance and transition obligations.','role_approval_controls':'One actionable human review control per modeled stakeholder role.'}
for name,meta in schema.items():
    if name.startswith('_'):continue
    meta['purpose']=purposes[name]
    meta['optional_fields']=['test_evidence_ref'] if name=='test_cases' else []
    meta['field_help']={col:meaning.get(col, col.replace('_',' ').capitalize()+' for this record; use stable vocabulary and link to the parent initiative.') for col in meta['fields']}
p.write_text(json.dumps(schema,indent=2,ensure_ascii=False)+'\n')
print('Enriched',len(purposes),'data table schemas with column help')
